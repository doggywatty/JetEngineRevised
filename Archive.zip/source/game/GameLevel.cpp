// source/game/GameLevel.cpp
#include "GameLevel.h"
#include "game/utils/ControlledRandom.h"
#include "Game.h"
#include "CGameConfig.h"
#include "entities/GameEntity.h"
#include "entities/GameEntityCreator.h"
#include "entities/LevelDef.h"
#include "entities/LightDef.h"
#include "entities/MaterialDef.h"
#include "entities/Minion.h"
#include "entities/Pacesetter.h"
#include "gamemanagers/FlareMgr.h"
#include "gamemanagers/SkyDomeMgr.h"
#include "gamemanagers/ClaraFilesMgr.h"
#include "gamemanagers/PainterMgr.h"
#include "gamestates/GameState.h"
#include "Statistics.h"
#include "colorprofiles.h"
#include "leveltemplate/LevelSequenceGraph.h"
#include "leveltemplate/GameplayTemplateInstance.h"
#include "gamemanagers/BackgroundMgr.h"
#include "gamemanagers/LocationsMgr.h"
#include "entities/LocationInfoEntity.h"
#include "Player.h"
#include "interfaces/menus/Menu_Base.h"
#include "interfaces/menus/MenuMgr.h"
#include "scripting/ScriptFunctions.h"
#include "camera/cameramgr.h"
#include "luavm.h"
#include "particlemgr.h"
#include "project.h"
#include "scene/camera.h"
#include "scene/scenemgr.h"
#include "stream/istream.h"
#include "system.h"
#include "video/display.h"
#include "video/driver.h"
#include "video/painter.h"
#include <algorithm>

float GameLevel::s_cameraFar = 0;
ControlledRandom *GameLevel::s_randomizer[4] = { 0, 0, 0, 0 };
LevelSequenceGraphMgr *GameLevel::s_levelSequenceGraphMgr = 0;
const jet::String GameLevel::k_fadeFx_defaultTechnique("postfx_glow_fade.xml");
const jet::String GameLevel::k_fadeFx_glowTechnique("postfx_glow_fade.xml");

const jet::String &GameLevel::GetShadowTagName() {
    static const jet::String k_shadowTagName("Shadow");
    return k_shadowTagName;
}

static void Remove(std::vector<GameEntity*> &v, GameEntity *e) {
    std::vector<GameEntity*>::iterator it = std::find(v.begin(), v.end(), e);
    if (it != v.end()) v.erase(it);
}

// @0x510630: a camera at the origin, the world and menu scene managers, the camera manager and the managers of a level
GameLevel::GameLevel(bool isMovieLevel)
    : m_updatingEntities(false), m_minion(0), m_pacesetter(0), m_templateMgr(this), m_levelTemplateMgr(&m_templateMgr), m_tutorialCompleted(false), m_entityToSpawnCount(-1), m_fluffy(0), m_rocket(0), m_launcher(0), m_gameplayDef(0), m_largeMinionGameplay(0), m_fluffyGameplay(0), m_rocketGameplay(0),
      m_levelDef(0), m_luaVM(0), m_loadingLibs(false), m_initDone(false), m_postFxMaterial(0), m_postEffect(0), m_fadeState(1), m_nextPostEffect(0), m_fadeFx(0), m_fadeT(0),
      m_fadeInTime(0), m_fadeHoldTime(0), m_fadeOutTime(0), m_fadeInInterp(0), m_fadeOutInterp(0), m_postFxEnabled(true), m_postFxDone(0), m_fogOn(0.0f, 0.0f, 0),
      m_fogColor(math::vec4<float>(0, 0, 0, 0), math::vec4<float>(0, 0, 0, 0), 0), m_fogDepthTime(0), m_fogDepthElapsed(0), m_fogDepthAnim(false), m_camera(0), m_cameraMgr(0),
      m_playerDistance(0), m_isMovieLevel(isMovieLevel) {
    for (int i = 0; i < 4; i++) {
        if (s_randomizer[i]) continue;
        s_randomizer[i] = new ControlledRandom;
        if (i) s_randomizer[0]->AddLinked(s_randomizer[i]);
    }
    for (int i = 0; i < 2; i++) m_fogDepth[i] = m_fogDepthFrom[i] = m_fogDepthTo[i] = 0;
    const PlatformToggles &t = CGameConfig::Current();
    s_cameraFar = t.backgroundFarPlane;
    m_camera = new jet::scene::Camera(math::vec3<float>(0, 0, 0), math::quat<float>(0, 0, 0, 1));
    m_camera->SetNearDistance(0.5f);
    m_camera->SetFarDistance(s_cameraFar);
    for (int i = 0; i < 2; i++) {
        m_sceneMgr[i] = new jet::scene::SceneMgr();
        m_sceneMgr[i]->SetCamera(m_camera);
    }
    m_sceneMgr[SceneMgr_World]->SetDistanceCulling(t.sceneMgrCullingRadius, t.sceneMgrCullingDistance);
    m_sceneMgr[SceneMgr_World]->SetScreenRadiusCulling(t.sceneMgrCullingScreenPixels);
    m_cameraMgr = new CameraMgr(m_camera);
    new BackgroundMgr(!isMovieLevel);
    ps::ParticleMgr *pm = new ps::ParticleMgr;
    pm->Init();
    pm->SetComputeLocalspacePeriod(7);
    pm->SetMinDistance(0.3f);
    new FlareMgr;
    new SkyDomeMgr;
    new LocationsMgr;
    FlareMgr::GetInstance()->Enable(true);
}

GameLevel::~GameLevel() {
    delete LocationsMgr::GetInstance();
    delete SkyDomeMgr::GetInstance();
    delete FlareMgr::GetInstance();
    delete ps::ParticleMgr::GetInstance();
    delete BackgroundMgr::GetInstance();
    delete m_cameraMgr;
    delete m_postEffect;
    delete m_nextPostEffect;
    delete m_fadeFx;
    for (ExtraPostFx &e : m_extraPostFx) delete e.effect;
    for (int i = 0; i < 2; i++) delete m_sceneMgr[i];
    delete m_camera;
    delete m_luaVM;
}

// @0x5121ec: the libraries (when the project has none yet), then the level files
void GameLevel::Load(const std::map<jet::String, jet::stream::IStream*> &libs, const std::map<jet::String, jet::stream::IStream*> &levels) {
    static GameEntityCreator creator;
    m_loadingLibs = true;
    clara::Project *p = clara::Project::GetInstance();
    if (p->GetLibraryCount() == 0)
        for (auto &l : libs) {
            if (p->GetLibraryCount() == 0) p->LoadLibraries(*l.second, creator);
            else p->AddLibraries(*l.second, creator);
        }
    m_loadingLibs = false;
    for (auto &l : levels) p->LoadClaraFile(*l.second, creator);
}

// @0x5122e4: the Lua machine, once
void GameLevel::Init() {
    if (m_initDone) return;
    m_luaVM = new LuaVM;
    RegisterScriptFunctions(m_luaVM);
    m_initDone = true;
    m_pacesetter = new Pacesetter(clara::Project::GetInstance()->FindTemplateByName(Pacesetter::k_tmplName));
    m_pacesetter->SetName(jet::String("minionPacestter"));
    m_pacesetter->Init();
}

// @0x51240c
void GameLevel::PostInit() {
    BackgroundMgr::GetInstance()->PostInit();
    m_pacesetter->PostInit();
    if (!m_isMovieLevel && m_levelDef) {
        MenuMgr *mm = MenuMgr::GetInstance();
        mm->SetCameraEntity(m_levelDef->GetUIDefaultCamera3D());
        mm->SetDefault3dLightFrom(dynamic_cast<LightDef*>(m_levelDef->GetUIDefaultLight3D()));
    }
    m_fadeState = 1;
    RemoveEntities();
    if (m_levelDef) m_levelDef->DefineLevel();
    m_pacesetter->SetCurrentGameplayTemplateInstance(m_templateMgr.GetCurrentLevelTemplateInstance());
    Game::GetInstance()->SetCurvatureParams(math::vec2<float>(0.0f, 0.0f), 0);
    Game::GetInstance()->SetTimeSpeed(1.0f, 0, -1);
}

void GameLevel::AddAnimatedEntity(GameEntity *e, const jet::String &animation, int nodeCount) {
    Animable a = { e, animation, nodeCount };
    m_animatedEntities.push_back(a);
}

// @0x5162f0: the entities the level keeps by their kind; library entities do not count as the level's own
void GameLevel::EntityCreated(clara::DataEntity *e) {
    if (!e) return;
    const jet::String &n = e->GetBaseTemplateName();
    if (n.Equals(Minion::k_tmplName)) {
        if (!m_loadingLibs && !m_minion) m_minion = static_cast<Minion*>(e);
    } else if (n.Equals("Fluffy"))
        m_fluffy = e;
    else if (n.Equals("Rocket"))
        m_rocket = e;
    else if (n.Equals("GameplayDef"))
        m_gameplayDef = e;
    else if (n.Equals("FluffyGameplay"))
        m_fluffyGameplay = e;
    else if (n.Equals("LargeMinionGameplay"))
        m_largeMinionGameplay = e;
    else if (n.Equals("RocketGameplay"))
        m_rocketGameplay = e;
    else if (n.Equals("Launcher")) {
        if (!m_loadingLibs) m_launcher = e;
    }
}

// @0x51473c, 0x5147a0: an entity is queued to leave a list the frame it is removed in
void GameLevel::RegisterForUpdate(GameEntity *e, bool add) {
    if (!add) {
        m_entitiesToRemoveFromUpdate.push_back(e);
        Remove(m_entitiesToUpdateBackup, e);
    } else
        m_entitiesToUpdate.push_back(e);
}

void GameLevel::RegisterForRender(GameEntity *e, bool add) {
    if (!add) {
        m_entitiesToRemoveFromRender.push_back(e);
        Remove(m_entitiesToRenderBackup, e);
    } else
        m_entitiesToRender.push_back(e);
}

void GameLevel::RegisterVolatileEntity(GameEntity *e, bool add) {
    if (add) m_volatileEntities.push_back(e);
    else Remove(m_volatileEntities, e);
}

// @0x5165e0: what was asked to leave the update and render lists
void GameLevel::RemoveEntities() {
    while (!m_entitiesToRemoveFromUpdate.empty()) {
        Remove(m_entitiesToUpdate, m_entitiesToRemoveFromUpdate.front());
        std::swap(m_entitiesToRemoveFromUpdate.front(), m_entitiesToRemoveFromUpdate.back());
        m_entitiesToRemoveFromUpdate.pop_back();
    }
    while (!m_entitiesToRemoveFromRender.empty()) {
        Remove(m_entitiesToRender, m_entitiesToRemoveFromRender.front());
        std::swap(m_entitiesToRemoveFromRender.front(), m_entitiesToRemoveFromRender.back());
        m_entitiesToRemoveFromRender.pop_back();
    }
}

// @0x516c28: volatile entities out of the scene are queued, then at most 2 (all if asked) are deleted
void GameLevel::UpdateEntitiesDeletion(bool all) {
    for (GameEntity *e : m_entitiesToUpdate)
        if (e->GetPersistenceType() == GameEntity::PersistenceTypeDef::Volatile && (all || e->IsOutOfScene()))
            m_entitiesToDelete.insert(e);
    int n = 0;
    bool any = false;
    while (!m_entitiesToDelete.empty() && (all || n < 2)) {
        GameEntity *e = *m_entitiesToDelete.begin();
        delete e;
        m_entitiesToDelete.erase(e);
        n++;
        any = true;
    }
    if (any) RemoveEntities();
}

GameLevel::GameplayHooks *GameLevel::s_gameplay = 0;
int g_ActiveColorProfile = 0, g_LastActiveColorProfile = 0;
float g_TransitionTime = 0;
bool GameLevel::s_allProbabilityMode = false;

// @0x51a114: only the gameplay state plays them
void GameLevel::SetSound(jet::String *ambience, jet::String *music) {
    GameState *s = GameState::GetCrtState();
    if (s && s->GetStateID() == 1 && s_gameplay) s_gameplay->ApplySoundSettings(ambience, music);
}

// @0x51a15c
void GameLevel::SetCurrentMusicGain(float g) {
    GameState *s = GameState::GetCrtState();
    if (s && s->GetStateID() == 1 && s_gameplay) s_gameplay->SetCurrentMusicGain(g);
}

// @0x51b970 (the bapple spot of the new location joins with BappleMgr)
void GameLevel::OnLocationChanged(int from, int to) {
    Statistics::GetInstance()->Location_IncreaseEnterLocationCount(to);
    if (from != -1) m_minion->SetLocationEnterDistance(m_minion->GetTraveledDistance());
}

// the provider of the level template manager: the graph of the location says which template is next (the cannon mode overrides come
// with the gameplay)
void GameLevel::IncSequenceNumber() { s_levelSequenceGraphMgr->IncSequenceNumber(); }
int GameLevel::GetNextSequenceNumber() { return s_levelSequenceGraphMgr->GetNextSequenceNumber(); }
GameEntity *GameLevel::GetNextCamera() {
    return dynamic_cast<GameEntity*>(clara::Project::GetInstance()->FindEntityByName(s_levelSequenceGraphMgr->GetCameraName()));
}
int GameLevel::GetNextCameraTransitionTime() { return s_levelSequenceGraphMgr->GetCameraTransitionTime(); }
const SpeedDef *GameLevel::GetNextSpeed() { return s_levelSequenceGraphMgr->GetSpeed(); }
const jet::String &GameLevel::GetNextLocation() { return s_levelSequenceGraphMgr->GetLocation(); }
const jet::String &GameLevel::GetNextNodeLabel() { return s_levelSequenceGraphMgr->GetNextNodeLabel(); }
const jet::String &GameLevel::GetNextNodeId() { return s_levelSequenceGraphMgr->GetNextNodeId(); }
int GameLevel::GetNextNodeGraphId() { return s_levelSequenceGraphMgr->GetNextNodeGraphId(); }
void GameLevel::OnNodeCompleted(const int &graphId, const jet::String &nodeId) { s_levelSequenceGraphMgr->OnNodeCompleted(graphId, nodeId); }
bool GameLevel::IsNodeOnSpecialTree(const jet::String &id) const { return s_levelSequenceGraphMgr && s_levelSequenceGraphMgr->IsNodeInASpecialTree(id); }

// @0x51acac: the way the minion took at the last bifurcation
int GameLevel::GetFinalBifurcation() const {
    GameplayTemplateInstance *g = m_templateMgr.GetCurrentLevelTemplateInstance();
    return g ? g->GetFinalBifurcation() : 1;
}

// @0x517428
void GameLevel::DestroyGraphMgr() {
    delete s_levelSequenceGraphMgr;
    s_levelSequenceGraphMgr = 0;
}

// @0x51b5dc: the libraries of the locations the run uses stay loaded, the others go
void GameLevel::UpdateUsedDynamicLibraries() {
    ClaraFilesMgr *m = ClaraFilesMgr::GetInstance();
    m->ClearUsedLocations();
    m->AddUsedLocation(ELocation((ELocationDef::type)s_levelSequenceGraphMgr->GetNextNodeGraphId()));
    if (const GameplayTemplateInstance *c = m_templateMgr.GetCurrentLevelTemplateInstance()) m->AddUsedLocation(c->GetLocation());
    for (const GameplayTemplateInstance *g : m_templateMgr.GetLevelTemplateInstanceList()) m->AddUsedLocation(g->GetLocation());
    for (const LevelTemplateMgr::LevelTemplateData *d : m_templateMgr.GetLevelTemplateCache()) m->AddUsedLocation(d->location);
    for (int loc : BackgroundMgr::GetInstance()->GetLocationPoolArray()) m->AddUsedLocation(ELocation((ELocationDef::type)loc));
    m->EndUpdateUsedLocations();
    m->LoadLibraries();
    m->UnloadLibraries();
    if (m->UpdateUnloadingLibraries((int)(Game::GetInstance()->GetUpdateTimeUs() / 1000), -1, 0)) OnLocationTransitionLoadingFinished();
}

// @0x5179f8: the first templates are cached, the run may start further along, the first templates are made and the first background applies
void GameLevel::InitLevelStructure() {
    m_templateMgr.CacheInitialLevelSequence();
    if (unsigned start = Game::GetInstance()->GetStartDistance()) {
        const float f = (float)start * 0.9f;
        const unsigned meters = f > 0 ? (unsigned)f : 0;
        const unsigned covered = m_templateMgr.AdvanceLevelSequence(meters);
        m_minion->SetDistanceBase(meters - covered);
    }
    m_templateMgr.InitLevelParts();
    BackgroundMgr::GetInstance()->ApplySkyDome();
    BackgroundMgr::GetInstance()->ApplyFogValue();
    BackgroundMgr::GetInstance()->ApplyLensFlare();
}

// @0x51746c: the graphs of the locations the player has data for, the one of the player's location the current one
void GameLevel::LoadLevelSequence(const jet::String &firstGraph) {
    Game *game = Game::GetInstance();
    if (game->GetStartMode() != 0) DestroyGraphMgr();
    if (!s_levelSequenceGraphMgr) s_levelSequenceGraphMgr = new LevelSequenceGraphMgr;
    LevelSequenceGraphMgr *mgr = s_levelSequenceGraphMgr;
    Player *player = Player::GetInstance();
    int location = player->GetCurrentLocation();
    bool hidden = false;
    LocationsMgr *locations = LocationsMgr::GetInstance();
    if (LocationInfoEntity *info = locations->GetLocationInfo(location)) {
        if (info->IsHidden()) {
            location = info->GetFallbackLocationId();
            LocationInfoEntity *fallback = locations->GetLocationInfo(location);
            if (fallback && fallback->IsHidden()) location = 0;
            hidden = true;
        }
    }
    jet::String file = firstGraph;
    if (file.size() == 0) {
        static const char *const k_graphs[6] = { "levelsequence2_labo.graphml", "levelsequence2_resi.graphml", "levelsequence2_macho.graphml",
                                                 "levelsequence2_beach.graphml", "levelsequence2_rnt.graphml", "levelsequence2_mall.graphml" };
        for (int loc = 0; loc < 6; loc++) {
            if (mgr->HasLevelSequenceGraph(loc)) continue;
            if (!game->HasDLCDataFor(loc, false)) {
                if (location == loc) location = 0;
                continue;
            }
            mgr->AddLevelSequenceGraph(loc, jet::String(k_graphs[loc]));
        }
    }
    mgr->Reset();
    const int mode = game->GetStartMode();
    if (mode >= 2 && mode <= 6) location = mode - 2;
    else if (mode == 7) {
        player->SetCurrentLocation(5);
        location = 5;
    }
    if ((mode >= 2 && mode <= 6) || hidden) player->SetCurrentLocation(location);
    mgr->SetCurrentLevelSequenceGraph(location);
    UpdateUsedDynamicLibraries();
    InitLevelStructure();
    game->SetStartMode(0);
}

// @0x516a68 (the level-part cleanup joins once LevelTemplateMgr exists)
void GameLevel::DeleteVolatileEntities(bool all) {
    GameLevel *l = GetInstance();
    if (!l) return;
    if (all) l->RemoveEntities();
    l->UpdateEntitiesDeletion(true);
    if (!all) return;
    if (!l->m_entitiesToUpdateBackup.empty()) {
        l->RemoveEntities();
        l->m_entitiesToUpdate = l->m_entitiesToUpdateBackup;
        l->m_entitiesToRender = l->m_entitiesToRenderBackup;
        l->m_entitiesToUpdateBackup.clear();
        l->m_entitiesToRenderBackup.clear();
        l->UpdateEntitiesDeletion(true);
    }
    std::vector<GameEntity*> vol(l->m_volatileEntities);
    for (GameEntity *e : vol) delete e;
}

// @0x51289c's entity pass: every registered entity updates once, on a copy so they can register others
void GameLevel::UpdateEntities() {
    RemoveEntities();
    m_updatingEntities = true;
    std::vector<GameEntity*> list(m_entitiesToUpdate);
    for (size_t i = 0; i < list.size(); i++) list[i]->Update();
    m_updatingEntities = false;
    RemoveEntities();
}

// @0x51289c: the project's movies, the entities, the scripts and the camera
void GameLevel::Update(bool fullUpdate) {
    Game *g = Game::GetInstance();
    int dt = (int)(g->GetUpdateTimeUs() / 1000);
    m_camera = m_cameraMgr->GetSceneCamera();
    if (!g->IsPaused()) clara::Project::GetInstance()->Update(dt);
    if (fullUpdate) RemoveEntities();
    BackgroundMgr::GetInstance()->Update();
    RemoveEntities();
    UpdateEntities();
    if (!IsFluffyMode()) {
        UpdateEntitiesDeletion(false);
        m_templateMgr.UpdateLevelParts();
        RemoveEntities();
    }
    if (m_luaVM) m_luaVM->Update((unsigned)dt);
    UpdateCamera(dt, false);
    if (jet::scene::Camera *c = m_sceneMgr[SceneMgr_World]->GetCullCamera()) (void)c;
    ClaraFilesMgr::GetInstance()->UpdateUnloadingLibraries(dt, 1, 500);
}

// @0x512ca4: the camera manager runs once in the update and not again while rendering, unless the cinematic camera is on
void GameLevel::UpdateCamera(int dt, bool cinematicPass) {
    Game *g = Game::GetInstance();
    if (g->IsPaused() || g->IsCinematic()) dt = 0;
    if (!cinematicPass) m_cameraMgr->Update((unsigned)dt);
}

bool GameLevel::IsCamera(const clara::Entity *e) const {
    if (!e) return false;
    const jet::String &n = e->GetTemplateName();
    return n.Equals("CameraDirect") || n.Equals("CameraCinematic") || n.Equals("CameraFollow") || n.Equals("CameraFluffy");
}

// @0x51aabc
void GameLevel::SetCamera(CameraController *c, unsigned ms) { m_cameraMgr->SetCamera(c, ms, 0); }

void GameLevel::SetFog(bool on, unsigned ms) {
    m_fogOn.SetDelay((int)ms);
    m_fogOn.SetTargetValue(on ? 1.0f : 0.0f);
}

void GameLevel::SetFogColor(const jet::video::Color &c, unsigned ms) {
    m_fogColor.SetDelay((int)ms);
    m_fogColor.SetTargetValue(math::vec4<float>(c.r, c.g, c.b, c.a));
}

// @0x5187bc: the depths blend from where they are to the new ones
void GameLevel::SetFogDepth(float start, float end, unsigned ms) {
    m_fogDepthTime = (int)ms;
    if (ms == 0) {
        m_fogDepthAnim = false;
        m_fogDepthElapsed = 0;
        m_fogDepthTo[0] = m_fogDepth[0];
        m_fogDepthTo[1] = m_fogDepth[1];
    }
    if ((int)ms < 1) {
        m_fogDepth[0] = m_fogDepthTo[0] = start;
        m_fogDepth[1] = m_fogDepthTo[1] = end;
        m_fogDepthAnim = false;
    } else if (m_fogDepthTo[0] != start || m_fogDepthTo[1] != end) {
        m_fogDepthElapsed = 0;
        m_fogDepthFrom[0] = m_fogDepth[0];
        m_fogDepthFrom[1] = m_fogDepth[1];
        m_fogDepthTo[0] = start;
        m_fogDepthTo[1] = end;
        m_fogDepthAnim = !(m_fogDepth[0] == start && m_fogDepth[1] == end);
    }
}

// @0x513bdc: the driver's fog follows the level's, fading with the "on" factor
void GameLevel::RenderFog() {
    jet::video::Driver *drv = jet::video::Driver::GetCurrent();
    const int dt = (int)Game::GetInstance()->GetRenderTime();
    m_fogOn.Update(dt);
    m_fogColor.Update(dt);
    if (m_fogDepthAnim) {
        m_fogDepthElapsed += dt;
        if (m_fogDepthElapsed < m_fogDepthTime) {
            if (m_fogDepthElapsed < 0) {
                m_fogDepth[0] = m_fogDepthFrom[0];
                m_fogDepth[1] = m_fogDepthFrom[1];
            } else {
                float t = jet::core::SmoothStep((float)m_fogDepthElapsed / (float)m_fogDepthTime).v;
                m_fogDepth[1] = t * m_fogDepthTo[1] + (1.0f - t) * m_fogDepthFrom[1];
                m_fogDepth[0] = t * m_fogDepthTo[0] + (1.0f - t) * m_fogDepthFrom[0];
            }
        } else {
            m_fogDepth[0] = m_fogDepthTo[0];
            m_fogDepth[1] = m_fogDepthTo[1];
            m_fogDepthAnim = false;
        }
    }
    float on = m_fogOn.GetCurrentValue();
    bool enabled = on > 0.0f;
    drv->SetFog(enabled);
    if (enabled) {
        math::vec4<float> c = m_fogColor.GetCurrentValue();
        jet::video::Color col(c.x, c.y, c.z, c.w * on);
        drv->SetFogParams(col, m_fogDepth[0], m_fogDepth[1]);
    }
}

// @0x5146f4: black in a movie level, else the fog colour
math::vec4<float> GameLevel::GetClearColor() {
    if (m_isMovieLevel) return math::vec4<float>(0, 0, 0, 1);
    return m_fogColor.GetCurrentValue();
}

void GameLevel::SetCurrentPostEffect(jet::video::PostEffect *pe) {
    delete m_postEffect;
    m_postEffect = pe;
}

// @0x517d14
void GameLevel::SetCurrentPostEffect(MaterialDef *def, bool fade, const jet::String &technique, int fadeOutMs, int holdMs, int fadeInMs,
                                     jet::core::InterpolationDef::type outInterp, jet::core::InterpolationDef::type inInterp, void (*onDone)()) {
    if (m_postFxDone) {
        void (*f)() = m_postFxDone;
        m_postFxDone = 0;
        f();
    }
    m_postFxDone = onDone;
    m_postFxMaterial = def;
    jet::video::PostEffect *pe = 0;
    if (def) {
        jet::video::Material m;
        std::vector<std::vector<jet::String> > names;
        def->LoadMaterial(m, names);
        pe = new jet::video::PostEffect(m);
    }
    delete m_nextPostEffect;
    m_nextPostEffect = 0;
    if (!fade) {
        if (m_fadeState == 2) m_nextPostEffect = pe;
        else SetCurrentPostEffect(pe);
        return;
    }
    const jet::String tech = MaterialDef::s_postFxEnabled ? technique : jet::String("basic.xml");
    if (!m_fadeFx) m_fadeFx = new jet::video::PostEffect(tech);
    else m_fadeFx->SetRenderTechnique(tech);
    m_nextPostEffect = pe;
    m_fadeInInterp = (int)inInterp;
    m_fadeOutInterp = (int)outInterp;
    m_fadeState = 2;
    m_fadeOutTime = (float)fadeOutMs * 0.001f;
    m_fadeInTime = (float)fadeInMs * 0.001f;
    m_fadeHoldTime = (float)holdMs * 0.001f;
}

// @0x517a94
void GameLevel::AddExtraPostEffect(MaterialDef *def, jet::core::Delayer<float, jet::core::QuadraticEaseIn> *delayer, unsigned *time) {
    for (ExtraPostFx &e : m_extraPostFx)
        if (e.def == def) {
            e.users++;
            return;
        }
    jet::video::Material m;
    std::vector<std::vector<jet::String> > names;
    def->LoadMaterial(m, names);
    ExtraPostFx e = { new jet::video::PostEffect(m), def, 1, delayer, time };
    m_extraPostFx.push_back(e);
}

// @0x517c30: the effect goes with its last user
void GameLevel::RemoveExtraPostEffect(MaterialDef *def) {
    for (size_t i = 0; i < m_extraPostFx.size(); i++)
        if (m_extraPostFx[i].def == def) {
            if (--m_extraPostFx[i].users == 0) {
                delete m_extraPostFx[i].effect;
                m_extraPostFx.erase(m_extraPostFx.begin() + i);
            }
            return;
        }
}

// @0x518010: the fades of the post effect, a step each frame
void GameLevel::UpdatePostEffectTransition(std::vector<jet::video::PostEffect*> &out) {
    static const jet::String k_fxTime("fxTime"), k_mixAmount("mixAmount");
    if (m_fadeState == 1) return;
    Game *g = Game::GetInstance();
    float dt = 0.0f;
    if (!g->IsPaused() && !g->IsCinematic()) dt = (float)g->GetRenderTime() * 0.001f;
    auto setUniform = [](jet::video::Material &m, unsigned pass, const jet::String &name, float v) {
        int idx = m.FindUniformIdxByName(pass, name);
        if (idx >= 0) m.SetUniform(pass, (unsigned)idx, jet::video::ShaderUniform(v));
    };
    switch (m_fadeState) {
    case 0: {
        m_fadeT -= dt;
        float f = jet::core::GetInterpolated(jet::core::Interpolation((int)m_fadeInInterp), math::clamp(m_fadeT / m_fadeInTime, 0.0f, 1.0f));
        setUniform(m_fadeFx->GetMaterial(), 0, k_fxTime, f);
        out.push_back(m_fadeFx);
        if (m_fadeT <= 0.0f) {
            m_fadeT = 0;
            m_fadeState = 1;
        }
        break;
    }
    case 2: {
        m_fadeT += dt;
        float f = jet::core::GetInterpolated(jet::core::Interpolation((int)m_fadeOutInterp), math::clamp(m_fadeT / m_fadeOutTime, 0.0f, 1.0f));
        setUniform(m_fadeFx->GetMaterial(), 0, k_fxTime, f);
        out.push_back(m_fadeFx);
        if (m_fadeOutTime <= m_fadeT) {
            m_fadeT = m_fadeHoldTime;
            m_fadeState = 3;
            SetCurrentPostEffect(m_nextPostEffect);
            m_nextPostEffect = 0;
            if (m_postFxDone) {
                void (*f)() = m_postFxDone;
                m_postFxDone = 0;
                f();
            }
        }
        break;
    }
    case 3:
        m_fadeT -= dt;
        out.push_back(m_fadeFx);
        if (m_fadeT <= 0.0f) {
            m_fadeT = m_fadeInTime;
            m_fadeState = 0;
        }
        break;
    default:
        break;
    }
}

// @0x513bdc's neighbours: the frame's passes
void GameLevel::InitRender() { LightMgr::GetInstance()->Process(); }

// @0x512ec4: the backgrounds and the entities draw themselves into the scene manager
void GameLevel::RenderEntities() {
    BackgroundMgr::GetInstance()->Render();
    std::vector<GameEntity*> list(m_entitiesToRender);
    for (GameEntity *e : list) e->Render();
}

// @0x512f40
void GameLevel::RenderSceneMgrs() {
    m_sceneMgr[SceneMgr_World]->SetCamera(m_camera);
    m_sceneMgr[SceneMgr_World]->Render();
}

// @0x512f70: the particle systems seen from the camera
void GameLevel::RenderParticles() {
    jet::scene::Camera *cam = m_cameraMgr->GetSceneCamera();
    ps::CameraData cd;
    cd.position = cam->GetPosition();
    cd.direction = cam->GetFrontVector();
    Game *g = Game::GetInstance();
    unsigned dt = g->GetRenderTime();
    if (g->IsPaused() || g->IsCinematic()) dt = 0;
    ps::ParticleMgr::GetInstance()->Update(dt);
    ps::ParticleMgr::GetInstance()->Render(cd);
}

// @0x51313c: the menu over the scene, then the painters
void GameLevel::RenderGUI() {
    jet::video::Driver *drv = jet::video::Driver::GetCurrent();
    drv->Flush();
    PainterMgr *pm = PainterMgr::GetInstance();
    jet::video::Painter &painter = pm->Get2DPainter();
    MenuMgr *mm = MenuMgr::GetInstance();
    if (mm->GetCurrentPlayingMenu()) mm->Render(painter);
    pm->Get3DPainter().Flush();
    painter.Flush();
}

// @0x51331c: the post effects of the level
void GameLevel::RenderPostEffectStart() {
    static const jet::String k_nearFar("nearFar");
    jet::video::Driver *drv = jet::video::Driver::GetCurrent();
    std::vector<jet::video::PostEffect*> list;
    UpdatePostEffectTransition(list);
    if (m_postFxEnabled && MaterialDef::s_postFxEnabled) {
        if (m_postEffect) {
            jet::video::Material &m = m_postEffect->GetMaterial();
            if (m.GetRenderPassCount() > 1) {
                int idx = m.FindUniformIdxByName(1, k_nearFar);
                if (idx >= 0) {
                    jet::scene::Camera *cam = m_cameraMgr->GetSceneCamera();
                    m.SetUniform(1, (unsigned)idx, jet::video::ShaderUniform(math::vec2<float>(cam->GetNearDistance(), cam->GetFarDistance())));
                }
            }
            list.push_back(m_postEffect);
        }
        for (ExtraPostFx &e : m_extraPostFx) list.push_back(e.effect);
        drv->BeginPostEffect(list, jet::video::PostFXAADef::None);
    }
}

// @0x513574: ends the post effects; without them the fades are quads over the screen
void GameLevel::RenderPostEffectEnd() {
    jet::video::Driver *drv = jet::video::Driver::GetCurrent();
    drv->EndPostEffect(math::mat4<float>());
    if (MaterialDef::s_postFxEnabled || m_fadeState == 1) return;
    drv->Flush();
    unsigned color = 0xffffffff;
    float amount = 0;
    bool blend = true;
    switch (m_fadeState) {
    case 0:
        amount = jet::core::GetInterpolated(jet::core::Interpolation((int)m_fadeInInterp), math::clamp(m_fadeT / m_fadeInTime, 0.0f, 1.0f));
        color = 0x80ffffff;
        break;
    case 2:
        amount = jet::core::GetInterpolated(jet::core::Interpolation((int)m_fadeOutInterp), math::clamp(m_fadeT / m_fadeOutTime, 0.0f, 1.0f));
        color = 0x80ffffff;
        break;
    case 3: blend = false; break;
    default: break;
    }
    jet::video::Painter &p = PainterMgr::GetInstance()->GetGenericPainter();
    jet::video::Material m;
    m.SetRenderTechnique(jet::String("_primitive2"));
    jet::video::RenderState &rs = m.GetRenderState(0);
    rs.SetBlending(true);
    rs.SetBlendFormula(jet::video::BlendFormula(jet::video::BlendFormula::ComboDef::Alpha));
    rs.SetCulling(false);
    p.SetMaterial(m);
    p.SetTransform(math::mat4<float>());
    math::vec2<unsigned int> sz = jet::System::GetDisplay(0)->GetSize();
    float w = (float)sz.x, h = (float)sz.y;
    float a = blend ? amount * 255.0f : 255.0f;
    jet::video::Color c(1, 1, 1, std::max(0.0f, std::min(1.0f, a / 255.0f)));
    (void)color;
    p.FillQuad(jet::video::Painter::Vertex(math::vec2<float>(0, 0), c), jet::video::Painter::Vertex(math::vec2<float>(w, 0), c),
               jet::video::Painter::Vertex(math::vec2<float>(w, h), c), jet::video::Painter::Vertex(math::vec2<float>(0, h), c));
    p.Flush();
}

// @0x513da4: one frame of the level, then the menu
void GameLevel::Render() {
    RemoveEntities();
    m_animatedEntities.clear();
    Game *g = Game::GetInstance();
    Menu_Base *menu = MenuMgr::GetInstance()->GetCurrentPlayingMenu();
    if (!menu || menu->RenderGameInBG()) {
        InitRender();
        RenderFog();
        RenderEntities();
        UpdateCamera((int)g->GetRenderTime(), true);
        g->RenderShadowMap(m_sceneMgr[SceneMgr_World]);
        jet::video::Driver *drv = jet::video::Driver::GetCurrent();
        if (g->GetDownsampleRT()) {
            drv->SetCrtRenderTarget(g->GetDownsampleRT());
            drv->Flush();
        } else
            drv->SetCrtRenderTarget(jet::System::GetDisplay(0)->GetRenderTarget());
        RenderPostEffectStart();
        RenderSceneMgrs();
        RenderParticles();
        RenderPostEffectEnd();
        RenderGUI();
        EndRender();
    } else
        RenderGUI();
}
