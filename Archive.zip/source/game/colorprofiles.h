// source/game/colorprofiles.h
#ifndef SOURCE_GAME_COLORPROFILES_H
#define SOURCE_GAME_COLORPROFILES_H

// The colour profile in use (the grading of the location) and the one before it; switching takes g_TransitionTime seconds
extern int g_ActiveColorProfile, g_LastActiveColorProfile;
extern float g_TransitionTime;

#endif
