// source/game/cameracontrollers/FollowMinionCamera.cpp
