// source/game/cameracontrollers/FollowMinionCamera.h
#ifndef SOURCE_GAME_CAMERACONTROLLERS_FOLLOWMINIONCAMERA_H
#define SOURCE_GAME_CAMERACONTROLLERS_FOLLOWMINIONCAMERA_H

class FollowMinionCamera : public CameraController {  // sizeof 0x150
public:
    FollowMinionCamera(CameraFollowEntity::FollowCameraConfigStruct*);
    void PostInit();
    void InitCameraPositionAndRotation();
    virtual math::vec3<float> GetPosition();
    virtual math::quat<float> GetRotation();
    virtual float GetFov();
    virtual const jet::String &GetType();
    virtual void Update(const unsigned);
    void UpdateTimers(const unsigned);
    virtual void Serialize(jet::stream::IStreamW&);
    virtual void Deserialize(jet::stream::IStream&);
    virtual void SetShakeTime(float);
    CameraFollowEntity::FollowCameraConfigStruct::FocusType GetFocusType();
    int GetCinematicCameraTransitionInTime();
    int GetCinematicCameraTransitionOutTime();
    static bool IsFollowMinionCameraCtrl(CameraController*);
    void SetCameraData(RunningCameraData*);
private:
    void UpdateRunningCameraDataByStateType(ActorState*, const ActorStateSet*);
    void UpdateRunningEffect(int, math::vec3<float>&, math::quat<float>&, float&);
    void SetPosition(const math::vec3<float>&);
    void SetRotation(const math::quat<float>&);
    void SetFov(float);
public:
    static jet::String k_cameraType;
private:
    math::vec3<float> m_position;  // 0x4
    math::quat<float> m_rotation;  // 0x10
    float m_fov;  // 0x20
    math::vec3<float> m_cameraLocalPosition;  // 0x24
    math::quat<float> m_cameraLocalRotation;  // 0x30
    jet::core::Delayer<float,jet::core::LinearStep> m_targetZDelayer;  // 0x40
    jet::core::Delayer<math::vec3<float>,jet::core::LinearStep> m_globalPositionDelayer;  // 0x58
    jet::core::Delayer<math::vec3<float>,jet::core::LinearStep> m_localPositionDelayer;  // 0x88
    jet::core::Delayer<math::quat<float>,jet::core::LinearStep> m_rotationDelayer;  // 0xB8
    jet::core::Delayer<float,jet::core::LinearStep> m_yawDelayer;  // 0xF4
    CameraFollowEntity::FollowCameraConfigStruct *m_followCameraConfig;  // 0x10C
    math::vec3<float> m_cameraOffset;  // 0x110
    math::vec3<float> m_targetOffset;  // 0x11C
    math::vec3<float> m_translationOffset;  // 0x128
    int m_runTime;  // 0x134
    float m_translationScale;  // 0x138
    float m_roll;  // 0x13C
    float m_runOffsetAngle;  // 0x140
    int m_transitionTime;  // 0x144
    RunningCameraData *m_cameraData;  // 0x148
    float m_vibrationTimer;  // 0x14C
    static const int k_cameraPositionDelayTime;
    static const int k_cameraRotationDelayTime;
};

#endif
