// source/game/interfaces/PopupMgr.h
#ifndef SOURCE_GAME_INTERFACES_POPUPMGR_H
#define SOURCE_GAME_INTERFACES_POPUPMGR_H

class PopupMgr : public Singleton<PopupMgr> {  // sizeof 0x2C
public:
    PopupMgr();
    virtual ~PopupMgr();
    void Init();
    void PushPopup(BasePopup*);
    void PopPopup(bool);
    void PushInfoPopup(const std::basic_string<char,std::char_traits<char>,std::allocator<char> >&);
    void Update(int);
    void Render();
    bool IsEnabled(bool);
    void RefreshPopup();
private:
    void _ClearDelayedDestructionArray();
    std::vector<BasePopup *,std::allocator<BasePopup *> > m_popupPool;  // 0x4
    std::vector<BasePopup *,std::allocator<BasePopup *> > m_delayedDestructionArray;  // 0x18
};

#endif
