// source/game/interfaces/menus/Menu_Options.h
#ifndef SOURCE_GAME_INTERFACES_MENUS_MENU_OPTIONS_H
#define SOURCE_GAME_INTERFACES_MENUS_MENU_OPTIONS_H

// See Menu_Shop.h for why these additions were needed (no #includes at all originally, and
// GetMenuName() missing `const` left the class abstract -- same two bugs, same fix).
#include "Menu_Base.h"
#include "jenum.h"
#include "game/online/tracking/tracking.h"
class InterfaceList;
class InterfaceScrollBar;
class OptionsSettingsPage;
class OptionsConnectionPage;
class OptionsHelpPage;
class OptionsAboutPage;
class RedeemCodePage;

class Menu_Options : public Menu_Base {  // sizeof 0x178
public:
    // Not in the PDB header. Menu_Options::GetTrackingState(safe_enum<EStateDef>) const at 0x48c234
    // does `cmp r1,#5; bhi <invalid>` into a 6-entry table -- confirms exactly 6 values, 0..5, from
    // the real binary. Member names are NOT verified (the header lists 5 sub-pages: Settings,
    // Connection, Help, About, RedeemCode -- plausibly states 1..5 with 0 as a default/transition
    // state, but this is a guess at names only, not at the count). See re/NOTES.md.
    struct EStateDef { enum type { Options_Default = 0, Options_Settings = 1, Options_Connection = 2, Options_Help = 3, Options_About = 4, Options_RedeemCode = 5 }; };
    virtual const jet::String &GetMenuName() const;
    Menu_Options();
    virtual ~Menu_Options();
    virtual void Init();
    virtual void Update(int);
    virtual void Render(const jet::scene::Camera&, jet::video::Painter&);
    virtual void Refresh();
    virtual void OnEnter();
    virtual void OnQuit();
    virtual bool RenderGameInBG();
    virtual bool ShowBanner();
    bool AnyTabWithNotification();
    virtual TRACKING_SCREEN GetCurrentTrackingScreen();
private:
    void SetState(safe_enum<Menu_Options::EStateDef,enum Menu_Options::EStateDef::type>);
    TRACKING_SCREEN GetTrackingState(safe_enum<Menu_Options::EStateDef,enum Menu_Options::EStateDef::type>);
    void UpdateTabNotify(safe_enum<Menu_Options::EStateDef,enum Menu_Options::EStateDef::type>, bool, bool, const jet::String&, const jet::String&);
public:
    static const jet::String k_menuName;
private:
    std::vector<InterfaceButton *,std::allocator<InterfaceButton *> > m_tabButtons;  // 0x124
    InterfaceButton *m_backButton;  // 0x138
    InterfaceButton *m_ccButton;  // 0x13C
    InterfaceList *m_subpagesParent;  // 0x140
    InterfaceScrollBar *m_subpagesScroll;  // 0x144
    InterfaceText *m_textCategory;  // 0x148
    std::vector<jet::String,std::allocator<jet::String> > m_tabHeaderStrings;  // 0x14C
    safe_enum<Menu_Options::EStateDef,enum Menu_Options::EStateDef::type> m_state;  // 0x160
    OptionsSettingsPage *m_settingsPage;  // 0x164
    OptionsConnectionPage *m_connectionPage;  // 0x168
    OptionsHelpPage *m_helpPage;  // 0x16C
    OptionsAboutPage *m_aboutPage;  // 0x170
    RedeemCodePage *m_redeemCodePage;  // 0x174
};

#endif
