// source/game/interfaces/CostumeShopItem.cpp
