// source/game/interfaces/PopupMgr.cpp
