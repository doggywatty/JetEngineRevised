// source/game/interfaces/popups/BasePopup.h
#ifndef SOURCE_GAME_INTERFACES_POPUPS_BASEPOPUP_H
#define SOURCE_GAME_INTERFACES_POPUPS_BASEPOPUP_H

class BasePopup : public BasicPage {  // sizeof 0x1C8
public:
    BasePopup(const jet::String&);
    virtual ~BasePopup();
    virtual void Update(int);
    virtual void Render(const jet::scene::Camera&, jet::video::Painter&);
    virtual void RefreshPopup();
    virtual bool CanShowInActionPhase();
    virtual TRACKING_SCREEN GetCurrentTrackingScreen();
protected:
    bool m_refreshOnNextFrame;  // 0x1C4
    bool m_canShowInActionPhase;  // 0x1C5
};

#endif
