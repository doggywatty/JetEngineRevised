// source/game/interfaces/popups/PopupQuestion.h
#ifndef SOURCE_GAME_INTERFACES_POPUPS_POPUPQUESTION_H
#define SOURCE_GAME_INTERFACES_POPUPS_POPUPQUESTION_H

class PopupQuestion : public BasePopup {  // sizeof 0x1E4
public:
    PopupQuestion(jet::String, void*, void (void*)*, void (void*)*);
    virtual ~PopupQuestion();
    virtual void Update(int);
    virtual void Render(const jet::scene::Camera&, jet::video::Painter&);
    virtual void RefreshPopup();
private:
    InterfaceButton *m_yesButton;  // 0x1C8
    InterfaceButton *m_noButton;  // 0x1CC
    InterfaceText *m_infoText;  // 0x1D0
    jet::String m_textPopupString;  // 0x1D4
    void (*m_yesCallback)(void*);  // 0x1D8
    void (*m_noCallback)(void*);  // 0x1DC
    void* m_userData;  // 0x1E0
};

#endif
