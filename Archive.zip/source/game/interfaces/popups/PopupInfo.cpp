// source/game/interfaces/popups/PopupInfo.cpp
