// source/game/interfaces/popups/PopupInfo.h
#ifndef SOURCE_GAME_INTERFACES_POPUPS_POPUPINFO_H
#define SOURCE_GAME_INTERFACES_POPUPS_POPUPINFO_H

class PopupInfo : public BasePopup {  // sizeof 0x1E4
public:
    PopupInfo(safe_enum<PopupInfo::EPopupInfoTypeDef,enum PopupInfo::EPopupInfoTypeDef::type>, std::basic_string<char,std::char_traits<char>,std::allocator<char> >);
    virtual ~PopupInfo();
    virtual void Update(int);
    virtual void Render(const jet::scene::Camera&, jet::video::Painter&);
    virtual void RefreshPopup();
private:
    void OnYesButton();
    void OnNoButton();
    void OnOkButton();
    void OnCancelButton();
    safe_enum<PopupInfo::EPopupInfoTypeDef,enum PopupInfo::EPopupInfoTypeDef::type> m_type;  // 0x1C8
    InterfaceButton *m_yesButton;  // 0x1CC
    InterfaceButton *m_noButton;  // 0x1D0
    InterfaceButton *m_okButton;  // 0x1D4
    InterfaceButton *m_cancelButton;  // 0x1D8
    InterfaceText *m_infoText;  // 0x1DC
    static PopupInfo::PopupConfig k_popupConfig[0];
    jet::String m_textPopupString;  // 0x1E0
};

#endif
