// source/game/interfaces/CostumeShopItem.h
#ifndef SOURCE_GAME_INTERFACES_COSTUMESHOPITEM_H
#define SOURCE_GAME_INTERFACES_COSTUMESHOPITEM_H

class CostumeShopItem : public BasicPage {  // sizeof 0x214
public:
    CostumeShopItem();
    virtual ~CostumeShopItem();
    virtual void Update(int);
    void UpdateButtonsVisibility();
    virtual void Render(const jet::scene::Camera&, jet::video::Painter&);
    bool IsTransitionInside();
    void SetState(int);
    int GetState();
    void SetCostume(MinionCostume*);
    MinionCostume *GetCostume();
    void SetButtonsActive(bool);
    void SetTransition(bool);
private:
    int m_state;  // 0x1C4
    InterfaceArea *m_area;  // 0x1C8
    float m_width;  // 0x1CC
    float m_areaOffsetY;  // 0x1D0
    static const int k_offsetDelayTime;
    jet::core::Delayer<float,jet::core::SmootherStep> m_offsetDelayer;  // 0x1D4
    InterfaceText *m_name;  // 0x1EC
    InterfaceGraph *m_nameBox;  // 0x1F0
    InterfaceButton *m_buyButton;  // 0x1F4
    InterfaceButton *m_buttonBuyOffer;  // 0x1F8
    InterfaceGraph *m_graphBananas;  // 0x1FC
    InterfaceGraph *m_graphTokens;  // 0x200
    InterfaceButton *m_buttonEquip;  // 0x204
    InterfaceText *m_textEquipped;  // 0x208
    MinionCostume *m_costume;  // 0x20C
    InterfaceText *m_bonusText;  // 0x210
};

#endif
