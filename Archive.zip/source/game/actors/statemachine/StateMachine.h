// source/game/actors/statemachine/StateMachine.h
#ifndef SOURCE_GAME_ACTORS_STATEMACHINE_STATEMACHINE_H
#define SOURCE_GAME_ACTORS_STATEMACHINE_STATEMACHINE_H

class StateMachine {  // sizeof 0x8C
public:
    StateMachine();
    virtual ~StateMachine();
    void SM_Init(jet::scene::Model*, const clara::Param::StateValue*);
    void SM_AddSateSet(jet::String);
    void SM_Reset();
    void SM_Update(int);
    ActorState *SM_GetNextState(ActorState*);
    const jet::String &SM_GetStateName(int);
    const ActorStateSet *SM_GetStateSet(const jet::String&);
    const ActorStateSet *SM_GetStateSet(int);
    void SM_SetStateSet(const jet::String&, bool);
    void SM_SetStateSet(int, bool);
    unsigned SM_GetStateSetCount();
    virtual bool SM_SetState(const jet::String&);
    virtual bool SM_SetState(int);
    ActorState *SM_GetState(const jet::String&);
    ActorState *SM_GetState(int);
    void SM_SetStateLabel(const jet::String&);
    void SM_SetStateLabel(int);
    void SM_NextState();
    int FindStateIdxByName(const jet::String&);
    void SM_ClearStack();
    void SM_LinkTo(StateMachine*);
    virtual bool SM_OnInputEvent(int, int, bool);
    virtual bool SM_OnEngineEvent(int);
    virtual bool SM_OnScreenEvent(int, int, bool);
    virtual void SM_OnChangeState(ActorState*, ActorState*);
    virtual void SM_OnChangeAnim(ActorState*);
    virtual void SM_SwitchStateEvent(int*, int*, int*);
    virtual int SM_GetFilteredState(int);
    virtual bool SM_CanChangeState();
    void SM_SetQueuedEventsTime(int);
    virtual bool SM_ExecuteTrigger(const StateTrigger*, bool);
    bool SM_HasStateLabel(int, int);
    static void SM_SetBlendingEnabled(bool);
    virtual unsigned SM_GetId();
    static void SM_SetBulletTimeTrackTransitionTimePgt(float);
    void SM_SetAnimatedCostume(MinionCostume*);
protected:
    virtual int SM_GetAnimTime();
    virtual int SM_GetAnimOldTime();
    virtual int SM_GetAnimTotalTime();
    void SM_ChangeModel(jet::scene::Model*);
    void SM_ResetStateTracks();
    void SM_AddEffectEvent(ActorState*, const StateEvent*, EffectDef*, int, const jet::scene::Node*, int);
    virtual void SM_UpdateStateTracks();
    int SM_FindTriggerIdxByEvent(int, int, int);
private:
    bool SM_OnStateEvent(int, int, int);
    void SM_UpdateQueuedEvents();
    void SM_AddToStack(ActorState*);
public:
    static void SM_StartDebug();
    void SM_RenderDebug(jet::String);
private:
    std::vector<ActorStateSet const *,std::allocator<ActorStateSet const *> > m_stateSets;  // 0x4
    int m_stateSetIdx;  // 0x18
    int m_stateIdx;  // 0x1C
    ActorState *m_state;  // 0x20
    jet::scene::Model *m_pModel;  // 0x24
    std::vector<ActorState *,std::allocator<ActorState *> > m_stateStack;  // 0x28
    std::vector<StateTrigger const *,std::allocator<StateTrigger const *> > m_queuedTriggers;  // 0x3C
    std::vector<StateMachineEvent,std::allocator<StateMachineEvent> > m_queuedEvents;  // 0x50
    int m_queued_events_time;  // 0x64
    StateMachine *m_linkedStateMachine;  // 0x68
    ActorState *m_nextStateAfterPrep;  // 0x6C
    static int s_debugY;
    MinionCostume *m_animatedCostume;  // 0x70
    int m_debugOnChangeStateCallCount;  // 0x74
    std::vector<EffectControl *,std::allocator<EffectControl *> > m_currentStateEffectControl;  // 0x78
    static bool s_SM_isBlendingEnabled;
    static float s_SM_bulletTimeTrackTransitionTimePgt;
};

#endif
