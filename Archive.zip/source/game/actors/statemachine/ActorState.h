// source/game/actors/statemachine/ActorState.h
#ifndef SOURCE_GAME_ACTORS_STATEMACHINE_ACTORSTATE_H
#define SOURCE_GAME_ACTORS_STATEMACHINE_ACTORSTATE_H

class ActorState : public State {  // sizeof 0x94
    int GetNextStateIndex(const ActorStateSet*, MinionCostume*);
    static bool CheckTriggerConditions(const StateTrigger*, MinionCostume*);
public:
    ActorState(const StateData*, int);
    virtual ~ActorState();
    virtual const jet::String &SetRandomAnim(int);
    virtual void RefreshData();
    bool HasInputTrigger(int, int);
    bool HasEngineTrigger(int);
    bool HasScreenTrigger(int, int);
    void GetStretchTime(float&, float&, jet::anim::Animation*);
    bool CheckFlags(unsigned);
    bool CheckAllFlags(unsigned);
    bool IsSelector();
    ActorState *GetSelectedState(const ActorStateSet*, int);
    bool IsIdleState();
    bool IsAttackInitState();
    bool IsAttackState();
    bool IsAttackEndState();
    bool IsStunnedHitState();
    bool IsStunnedState();
    bool IsAnyStunnedState();
    bool IsAppearState();
    bool IsDisappearState();
    bool IsDieState();
    bool IsDeadState();
    bool IsAnyDeadState();
    bool IsWalkInitState();
    bool IsWalkState();
    bool IsRunState();
    bool IsAnyWalkRunState();
    bool IsLandingState();
    bool IsJumpInitState();
    bool IsJumpState();
    bool IsJumpEndState();
    bool IsFallingState();
    bool IsFallingInitState();
    bool IsGravityState();
    bool IsAnyJumpingState();
    bool IsDashDownState();
    bool IsFreeFallState();
    bool IsSafeLandingState();
    bool IsRideInitState();
    bool IsRocketInitState();
    bool IsMountInitState();
    bool IsRideEngageState();
    bool IsRocketEngageState();
    bool IsMountEngageState();
    bool IsRideDisengageState();
    bool IsRocketDisengageState();
    bool IsMountDisengageState();
    bool IsRideEndState();
    bool IsRocketEndState();
    bool IsMountEndState();
    bool IsRideRunState();
    bool IsAnyRideState();
    bool IsRocketLeftState();
    bool IsRocketRightState();
    bool IsRideDodgeState();
    bool IsRideDodgeLeftState();
    bool IsRideDodgeRightState();
    bool IsDodgeLeftState();
    bool IsDodgeRightState();
    bool IsDodgeDoubleLeftState();
    bool IsDodgeDoubleRightState();
    bool IsGroundDodgeLeftState();
    bool IsGroundDodgeRightState();
    bool IsAirDodgeLeftState();
    bool IsAirDodgeRightState();
    bool IsDespicableInitState();
    bool IsDespicableEndState();
    bool IsDespicableEndToSledgeState();
    bool IsAnyDespicableEndState();
    bool IsSledgeInitState();
    bool IsAnySledgeInitState();
    bool IsSledgeEndState();
    bool IsSlideState();
    bool IsCrashState();
    bool IsCrashBounceScreenState();
    bool IsAnyCrashState();
    bool IsBossMeenaChangeLaneState();
    bool IsBossMeenaRamState();
    bool IsBossMeenaBackState();
    bool IsBossMeenaWarningState();
    bool IsBossMeenaWaitState();
    bool IsBossMeenaAnyRamState();
    bool IsBossMeenaHittedState();
    bool IsBossEntranceState();
    bool IsFastForwardState();
    bool IsReviveState();
    bool IsShadowState();
    void GetSubstringName(char*, const char*, const char*, char, int, int);
    int GetStateId();
    short GetTotalTime();
    static const unsigned k_flag_None;
    static const unsigned k_flag_IsAttack;
    static StateTypeFlagDefinition k_stateTypeDefinitions[0];
    short m_index;  // 0xC
    unsigned m_stateTypeFlags;  // 0x10
    short m_animStartTime;  // 0x14
    short m_animEndTime;  // 0x16
    short m_loopStartTime;  // 0x18
    short m_loopEndTime;  // 0x1A
    short m_blendTime;  // 0x1C
    bool m_loop;  // 0x1E
    short m_loopCount;  // 0x20
    float m_animSpeed;  // 0x24
    bool m_allowDodgeByInput;  // 0x28
    bool m_isCinematicCameraEnabled;  // 0x29
    short m_cinematicCamTransition;  // 0x2A
    std::vector<AttackConfig *,std::allocator<AttackConfig *> > m_attackConfig;  // 0x2C
    std::vector<SoundConfig *,std::allocator<SoundConfig *> > m_soundConfig;  // 0x40
    std::vector<EffectConfig,std::allocator<EffectConfig> > m_effectConfig;  // 0x54
    short m_type;  // 0x68
    short m_label;  // 0x6A
    const StateTrack *m_attackTrack;  // 0x6C
    const StateTrack *m_collisionEffectTrack[3];  // 0x70
    const StateTrack *m_giantScaleTrack;  // 0x7C
    const StateTrack *m_bulletTimeTrack;  // 0x80
    const jet::String *m_dirBlendR;  // 0x84
    const jet::String *m_dirBlendL;  // 0x88
    int m_selector_RepeatBehavior;  // 0x8C
    unsigned m_selector_lastSelected;  // 0x90
};

#endif
