// source/game/actors/statemachine/StateDatabase.cpp
#include "StateDatabase.h"
#include "stream/streammgr.h"
#include "stream/istream.h"
#include <cstring>

StateDatabase *StateDatabase::GetInstance() {
    static StateDatabase s_instance;
    return &s_instance;
}

int StateData::GetParam(const char *n, int def) const {
    for (unsigned i = 0; i < params.size(); i++)
        if (params[i].name.Equals(n)) return params[i].value;
    return def;
}
const StateTrack *StateData::FindTrack(unsigned anim, const char *n) const {
    if (anim >= anims.size()) return 0;
    for (unsigned i = 0; i < anims[anim].tracks.size(); i++)
        if (anims[anim].tracks[i].name.Equals(n)) return &anims[anim].tracks[i];
    return 0;
}
int StateSetData::FindStateIdxByName(const jet::String &n) const {
    for (unsigned i = 0; i < states.size(); i++)
        if (states[i].name.Equals(n)) return (int)i;
    return -1;
}

static void Read(jet::stream::IStream &s, StateTrigger &t) {
    for (int i = 0; i < 6; i++) s >> t.values[i];
    bool named = false;
    s >> named;
    if (named) s >> t.target;
    unsigned short n = 0;
    s >> n;
    t.conditions.resize(n);
    for (unsigned i = 0; i < n; i++) s >> t.conditions[i].name >> t.conditions[i].value;
}

static void Read(jet::stream::IStream &s, StateTrack &t) {
    s >> t.name;
    unsigned short n = 0;
    s >> n;
    t.events.resize(n);
    for (unsigned i = 0; i < n; i++) {
        StateEvent &e = t.events[i];
        int count = 0;
        s >> e.time >> e.type >> count;
        e.args.resize(count > 0 ? count : 0);
        for (int k = 0; k < count; k++) s >> e.args[k];
        bool named = false;
        s >> named;
        if (named) s >> e.name;
    }
    s >> t.end;
}

static void Read(jet::stream::IStream &s, StateData &d) {
    s >> d.name;
    s >> d.isSelector;
    unsigned short n = 0;
    if (d.isSelector) {
        s >> n;
        d.entries.resize(n);
        for (unsigned i = 0; i < n; i++) {
            SelectorEntryData &e = d.entries[i];
            s >> e.name >> e.a;
            s.Read(&e.weight, 4);
            s >> e.b;
        }
    }
    s >> n;
    d.params.resize(n);
    for (unsigned i = 0; i < n; i++) s >> d.params[i].name >> d.params[i].value;
    s >> n;
    d.triggers.resize(n);
    for (unsigned i = 0; i < n; i++) Read(s, d.triggers[i]);
    if (d.isSelector) return;
    s >> n;
    d.anims.resize(n);
    for (unsigned i = 0; i < n; i++) {
        StateAnim &a = d.anims[i];
        s >> a.name >> a.set;
        unsigned short tracks = 0;
        s >> tracks;
        a.tracks.resize(tracks);
        for (unsigned k = 0; k < tracks; k++) Read(s, a.tracks[k]);
    }
    s >> n;
    d.animSets.resize(n);
    for (unsigned i = 0; i < n; i++) s >> d.animSets[i].name >> d.animSets[i].first >> d.animSets[i].count;
}

bool StateDatabase::Load(const jet::String &name) {
    jet::stream::IStream *sp = jet::stream::StreamMgr::GetInstance().CreateStream(name);
    if (!sp) return false;
    jet::stream::IStream &s = *sp;
    s.Start();
    unsigned short sets = 0;
    s >> sets;
    m_sets.resize(sets);
    for (unsigned i = 0; i < sets; i++) {
        StateSetData &set = m_sets[i];
        s >> set.name;
        unsigned short params = 0;
        s >> params;
        for (unsigned k = 0; k < params; k++) {
            int v = 0;
            jet::String skipped;
            s >> v >> skipped;
        }
        unsigned short states = 0;
        s >> states;
        set.states.resize(states);
        for (unsigned k = 0; k < states; k++) Read(s, set.states[k]);
    }
    bool ok = s.Tell() == s.Size();
    s.Finish();
    delete sp;
    return ok;
}

const StateSetData *StateDatabase::FindStateSetDataByName(const jet::String &n) const {
    for (unsigned i = 0; i < m_sets.size(); i++)
        if (m_sets[i].name.Equals(n)) return &m_sets[i];
    return 0;
}
