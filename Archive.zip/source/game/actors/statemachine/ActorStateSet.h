// source/game/actors/statemachine/ActorStateSet.h
#ifndef SOURCE_GAME_ACTORS_STATEMACHINE_ACTORSTATESET_H
#define SOURCE_GAME_ACTORS_STATEMACHINE_ACTORSTATESET_H

class ActorStateSet : public StateSet {  // sizeof 0x9C
public:
    ActorStateSet(const StateSetData*);
    virtual ~ActorStateSet();
    virtual void Init();
    virtual ActorState *GetState(unsigned);
    ActorState *GetStateFromLabel(int);
    const jet::String &GetStateName(unsigned);
    virtual ActorState *FindStateByName(const jet::String&);
    void InitLabelList();
    static ActorStateSet *GetStateSetFromCollection(const StateSetData*);
    static void ClearStateSetCollection();
    static const int k_stateLabel_max;
private:
    int m_labelStates[34];  // 0x14
    static std::vector<ActorStateSet *,std::allocator<ActorStateSet *> > s_stateSetCollection;
};

#endif
