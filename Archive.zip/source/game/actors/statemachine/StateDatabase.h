// source/game/actors/statemachine/StateDatabase.h
#ifndef SOURCE_GAME_ACTORS_STATEMACHINE_STATEDATABASE_H
#define SOURCE_GAME_ACTORS_STATEMACHINE_STATEDATABASE_H

#include <vector>
#include "core/pstring.h"

namespace jet::stream { class IStream; }

// The actor state machines ("states" datalib; StateDatabase::Load @0x644160,
// StateSetData::Load @0x643e10, StateData::Load @0x6432e4, StateTrack::Load @0x642e90).
// Strings are u16 length + bytes.
//   u16 sets; set: str name, u16 n (s32 + str) pairs, u16 states, states
//   state: str name, u8 selector
//     selector: u16 entries (str, s32, f32, s32), u16 params (str, s32), u16 triggers
//     else: u16 params (str, s32), u16 triggers, u16 anims, u16 animsets (str, s16, s16)
//   trigger: 6 x s32, u8 named [str], u16 conditions (str, s32)
//   anim: str, s16, u16 tracks; track: str, u16 events, s32
//   event: s32, s32, s32 n, n x s32, u8 named [str]
struct StateParam { jet::String name; int value; };
struct StateTriggerCondition { jet::String name; int value; };
struct StateTrigger {
    int values[6];            // event, flags, target..., -1 = evaluated on entry
    jet::String target;       // the state it leads to
    std::vector<StateTriggerCondition> conditions;
};
struct StateEvent { int time; int type; std::vector<int> args; jet::String name; };
struct StateTrack { jet::String name; std::vector<StateEvent> events; int end; };
struct StateAnim { jet::String name; short set; std::vector<StateTrack> tracks; };
struct StateAnimSet { jet::String name; short first; short count; };
struct SelectorEntryData { jet::String name; int a; float weight; int b; };

struct StateData {
    jet::String name;
    bool isSelector;
    std::vector<SelectorEntryData> entries;
    std::vector<StateParam> params;
    std::vector<StateTrigger> triggers;
    std::vector<StateAnim> anims;
    std::vector<StateAnimSet> animSets;
    int GetParam(const char *name, int def = 0) const;
    const StateTrack *FindTrack(unsigned anim, const char *name) const;
};

struct StateSetData {
    jet::String name;
    std::vector<StateData> states;
    int FindStateIdxByName(const jet::String&) const;
};

class StateDatabase {
public:
    static StateDatabase *GetInstance();
    bool Load(const jet::String &name);
    const StateSetData *FindStateSetDataByName(const jet::String&) const;
    unsigned GetStateSetCount() const { return (unsigned)m_sets.size(); }
private:
    std::vector<StateSetData> m_sets;
};

#endif
