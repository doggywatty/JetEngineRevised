// source/game/online/store/Price.h
#ifndef SOURCE_GAME_ONLINE_STORE_PRICE_H
#define SOURCE_GAME_ONLINE_STORE_PRICE_H

class Price : public GameEntity {  // sizeof 0xE0
public:
    Price(const clara::Template*);
    virtual ~Price();
    virtual void PostInit();
    void SetPriceType(safe_enum<EPriceTypeDef,enum EPriceTypeDef::type>);
    void SetPrice(double);
    void SetRegularPrice(double);
    void SetAmount(int);
    void SetRegularAmount(int);
    void SetItemName(const jet::String&);
    void SetItemId(int);
    void SetActive(bool);
    void SetPriceString(const jet::String&);
    void SetRegularPriceString(const jet::String&);
    void SetCurrencyCode(const jet::String&);
    void SetPackId(const jet::String&);
    void AddExtraCategory(const jet::String&);
    jet::String GetItemName();
    jet::String GetCategory();
    int GetExtraCategoryCount();
    jet::String GetExtraCategory(int);
    int GetItemId();
    double GetPriceAsDouble();
    double GetRegularPriceAsDouble();
    jet::String GetPriceAsString();
    jet::String GetPriceAsString();
    jet::String GetRegularPriceAsString();
    jet::String GetRegularPriceAsString();
    bool HasPricePromotion();
    safe_enum<EPriceTypeDef,enum EPriceTypeDef::type> GetPriceType();
    jet::String GetCurrencyCode();
    jet::String GetPackId();
    int GetAmount();
    int GetRegularAmount();
    bool HasAmountPromotion();
    bool IsActive();
    virtual void BuyItem();
    virtual void DeliverIAPItem();
    virtual void Reset();
    static const jet::String k_tmplName;
private:
    jet::String m_category;  // 0x90
    std::vector<jet::String,std::allocator<jet::String> > m_extraCategories;  // 0x94
    int m_itemId;  // 0xA8
    double m_price;  // 0xB0
    double m_regularPrice;  // 0xB8
    safe_enum<EPriceTypeDef,enum EPriceTypeDef::type> m_priceType;  // 0xC0
    int m_amount;  // 0xC4
    int m_regularAmount;  // 0xC8
    jet::String m_priceString;  // 0xCC
    jet::String m_regularPriceString;  // 0xD0
    jet::String m_currencyCode;  // 0xD4
    jet::String m_packId;  // 0xD8
    bool m_isActive;  // 0xDC
    static const jet::String k_paramCategory;
    static const jet::String k_paramValue;
    static const jet::String k_paramCurrency;
    static const jet::String k_paramAmount;
    static const jet::String k_paramAvailable;
};

#endif
