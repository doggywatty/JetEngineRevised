// source/game/online/store/Store.h
#ifndef SOURCE_GAME_ONLINE_STORE_STORE_H
#define SOURCE_GAME_ONLINE_STORE_STORE_H

class Store : public Singleton<Store> {  // sizeof 0x78
public:
    Store();
    virtual ~Store();
    void Init();
    bool IsInitialized();
    void InitIAPStore();
    void Update();
    void Refresh(int);
    void AddDynamicPriceToDB(Price*);
    void AddIAPPriceToDB(Price*);
    Price *GetIAPItem(const jet::String&);
    Price *GetDynamicItem(const jet::String&);
    bool BuyItem(const jet::String&);
    bool GenerateCustomerCareLink(const std::basic_string<char,std::char_traits<char>,std::allocator<char> >&, const std::basic_string<char,std::char_traits<char>,std::allocator<char> >&, std::basic_string<char,std::char_traits<char>,std::allocator<char> >&, gaia::BaseServiceManager::Credentials);
    bool HasIAPPromotion();
    bool HasDynamicPromotion();
    jet::String GetIAPPromotionDescription();
    int GetIAPPromotionRemainingTime();
    bool HasPromotionOnCategory(const jet::String&);
    jet::String GetDynamicPricingPromotionName();
    int GetDynamicPricingPromotionRemainingTime();
    bool HasAnyPromotion();
    bool IsIAPPurchaseInProgress();
    int GetBananasPriceInTokens(int);
    void UpdateOfflineItemsCRM();
    void SetTrackingPurchaseType(TRACKING_PURCHASE_TYPE);
    void SetTrackingPurchaseLocation(TRACKING_SCREEN);
    void SetTrackingPurchaseRedirection(TRACKING_SCREEN);
private:
    void OnDynamicPricingUpdated(boost::shared_ptr<Event>);
    void OnIAPUpdated(boost::shared_ptr<Event>);
    void OnIAPItemBought(boost::shared_ptr<Event>);
    static void sOnOfflineStoreInitialized();
    static void sOnHestiaConfigUpdated(gaia::OpCodes, const std::basic_string<char,std::char_traits<char>,std::allocator<char> >&, int, void*);
    static void sHestiaCallback();
    bool m_isInitialized;  // 0x4
    std::map<jet::String,Price *,std::less<jet::String>,std::allocator<std::pair<jet::String const ,Price *> > > m_dynamicPrices;  // 0x8
    std::map<jet::String,Price *,std::less<jet::String>,std::allocator<std::pair<jet::String const ,Price *> > > m_iapPrices;  // 0x24
    unsigned m_iapPromoEndTime;  // 0x40
    unsigned m_dynamicPromoEndTime;  // 0x44
    std::map<jet::String,int,std::less<jet::String>,std::allocator<std::pair<jet::String const ,int> > > m_currencyTypes;  // 0x48
    oi::OfflineStore *m_offlineStore;  // 0x64
    bool m_hasDynamicPromotion;  // 0x68
    bool m_isIAPPurchaseInProgress;  // 0x69
    TRACKING_PURCHASE_TYPE m_purchaseType;  // 0x6C
    TRACKING_SCREEN m_purchaseLocation;  // 0x70
    TRACKING_SCREEN m_purchaseRedirection;  // 0x74
};

#endif
