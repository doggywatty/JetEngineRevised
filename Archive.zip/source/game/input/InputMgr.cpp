// source/game/input/InputMgr.cpp
//
// Port of the player's swipe/touch control scheme. The octant classifiers (GetLineSlideAction8/4) and
// now UpdateSlideActions (the real per-frame touch-tracking state machine, reading TouchMgr -- already
// real in this tree from an earlier session) are fully verified against the disassembly, including every
// boundary-angle/threshold constant and the k_SLIDE_ACTION_* mapping (cross-checked against real .data
// values). LaunchEvents() -- the event-dispatch half, which reads the slide-action bitset this now
// produces and is meant to call into Minion's lane-change/jump/slide methods -- is not ported yet; see
// its own comment below for why and what's needed next.
#include "InputMgr.h"
#include "system.h"
#include "video/display.h"
#include "TouchMgr.h"
#include <cmath>

const float InputMgr::k_SLIDE_MIN_DISTANCE = 28.0f;
const float InputMgr::k_SLIDE_MAX_DISTANCE = 60.0f;
const float InputMgr::k_TOUCH_MAX_DISTANCE = 30.0f;
// Verified: real .data values at each symbol, not assumed from declaration order.
const int InputMgr::k_SLIDE_ACTION_UpDown = 0;
const int InputMgr::k_SLIDE_ACTION_UpRightDownLeft = 1;
const int InputMgr::k_SLIDE_ACTION_RightLeft = 2;
const int InputMgr::k_SLIDE_ACTION_DownRightUpLeft = 3;
const int InputMgr::k_SLIDE_ACTION_DownUp = 4;
const int InputMgr::k_SLIDE_ACTION_DownLeftUpRight = 5;
const int InputMgr::k_SLIDE_ACTION_LeftRight = 6;
const int InputMgr::k_SLIDE_ACTION_UpLeftDownRight = 7;
const int InputMgr::k_MAX_SLIDE_ACTIONS = 8;

float InputMgr::s_minSlideDistance = 0.0f;
float InputMgr::s_maxSlideDistance = 0.0f;
float InputMgr::s_maxTouchDistance = 0.0f;
bool InputMgr::s_isInit = false;

// Verified @0x5045a8: the three k_SLIDE_*_DISTANCE constants are percentages of a 768-unit reference
// width (28/768, 60/768, 30/768 match the real literal pool exactly), scaled by the real screen width and
// squared (so callers compare squared distances, avoiding a sqrt) -- computed once, guarded by s_isInit.
InputMgr::InputMgr()
    : m_tutorialId(), m_tutorialDoneListener(0), m_isEnabled(true), m_enableTouchInteracts(false),
      m_currentTouch(-1), m_touchInitialPos(0, 0), m_touchLastPos(0, 0), m_pressedTime(0), m_oldSlideAction(-1),
      m_upDirection(0), m_keyboardSlideAction(0), m_touched(false), m_touchedPos(0, 0), m_player(0),
      m_ignoreAllSlideActions(false), m_ignoreVerticalSlideActions(false), m_inputRatio(0.0f),
      m_inputRatioCount(0), m_inputRatioLast10Seconds(0.0f), m_inputLast10secCount(0), m_inputLast10secTimeCount(0) {
    Reset();
    if (!s_isInit) {
        s_isInit = true;
        jet::video::Display *disp = jet::System::GetMainDisplay();
        float w = disp ? (float)disp->GetMode().size.x : 768.0f;
        float minD = 28.0f / 768.0f * w, maxD = 60.0f / 768.0f * w, touchD = 30.0f / 768.0f * w;
        s_minSlideDistance = minD * minD;
        s_maxSlideDistance = maxD * maxD;
        s_maxTouchDistance = touchD * touchD;
    }
}

InputMgr::~InputMgr() {}

// Clears per-touch tracking state. Real offsets this reads/writes couldn't be cleanly mapped back to
// this header's field layout one-for-one (same kind of shift seen on other headers this session) --
// reproduced by intent (clear the touch/slide tracking, not a from-scratch guess) rather than by offset.
void InputMgr::Reset() {
    m_currentTouch = -1;
    m_touchInitialPos = math::vec2<float>(0, 0);
    m_touchLastPos = math::vec2<float>(0, 0);
    m_pressedTime = 0;
    m_oldSlideAction = -1;
    m_upDirection = 0;
}

void InputMgr::SetEnabled(bool v) { m_isEnabled = v; }
void InputMgr::SetPlayer(Minion *m) { m_player = m; }
void InputMgr::EnableTouchInteracts(bool v) { m_enableTouchInteracts = v; }
bool InputMgr::IsTouchInteractsEnabled() { return m_enableTouchInteracts; }
void InputMgr::IgnoreAllSlideActions(bool v) { m_ignoreAllSlideActions = v; }
void InputMgr::IgnoreVerticalSlideActions(bool v) { m_ignoreVerticalSlideActions = v; }
float InputMgr::GetInputRatio() { return m_inputRatio; }
float InputMgr::GetInputRatioLast10Seconds() { return m_inputRatioLast10Seconds; }

// Verified @0x4f4fdc: tests bit `action` of the slide-actions bitset.
bool InputMgr::IsSlideAction(int action) { return action >= 0 && action < 8 && m_slideActions.test(action); }

// Verified @0x4f4fd4: the base implementation just returns "no touch action" (-1); real per-touch
// handling (if any override exists) isn't ported.
int InputMgr::GetTouchAction(int) { return -1; }

void InputMgr::OnKeyPressed(int) {}
void InputMgr::OnKeyReleased(int) {}

// Verified @0x504df8: classic 8-octant swipe classifier. angle = atan2f(p2.y - p1.y, p2.x - p1.x),
// normalized to [0, 2*PI), then bucketed into 8 PI/4-wide sectors offset by PI/8 so each named direction
// is centered on its compass angle. Every boundary (PI/8, 3PI/8, 5PI/8, 7PI/8, 9PI/8, 11PI/8, 13PI/8,
// 15PI/8) and the LeftRight/UpLeftDownRight/UpDown/UpRightDownLeft/RightLeft/DownRightUpLeft/DownUp/
// DownLeftUpRight return-value sequence is read directly from the literal pool and cross-checked against
// the real k_SLIDE_ACTION_* data above, not assumed.
int InputMgr::GetLineSlideAction8(const math::vec2<float> &p1, const math::vec2<float> &p2) {
    float dy = p2.y - p1.y, dx = p2.x - p1.x;
    float a = atan2f(dy, dx);
    if (a < 0) a += 6.2831855f;
    if (a >= 5.8904862f || a < 0.3926991f) return k_SLIDE_ACTION_LeftRight;
    if (a < 1.1780972f) return k_SLIDE_ACTION_UpLeftDownRight;
    if (a < 1.9634955f) return k_SLIDE_ACTION_UpDown;
    if (a < 2.7488937f) return k_SLIDE_ACTION_UpRightDownLeft;
    if (a < 3.5342917f) return k_SLIDE_ACTION_RightLeft;
    if (a < 4.3196902f) return k_SLIDE_ACTION_DownRightUpLeft;
    if (a < 5.1050882f) return k_SLIDE_ACTION_DownUp;
    return k_SLIDE_ACTION_DownLeftUpRight;
}

// Verified @0x504f10: same shape, 4 quadrants (boundaries PI/4, 3PI/4, 5PI/4, 7PI/4).
int InputMgr::GetLineSlideAction4(const math::vec2<float> &p1, const math::vec2<float> &p2) {
    float dy = p2.y - p1.y, dx = p2.x - p1.x;
    float a = atan2f(dy, dx);
    if (a < 0) a += 6.2831855f;
    if (a >= 5.4977875f || a < 0.7853982f) return k_SLIDE_ACTION_LeftRight;
    if (a < 2.3561945f) return k_SLIDE_ACTION_UpDown;
    if (a < 3.9269910f) return k_SLIDE_ACTION_RightLeft;
    return k_SLIDE_ACTION_DownUp;
}

// Not ported: tutorial-graph gating isn't needed for the core swipe classifier this pass targets, and
// IsTutorialActionEnabled's real comparison (against an int, while m_tutorialId is the placeholder
// TutorialInputId struct above) can't be faithfully reproduced until that type is verified.
void InputMgr::SetTutorial(InputMgr::TutorialInputId id, InputMgr::TutorialInputListener *l) { m_tutorialId = id; m_tutorialDoneListener = l; }
bool InputMgr::IsTutorialActionEnabled(int) { return true; }
void InputMgr::OnTutorialInputDone(const InputMgr::TutorialInputId &id) { if (m_tutorialDoneListener) m_tutorialDoneListener->OnTutorialInputDone(id); }

// Verified @0x5046e8: if disabled and no tutorial listener is waiting, do nothing; otherwise run the
// slide-action detection then dispatch events. dt is passed straight through to UpdateSlideActions.
void InputMgr::Update(int dt) {
    if (!m_isEnabled && !m_tutorialDoneListener) return;
    UpdateSlideActions(dt);
    LaunchEvents();
}

// Verified @0x50472c against TouchMgr (already real in this tree, ported in an earlier session) --
// this now reads actual queued touch events, not a stub. Per real binary structure: clear this frame's
// slide-action bitset/upDirection/touched flag, bail early (resetting the tracked touch) if there are no
// active touches, otherwise walk each active touch: acquire an untracked Pressed/Dragged touch, update
// the running pressed-time and last-known position for the tracked one, skip touches that haven't moved
// past k_TOUCH_MAX_DISTANCE yet (unless they just released -- a release always finalizes), then if the
// move exceeds k_SLIDE_MIN_DISTANCE classify it with GetLineSlideAction4 and latch the first detected
// action + its vertical direction for the gesture, and if it's still within k_SLIDE_MAX_DISTANCE treat
// the current position as a "touched" point (used for tap/interact, separate from the slide gesture).
// A Released touch always clears the tracked-touch state at the end regardless of distance.
void InputMgr::UpdateSlideActions(int dt) {
    m_slideActions.reset();
    m_upDirection = -1;
    m_touched = false;

    std::vector<const Touch*> touches = TouchMgr::GetInstance()->GetAllActiveTouches();
    if (touches.empty()) {
        m_currentTouch = -1;
        m_pressedTime = 0;
        m_oldSlideAction = -1;
        return;
    }

    for (const Touch *t : touches) {
        bool pressedOrDragged = (t->state & (Touch::Pressed | Touch::Dragged)) != 0;
        if (pressedOrDragged && m_currentTouch == -1) {
            m_currentTouch = t->id;
            m_pressedTime = 0;
            m_touchInitialPos = t->pos;
        }
        float distSq = math::distanceSq(m_touchInitialPos, t->pos);
        m_pressedTime += dt;
        m_touchLastPos = t->pos;

        bool released = (t->state & Touch::Released) != 0;
        if (!released && distSq < s_maxTouchDistance) continue;
        if (m_currentTouch != t->id) continue;

        if (distSq > s_minSlideDistance) {
            int action = GetLineSlideAction4(m_touchInitialPos, t->pos);
            if (action >= 0 && m_oldSlideAction == -1) {
                m_slideActions.set(action);
                m_upDirection = (m_touchInitialPos.y < t->startPos.y) ? k_SLIDE_ACTION_UpDown : k_SLIDE_ACTION_DownUp;
                m_oldSlideAction = action;
            }
            m_pressedTime = 0;
        }
        if (distSq < s_maxSlideDistance) {
            m_touched = true;
            m_touchedPos = t->pos;
        }
        if (released) {
            m_currentTouch = -1;
            m_pressedTime = 0;
            m_oldSlideAction = -1;
        }
    }
}

// Not ported -- 904 bytes, deeply entangled with camera-ray/BodyPartOwner 3D touch-interact hit testing
// (BPO_GetProjectileHit) on top of the slide-action dispatch, a significantly larger subsystem than
// UpdateSlideActions' self-contained touch-tracking math above. Confirmed from the disassembly: it reads
// m_player (null-checks it and returns early if unset -- so SetPlayer(minion) must happen before this
// does anything), checks m_ignoreAllSlideActions and (for vertical slides) m_upDirection/
// IsTutorialActionEnabled before presumably calling into Minion's lane-change/jump/slide methods, which
// this session didn't trace that far. A good next concrete step -- the slide detection feeding it is now
// solid and ready.
void InputMgr::LaunchEvents() {}
void InputMgr::HandleAccelerometer(float, float) {}
void InputMgr::OnSlideAction(int) {}
