// source/game/GameLevel.h
#ifndef SOURCE_GAME_GAMELEVEL_H
#define SOURCE_GAME_GAMELEVEL_H

#include <map>
#include <vector>
#include <unordered_set>
#include "jsingleton.h"
#include "smath.h"
#include "video/color.h"
#include "video/posteffect.h"
#include "core/pstring.h"
#include "core/delayer.h"
#include "core/interputils.h"
#include "gameenums.h"
#include "leveltemplate/LevelTemplateMgr.h"
#include "leveltemplate/leveltemplatesequenceprovider.h"

namespace jet::scene { class Camera; class SceneMgr; }
namespace jet::stream { class IStream; }
namespace clara { class DataEntity; class Entity; }
class GameEntity;
class LevelDef;
class LuaVM;
class CameraMgr;
class CameraController;
class MaterialDef;
class Minion;
class ControlledRandom;
class LevelSequenceGraphMgr;
class Pacesetter;

// The loaded level: the entities it updates and renders each frame, the world and menu scene managers they draw
// into, the camera, the Lua machine of its scripts, the fog and the post effect; Render() is the frame.
// Not ported yet (they come with the gameplay): the level sequence, the pacesetter and templates, the managers
// that reset with a new level, the cinematic camera, physics, effects, flares and trails.
class GameLevel : public Singleton<GameLevel>, public LevelTemplateSequenceProvider {  // sizeof 0x690
public:
    enum SceneMgrId { SceneMgr_World = 0, SceneMgr_Menu = 1 };
    explicit GameLevel(bool isMovieLevel);
    virtual ~GameLevel();

    // the clara files of the level: libraries first (when none are loaded), then the level files
    void Load(const std::map<jet::String, jet::stream::IStream*> &libs, const std::map<jet::String, jet::stream::IStream*> &levels);
    // the script machine, once
    void Init();
    void PostInit();
    void Update(bool fullUpdate);
    void Render();

    // entities as the creator makes them: the ones the level keeps by their kind
    void EntityCreated(clara::DataEntity*);
    void RegisterForUpdate(GameEntity*, bool);
    void RegisterForRender(GameEntity*, bool);
    void RegisterVolatileEntity(GameEntity*, bool);
    // entities whose model animates this frame: entity, animation name, node count (@0x51463c)
    struct Animable { GameEntity *entity; jet::String animation; int nodeCount; };
    void AddAnimatedEntity(GameEntity*, const jet::String &animation, int nodeCount);
    const std::vector<Animable> &GetAnimatedEntities() const { return m_animatedEntities; }
    // how far the player has run: the base of "pending to delete" entities going out of the scene
    unsigned GetPlayerDistance() const { return m_playerDistance; }
    void SetPlayerDistance(unsigned d) { m_playerDistance = d; }

    LevelDef *GetLevelDef() const { return m_levelDef; }
    void SetLevelDef(LevelDef *l) { m_levelDef = l; }
    LuaVM *GetLuaVM() const { return m_luaVM; }
    void SetLuaVM(LuaVM *v) { m_luaVM = v; }
    Minion *GetMinion() const { return m_minion; }
    clara::DataEntity *GetFluffyGameplay() const { return m_fluffyGameplay; }
    clara::DataEntity *GetGameplayDef() const { return m_gameplayDef; }
    void SetLoadingLibs(bool b) { m_loadingLibs = b; }
    bool IsLoadingLibs() const { return m_loadingLibs; }
    CameraMgr *GetCameraMgr() const { return m_cameraMgr; }
    // the entity is a level camera (Lua SetCamera only takes those) (@0x519738)
    bool IsCamera(const clara::Entity*) const;
    // switches the level to the camera, blending over ms
    void SetCamera(CameraController*, unsigned ms);

    // fog: on / off, colour and depths, each switching over a time in ms (@0x518654, 0x5186a0, 0x5187bc)
    void SetFog(bool on, unsigned ms);
    void SetFogColor(const jet::video::Color &c, unsigned ms);
    void SetFogDepth(float start, float end, unsigned ms);
    bool GetFog() const { return m_fogOn.GetTargetValue() > 0.0f; }
    void GetFogColor(jet::video::Color &c) const { c = jet::video::Color(m_fogColor.GetTargetValue().x, m_fogColor.GetTargetValue().y, m_fogColor.GetTargetValue().z, m_fogColor.GetTargetValue().w); }
    void GetFogDepths(float &start, float &end) const { start = m_fogDepthTo[0]; end = m_fogDepthTo[1]; }
    void RenderFog();

    // the post effect of the level: now, or faded to over fadeOutMs / holdMs / fadeInMs through a technique
    void SetCurrentPostEffect(jet::video::PostEffect*);
    void SetCurrentPostEffect(MaterialDef*, bool fade, const jet::String &technique, int fadeOutMs, int holdMs, int fadeInMs, jet::core::InterpolationDef::type outInterp,
                              jet::core::InterpolationDef::type inInterp, void (*onDone)());
    void SetPostEffectsEnabled(bool b) { m_postFxEnabled = b; }
    // a material blended in over the level's, counted by its users
    void AddExtraPostEffect(MaterialDef*, jet::core::Delayer<float, jet::core::QuadraticEaseIn>*, unsigned *);
    void RemoveExtraPostEffect(MaterialDef*);
    static const jet::String k_fadeFx_defaultTechnique;
    static const jet::String k_fadeFx_glowTechnique;

    // what the gameplay state gives the level while it exists (it sets s_gameplay)
    struct GameplayHooks {
        virtual ~GameplayHooks() {}
        virtual int GetMode() const = 0;  // 1: the fluffy dimension
        virtual void ApplySoundSettings(jet::String *ambience, jet::String *music) = 0;
        virtual void SetCurrentMusicGain(float) = 0;
        virtual void SetGameplaySoundGain(float) = 0;
        // the dynamic libraries of a location are loaded: the loading panel goes
        virtual void OnLocationTransitionLoadingFinished() = 0;
    };
    static GameplayHooks *s_gameplay;
    bool IsGameplayStateCreated() const { return s_gameplay != 0; }
    bool IsFluffyMode() const { return s_gameplay && s_gameplay->GetMode() == 1; }
    void SetSound(jet::String *ambience, jet::String *music);
    void SetCurrentMusicGain(float g);
    void SetGameplaySoundGain(float g) { if (s_gameplay) s_gameplay->SetGameplaySoundGain(g); }
    // how many entities of a template are made at a time (all while negative)
    int GetEntityToSpawnCount() const { return m_entityToSpawnCount; }
    Pacesetter *GetPacesetter() const { return m_pacesetter; }
    LevelTemplateMgr *GetLevelTemplateMgr() const { return m_levelTemplateMgr; }
    void OnLocationChanged(int from, int to);
    void OnLocationTransitionLoadingFinished() { if (s_gameplay) s_gameplay->OnLocationTransitionLoadingFinished(); }
    int GetGameplayMode() const { return s_gameplay ? s_gameplay->GetMode() : -1; }
    // the run: the graph of the location, the level templates, the loaded dynamic libraries
    void LoadLevelSequence(const jet::String &firstGraph);
    void InitLevelStructure();
    void UpdateUsedDynamicLibraries();
    void DestroyGraphMgr();
    bool IsNodeOnSpecialTree(const jet::String &id) const;
    int GetFinalBifurcation() const;
    void OnTutorialCompleted() { m_tutorialCompleted = true; }
    // LevelTemplateSequenceProvider
    virtual void IncSequenceNumber();
    virtual int GetNextSequenceNumber();
    virtual GameEntity *GetNextCamera();
    virtual int GetNextCameraTransitionTime();
    virtual const SpeedDef *GetNextSpeed();
    virtual const jet::String &GetNextLocation();
    virtual const jet::String &GetNextNodeLabel();
    virtual const jet::String &GetNextNodeId();
    virtual int GetNextNodeGraphId();
    virtual void OnNodeCompleted(const int &graphId, const jet::String &nodeId);

    void RemoveEntities();
    void UpdateEntities();
    void DeleteEntityLater(GameEntity *e) { m_entitiesToDelete.insert(e); }
    void UpdateEntitiesDeletion(bool all);
    static void DeleteVolatileEntities(bool all);
    void RenderSceneMgrs();
    void UpdateCamera(int dt, bool cinematicPass);
    math::vec4<float> GetClearColor();
    jet::scene::Camera *GetCamera() { return m_camera; }
    void SetCamera(jet::scene::Camera *c) { m_camera = c; }
    bool IsMovieLevel() const { return m_isMovieLevel; }
    bool IsUpdatingEntities() const { return m_updatingEntities; }
    static jet::scene::SceneMgr *GetSceneMgr(SceneMgrId id) { return GetInstance()->m_sceneMgr[id]; }
    static jet::scene::SceneMgr *GetMenuSceneMgr() { return GetInstance()->m_sceneMgr[SceneMgr_Menu]; }
    // the tag shadow models are drawn with (Game::k_shadowTagName)
    static const jet::String &GetShadowTagName();
    static float s_cameraFar;
    // [0] the level's, [1] the spawn probabilities', [2] the decos' and [3] a fourth one, the others reseeded from [0]
    static ControlledRandom *s_randomizer[4];
    static LevelSequenceGraphMgr *s_levelSequenceGraphMgr;
    // every entity appears whatever its probability (a cheat)
    static bool s_allProbabilityMode;
private:
    void InitRender();
    void EndRender() {}
    void RenderEntities();
    void RenderParticles();
    void RenderGUI();
    void RenderPostEffectStart();
    void RenderPostEffectEnd();
    void UpdatePostEffectTransition(std::vector<jet::video::PostEffect*> &out);
    struct ExtraPostFx { jet::video::PostEffect *effect; MaterialDef *def; int users; jet::core::Delayer<float, jet::core::QuadraticEaseIn> *delayer; unsigned *time; };
    std::vector<GameEntity*> m_volatileEntities;  // 0x6C
    std::vector<GameEntity*> m_entitiesToUpdate;  // 0x78
    std::vector<GameEntity*> m_entitiesToRender;  // 0x84
    std::vector<GameEntity*> m_entitiesToUpdateBackup;  // 0x90
    std::vector<GameEntity*> m_entitiesToRenderBackup;  // 0x9C
    std::vector<GameEntity*> m_entitiesToRemoveFromUpdate;  // 0xA8
    std::vector<GameEntity*> m_entitiesToRemoveFromRender;  // 0xB4
    std::unordered_set<GameEntity*> m_entitiesToDelete;  // 0xC0
    bool m_updatingEntities;  // 0xD8
    Minion *m_minion;  // 0x20C
    Pacesetter *m_pacesetter;  // 0x210
    LevelTemplateMgr m_templateMgr;  // 0xE0
    LevelTemplateMgr *m_levelTemplateMgr;  // 0x1B0
    bool m_tutorialCompleted;  // 0x260
    int m_entityToSpawnCount;  // 0x630
    clara::DataEntity *m_fluffy, *m_rocket, *m_launcher, *m_gameplayDef;  // 0x228, 0x22C, 0x230, 0x238
    clara::DataEntity *m_largeMinionGameplay, *m_fluffyGameplay, *m_rocketGameplay;  // 0x43C, 0x440, 0x444
    LevelDef *m_levelDef;  // 0x234
    LuaVM *m_luaVM;  // 0x23C
    bool m_loadingLibs;  // 0x240
    bool m_initDone;  // 0x69
    // the post effect
    MaterialDef *m_postFxMaterial;  // 0x2DC
    jet::video::PostEffect *m_postEffect;  // 0x2E0
    int m_fadeState;  // 0x2E4: 0 fading in, 1 none, 2 fading out, 3 holding, 4 and 5 mixing the level's effect in and out
    jet::video::PostEffect *m_nextPostEffect;  // 0x2E8
    jet::video::PostEffect *m_fadeFx;  // 0x2EC
    float m_fadeT, m_fadeInTime, m_fadeHoldTime, m_fadeOutTime;  // 0x2F0, 0x2F4, 0x2F8, 0x2FC
    int m_fadeInInterp, m_fadeOutInterp;  // 0x300, 0x304
    bool m_postFxEnabled;  // 0x308
    void (*m_postFxDone)();  // 0x30C
    std::vector<ExtraPostFx> m_extraPostFx;  // 0x310
    jet::core::Delayer<float, jet::core::SmoothStep> m_fogOn;  // 0x320
    jet::core::Delayer<math::vec4<float>, jet::core::SmoothStep> m_fogColor;  // 0x338
    float m_fogDepth[2], m_fogDepthFrom[2], m_fogDepthTo[2];  // 0x37c 0x374 0x384
    int m_fogDepthTime, m_fogDepthElapsed;  // 0x38c 0x390
    bool m_fogDepthAnim;  // 0x394
    jet::scene::Camera *m_camera;  // 0x3AC
    jet::scene::SceneMgr *m_sceneMgr[2];  // 0x3B0
    CameraMgr *m_cameraMgr;
    std::vector<Animable> m_animatedEntities;  // 0x618
    unsigned m_playerDistance;
    bool m_isMovieLevel;  // 0x66C
};

#endif
