// source/game/Game.h
#ifndef SOURCE_GAME_GAME_H
#define SOURCE_GAME_GAME_H

#include <functional>
#include <memory>
#include <set>
#include <vector>
#include <boost/shared_ptr.hpp>
#include "application.h"
#include "core/delayer.h"
#include "jsingleton.h"
#include "smath.h"
#include "stream/istreamfactory.h"
#include "stream/ifilesystem.h"
#include "video/rendertarget.h"
#include "CGameConfig.h"
#include "localization/lang.h"
#include "GFXConfig.h"

namespace jet::scene { class Camera; class SceneMgr; class ModelBase; }
namespace clara { class DataEntity; class Movie; class Group; class Folder; }
class GameLevel;

// The game application: its file systems, the managers every state shares, and the frame loop that updates the
// current state in fixed steps and renders it. Not ported yet: the online services (Gaia, social, DLC, tracking,
// store), the sound manager, the save game, the popup/waiting-screen/cheat managers and the menu music.
class Game : public jet::Application, public Singleton<Game> {  // sizeof 0x810
public:
    Game();
    virtual ~Game();
    virtual void OnDisplayAttached(unsigned);
    virtual void OnDisplayDetached(unsigned);
    virtual void Init();
    virtual void Shutdown();
    virtual void OnUpdate();
    void PostInit();
    // the fonts of the language: the device policy and the GUI fonts (@0x50a39c)
    void LoadFonts(babel::Lang);
    void PostInitRefreshGFX();
    // the frame: a step of the simulation, and the drawing of the state
    void FrameUpdate(unsigned dt);
    void FrameRender();
    // called with every finished frame before it is shown (a host that captures frames uses it)
    void SetFrameDoneCallback(std::function<void()> f) { m_frameDone = f; }
    // host input
    void OnPointerPressed(int id, int x, int y);
    void OnPointerDragged(int id, int x, int y);
    void OnPointerReleased(int id, int x, int y);
    void OnPointerCancelled(int id, int x, int y);
    void OnKeyPressed(int);
    void OnKeyReleased(int);

    // the game's own time: the speed it runs at, easing to target over ms and holding it for hold ms (-1 for ever)
    void SetTimeSpeed(float target, int transitionMs, int holdMs, std::function<void()> onDone = nullptr);
    float GetTimeSpeed() const { return m_timeSpeed.GetCurrentValue(); }
    bool IsTimeSpeedChanging() const { return m_timeSpeed.IsUpdating(); }
    float GetUpdateTimeNotScaled() const { return 1000.0f / (float)m_updateStep; }
    int GetUpdateStep() const { return m_updateStep; }
    int GetUpdateCounter() const { return m_updateCounter; }
    int GetRenderCounter() const { return m_renderCounter; }

    // file systems: the archives added come first, then the paths
    void AddZipFileSystem(const jet::String &path);
    std::shared_ptr<jet::stream::IStreamFactory> FileSystem_AddPath(const jet::String &path, const jet::String &ext);
    std::shared_ptr<jet::stream::IStreamFactory> FileSystem_AddPathInFront(const jet::String &path, const jet::String &ext);
    std::shared_ptr<jet::stream::IStreamFactory> FileSystem_CreateStreamFactoryFromPath(const jet::String &path, const jet::String &ext);
    bool FileSystem_IsFile(const jet::String &path);
    bool FileSystem_IsDirectory(const jet::String &path);
    jet::stream::IStream *FileSystem_CreateStreamFromPath(const jet::String &path);
    // adds name -> game version to the launch parameters
    void SetGameParam(const jet::String &name, const jet::String &file);

    // the display variants of an entity, movie, group or folder: the same name with each device suffix added
    const std::vector<jet::String> &GetDeviceGFXSuffixes() const { return m_gfx->suffixes; }
    clara::DataEntity *GetDeviceSpecificEntity(clara::DataEntity*);
    clara::DataEntity *GetDeviceSpecificEntity(const jet::String &name);
    clara::Movie *GetDeviceSpecificMovie(clara::Movie*);
    clara::Group *GetDeviceSpecificGroup(clara::Group*);
    clara::Folder *GetDeviceSpecificFolder(clara::Folder*);

    // the horizontal fov of a vertical one on this display
    float GetHFovFor(float fovY, bool useDesignRatio) const;
    // road curvature shader parameters, eased over ms
    void SetCurvatureParams(const math::vec2<float>&, unsigned ms);
    math::vec2<float> GetCurvatureParams() const { return m_curvature; }

    // shadow maps
    void InitShadowMapData();
    void RenderShadowMap(jet::scene::SceneMgr*);
    static const jet::String &GetShadowTagName();
    const jet::String &GetAppVersionName() const { return m_versionName; }

    const PlatformToggles &GetPlatformToggles() const { return CGameConfig::Current(); }
    const GFXConfigStruct *GetGFXConfig() const { return m_gfx; }
    GFXConfig *GetGFXConfigData() { return m_gfxConfig; }
    bool IsPaused() const { return m_paused; }
    void SetPaused(bool p) { m_paused = p; }
    // Not in the PDB header -- GS_Pause::GS_Pause()/UpdateState() call Game::StopMenuMusic()/
    // GetMenuMusic()/PlayMenuMusic(const jet::String&) (verified @0x5039d4/0x503a98/0x503ac4), but there
    // is no SoundMgr class anywhere in this tree (the earlier sound work this session was the Musepack
    // codec, not an engine-level sound manager), so these only track a handle, they don't play anything.
    int GetMenuMusic() const { return m_menuMusic; }
    void PlayMenuMusic(const jet::String&) { m_menuMusic = 0; }
    void StopMenuMusic() { m_menuMusic = -1; }
    // Not in the PDB header. Verified @0x4fc6d4 (GS_Gameplay::UpdateState): a mutex-guarded bool on the
    // Game instance, set from elsewhere (likely a native pause-button/lifecycle callback on another
    // thread -- not traced this session, nothing in this tree generates that callback yet) and consumed
    // once by GS_Gameplay to push GS_Pause. No real mutex here since nothing in this tree sets the flag
    // from another thread yet; add one if/when that callback is wired up.
    void RequestPause() { m_pauseRequested = true; }
    bool ConsumePauseRequest() { bool v = m_pauseRequested; m_pauseRequested = false; return v; }
    // Verified @0x4fc720 (tail call at the end of the same block): also not in the PDB header. Real
    // meaning ("go to in-game-menu"?) not confirmed -- just bookkeeping for now, nothing reads it yet.
    void SetGoToIGM(bool b) { m_goToIGM = b; }
    bool IsInActionPhase() const { return m_isInActionPhase; }
    void SetIsInActionPhase(bool b) { m_isInActionPhase = b; }
    bool IsInLoadingPhase() const { return m_isInLoadingPhase; }
    void SetIsInLoadingPhase(bool b) { m_isInLoadingPhase = b; }
    bool IsGameplayStarted() const { return m_gameplayStarted; }
    void SetGameplayStarted(bool b) { m_gameplayStarted = b; }
    bool IsCinematic() const { return m_isCinematic; }
    void SetIsCinematic(bool b) { m_isCinematic = b; }
    bool GetPaintGUI() const;
    void SetPaintGUI(bool);
    // what the game was started to do: 0 the main menu, 1 .. 8 a level (the data's start modes)
    int GetStartMode() const { return m_startMode; }
    void SetStartMode(int m) { m_startMode = m; }
    // the fraction of the shadow map size and the downsampled render target (0 when not used)
    const boost::shared_ptr<jet::video::RenderTarget> &GetShadowRT() const { return m_shadowRT; }
    const boost::shared_ptr<jet::video::RenderTarget> &GetDownsampleRT() const { return m_downsampleRT; }
    jet::scene::Camera *GetShadowCamera() const { return m_shadowCamera; }
    void GoToMainMenu();
    void OnMainMenuLoaded();
    // what is in memory for the level is released (@0x50cdec)
    static void OnUnloadClaraData();
    // the loading screen is up (as GS_Loading sets it)
    void SetLoadingScreen(bool b) { m_loadingScreen = b; }
    bool IsLoadingScreen() const { return m_loadingScreen; }
    void SetDisplayedInitialScreens(bool b) { m_showingInitialScreens = b; }
    bool IsShowingInitialScreens() const { return m_showingInitialScreens; }
    void SetWaitingForLoad(bool b) { m_waitingForLoad = b; }
    bool IsWaitingForLoad() const { return m_waitingForLoad; }
    static const unsigned k_maxUpdates = 10;
    static const unsigned k_updateTime = 17;
    // the platform models of randomized templates stay loaded until the level goes
    void AddRandomizerModel(const boost::shared_ptr<jet::scene::ModelBase> &m) { m_randomizerModels.insert(m); }
    void FreeRandomizerModels();
    // whether the data of a location is there (the first and third ones are part of the game; the revival keeps the others as plain data)
    bool HasDLCDataFor(int location, bool addPath);
    unsigned GetStartDistance() const { return m_startDistance; }
    void SetStartDistance(unsigned d) { m_startDistance = d; }
private:
    void ApplyGameSettings();
    std::set<boost::shared_ptr<jet::scene::ModelBase>> m_randomizerModels;  // 0x564
    std::vector<std::shared_ptr<jet::stream::IFileSystem>> m_zipFileSystems;  // 0x540
    GFXConfig *m_gfxConfig;  // 0x450
    const GFXConfigStruct *m_gfx;  // 0x454
    float m_designWidthScale;  // 0x408
    jet::String m_versionName;
    // the frame loop
    long long m_lastTime;  // 0x300
    int m_updateStep;  // 0x308
    int m_scaledStep;  // 0x2fc
    int m_updateCounter, m_renderCounter;  // 0x38c, 0x390
    bool m_paused;  // 0x318
    int m_menuMusic = -1;  // not in the PDB header, see GetMenuMusic() above
    bool m_pauseRequested = false;  // not in the PDB header, see RequestPause() above
    bool m_goToIGM = false;  // not in the PDB header, see SetGoToIGM() above
    bool m_oneUpdateOnly;  // 0x319
    bool m_keepPending;  // 0x31a
    jet::core::Delayer<float, jet::core::SmoothStep> m_timeSpeed;  // 0x31c
    float m_debugTimeRatio;  // 0x334
    int m_timeSpeedHold;  // 0x338
    std::function<void()> m_timeSpeedDone;  // 0x33c
    // what state of the game this is
    bool m_isInActionPhase;  // 0x41b
    bool m_isInLoadingPhase;  // 0x41d
    bool m_isCinematic;  // 0x41c
    bool m_gameplayStarted;  // 0x424
    bool m_loadingScreen;  // 0x41a
    bool m_showingInitialScreens;  // 0x2b2
    bool m_waitingForLoad;
    std::function<void()> m_frameDone;
    int m_startMode;  // 0x2f4
    unsigned m_startDistance;  // 0x350: where a run starts, 0 for the beginning
    // road curvature
    math::vec2<float> m_curvature, m_curvatureFrom, m_curvatureTo;  // 0x434, 0x42c, 0x43c
    int m_curvatureTime, m_curvatureElapsed;  // 0x444, 0x448
    bool m_curvatureAnim;  // 0x44c
    // shadow map
    boost::shared_ptr<jet::video::RenderTarget> m_shadowRT, m_downsampleRT;  // 0x550, 0x55c
    jet::scene::Camera *m_shadowCamera;  // 0x558
};

#endif
