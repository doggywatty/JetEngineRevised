// source/game/CGameConfig.cpp
#include "CGameConfig.h"
#include "video/driver.h"
#include <json/json.h>
#include <strings.h>

static void ApplyToggles(const Json::Value &p, PlatformToggles &t) {
    if (!p.isObject()) return;
#define INT(k) if (p.isMember(#k)) t.k = p[#k].asInt()
#define FLT(k) if (p.isMember(#k)) t.k = (float)p[#k].asDouble()
#define BOOL(k) if (p.isMember(#k)) t.k = p[#k].asInt() != 0
    INT(textureStartLOD); FLT(size); FLT(downsamplePercent); INT(msaa); BOOL(usePostFX);
    INT(defaultTextureFiltering); INT(useShadows); BOOL(useLowMaterials); BOOL(useLowModels);
    BOOL(useLowParticles); BOOL(hideOptionalDecos); FLT(decoGenerationGroupAllowedDecosLerp);
    BOOL(useSpecularMask); BOOL(useRimLight); BOOL(useCurvature); BOOL(useLinearSpace);
    BOOL(useSpecularLight); BOOL(useEmissiveness); BOOL(useBarla); BOOL(useNdis); BOOL(forceRoadShader);
    BOOL(useIngameUITextEffect); BOOL(useUIDespicableScoreParticles); INT(maxOutline);
    FLT(backgroundFarPlane); FLT(decosAnimationRadius); FLT(sceneMgrCullingDistance);
    FLT(sceneMgrCullingRadius); FLT(sceneMgrCullingScreenPixels);
    if (p.isMember("useCheapNdis")) t.useCheapNdis = p["useCheapNdis"].asInt() != 0;
#undef INT
#undef FLT
#undef BOOL
}

PlatformToggles &CGameConfig::Current() {
    static PlatformToggles t;
    return t;
}

bool CGameConfig::ComputePlatformToggles(const std::string &json, const std::string &device, PlatformToggles &t) {
    Json::Value root;
    Json::Reader reader;
    if (!reader.parse(json, root)) return false;
    // GetCompatMaster @0x3e931c: case-insensitive device lookup
    std::string master = device;
    const Json::Value &compats = root["compats"];
    for (const std::string &k : compats.getMemberNames())
        if (!strcasecmp(k.c_str(), device.c_str())) { master = compats[k].asString(); break; }
    int mem = 0, cpu = 0, gpu = 0;
    const Json::Value &nc = root["noncompats"];
    for (const std::string &k : nc.getMemberNames())
        if (!strcasecmp(k.c_str(), master.c_str())) {
            mem = nc[k]["mem"].asInt();
            cpu = nc[k]["cpu"].asInt();
            gpu = nc[k]["gpu"].asInt();
            break;
        }
    const Json::Value &profiles = root["Profiles"];
    ApplyToggles(profiles["GPU_" + std::to_string(gpu)], t);
    ApplyToggles(profiles["CPU_" + std::to_string(cpu)], t);
    ApplyToggles(profiles["MEM_" + std::to_string(mem)], t);
    if (profiles.isMember(master)) ApplyToggles(profiles[master], t);
    return true;
}

// Game::PostInit @0x528e1c..
void CGameConfig::AddShaderDefines(const PlatformToggles &t, jet::video::Driver *d) {
    if (!d) return;
    if (t.useShadows > 0) d->AddShaderDefine(jet::String("HAS_SHADOWS"));
    if (t.useSpecularMask) d->AddShaderDefine(jet::String("HAS_SPECULAR_MASK"));
    if (t.useRimLight) d->AddShaderDefine(jet::String("HAS_RIM_LIGHT"));
    if (t.useCurvature) d->AddShaderDefine(jet::String("HAS_CURVATURE"));
    if (t.useLinearSpace) d->AddShaderDefine(jet::String("HAS_LINEAR_SPACE"));
    if (t.useSpecularLight) d->AddShaderDefine(jet::String("HAS_SPECULAR_LIGHT"));
    if (t.useEmissiveness) d->AddShaderDefine(jet::String("HAS_EMISSIVENESS"));
    if (t.useBarla) d->AddShaderDefine(jet::String("HAS_BARLA"));
    if (t.useNdis) d->AddShaderDefine(jet::String("HAS_NDIS"));
    if (t.useCheapNdis) d->AddShaderDefine(jet::String("CHEAP_NDIS"));
    if (t.forceRoadShader) d->AddShaderDefine(jet::String("HAS_ROAD_SHADER"));
}
