// source/game/cheats/CheatsMgr.cpp
