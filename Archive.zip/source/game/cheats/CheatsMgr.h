// source/game/cheats/CheatsMgr.h
#ifndef SOURCE_GAME_CHEATS_CHEATSMGR_H
#define SOURCE_GAME_CHEATS_CHEATSMGR_H

class CheatsMgr : public Singleton<CheatsMgr> {  // sizeof 0xB4
public:
    CheatsMgr();
    virtual ~CheatsMgr();
    void RemoveCheatEntry(boost::shared_ptr<CheatsEntry>);
    boost::shared_ptr<CheatsEntry> GetCheatEntry(const jet::String&);
    boost::shared_ptr<CheatsEntry> GetCurrentStackCheat();
    void UI_Show();
    bool UI_IsShowingCheatsMenu();
    void UI_ForceCloseCheatsMenu();
    void UIEvent_GoBackPressed();
    bool GetCheatEnabled();
    void SetEnableCheats(bool);
    void SetFpsEnabled(bool);
    bool IsFPSEnabled();
    bool IsFasterLocalPushNotsEnabled();
    bool IsInvincible();
    void SetInvincible(bool);
    bool ShowItemPositions();
    void SetShowItemPositions(bool);
    bool ShowSkippedDespicableActions();
    void SetShowSkippedDespicableActions(bool);
    void Debug_RenderReflexionMap();
    void Debug_RenderTarget(boost::shared_ptr<jet::video::RenderTarget>);
    safe_enum<EVehiclesDef,enum EVehiclesDef::type> GetMinionVehicle();
    void SetMinionVehicle(safe_enum<EVehiclesDef,enum EVehiclesDef::type>);
    safe_enum<EPowerUpDef,enum EPowerUpDef::type> GetPowerUp();
    void SetPowerUp(safe_enum<EPowerUpDef,enum EPowerUpDef::type>);
    bool IsShowLogEnabled();
    bool IsAutosaveCheatEnabled();
private:
    void SetFlag(int&, int, bool);
    void PushStackEntry(boost::shared_ptr<CheatsEntry>);
    void PopStackEntry();
    void UI_Init();
    void UI_Hide();
    void UI_RefreshEntry();
    void InitQACheats();
    void InitDesignCheats();
    void InitDevCheats();
    void PostInit_GameParams();
    void Event_CheatsEnabled(boost::shared_ptr<CheatsEntry>&);
    void Event_FPSCheatEntry(boost::shared_ptr<CheatsEntry>&);
    void Event_ShowLogCheatEntry(boost::shared_ptr<CheatsEntry>&);
    void Event_ShowOnlineStatusCheatEntry(boost::shared_ptr<CheatsEntry>&);
    void Event_DebugFlagCheatEntry(boost::shared_ptr<CheatsEntry>&);
    void RefreshDebugFlagsStatus();
    void Event_ToggleCheatOnOff(boost::shared_ptr<CheatsEntry>&);
    void InitVehiclesCheatCheatEntry();
    void AddMinionVehicle(const jet::String&, safe_enum<EVehiclesDef,enum EVehiclesDef::type>);
    void Event_TriggerVehicle(boost::shared_ptr<CheatsEntry>&);
    void InitPowerUpEntry();
    void AddPowerUp(const jet::String&, safe_enum<EPowerUpDef,enum EPowerUpDef::type>);
    void Event_TriggerPowerUp(boost::shared_ptr<CheatsEntry>&);
    void InitRestartEntry();
    void Event_AddBananas(boost::shared_ptr<CheatsEntry>&);
    void Event_AddTokens(boost::shared_ptr<CheatsEntry>&);
    void Event_RestartOnLab(boost::shared_ptr<CheatsEntry>&);
    void Event_RestartOnResidential(boost::shared_ptr<CheatsEntry>&);
    void Event_RepeatLastLevel(boost::shared_ptr<CheatsEntry>&);
    void Event_EnterNewSeed(boost::shared_ptr<CheatsEntry>&);
    void Event_newSeedCallback(int);
    void Event_RestartWithNewSeed(boost::shared_ptr<CheatsEntry>&);
    void Event_AutosaveCheat(boost::shared_ptr<CheatsEntry>&);
    void Event_QATestLocalNotifications(boost::shared_ptr<CheatsEntry>&);
    void Event_SetGameSpeedNormal(boost::shared_ptr<CheatsEntry>&);
    void Event_SetGameSpeedDiv2(boost::shared_ptr<CheatsEntry>&);
    void Event_SetGameSpeedx4(boost::shared_ptr<CheatsEntry>&);
public:
    static const jet::String k_QACheatStr;
    static const jet::String k_designCheatStr;
    static const jet::String k_devCheatStr;
    static const jet::String k_devCheatDebugFlagsStr;
    static const jet::String k_restartStr;
private:
    boost::shared_ptr<CheatsEntry> m_cheatsRootEntry;  // 0x4
    ustl::vector<boost::shared_ptr<CheatsEntry> > m_cheatsStack;  // 0xC
    bool m_areCheatsEnabled;  // 0x1C
    boost::shared_ptr<CheatsEntry> m_cheatsEnabled;  // 0x20
    boost::shared_ptr<CheatsEntry> m_fpsCheatEntry;  // 0x28
    bool m_isFPSEnabled;  // 0x30
    boost::shared_ptr<CheatsEntry> m_invincibleCheatEntry;  // 0x34
    boost::shared_ptr<CheatsEntry> m_showItemsEntry;  // 0x3C
    boost::shared_ptr<CheatsEntry> m_showSkippedDespicableActionsEntry;  // 0x44
    boost::shared_ptr<CheatsEntry> m_showLog;  // 0x4C
    bool m_isShowLogEnabled;  // 0x54
    boost::shared_ptr<CheatsEntry> m_showOnlineStatus;  // 0x58
    std::vector<boost::shared_ptr<CheatsEntry>,std::allocator<boost::shared_ptr<CheatsEntry> > > m_debugFlags;  // 0x60
    boost::shared_ptr<CheatsEntry> m_fasterLocalPushNots;  // 0x74
    safe_enum<EVehiclesDef,enum EVehiclesDef::type> m_minionVehicle;  // 0x7C
    boost::shared_ptr<CheatsEntry> m_vehiclesCheatEntry;  // 0x80
    safe_enum<EPowerUpDef,enum EPowerUpDef::type> m_powerUp;  // 0x88
    boost::shared_ptr<CheatsEntry> m_powerUpCheatEntry;  // 0x8C
    boost::shared_ptr<CheatsEntry> m_restartCheatEntry;  // 0x94
    boost::shared_ptr<CheatsEntry> m_restartWithNewSeedEntry;  // 0x9C
    int m_newSeedValue;  // 0xA4
    boost::shared_ptr<CheatsEntry> m_autosaveCheatEntry;  // 0xA8
    bool m_isAutosaveCheatEnabled;  // 0xB0
};

#endif
