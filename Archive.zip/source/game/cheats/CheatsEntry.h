// source/game/cheats/CheatsEntry.h
#ifndef SOURCE_GAME_CHEATS_CHEATSENTRY_H
#define SOURCE_GAME_CHEATS_CHEATSENTRY_H

class CheatsEntry : public BasicPage, public boost::enable_shared_from_this<CheatsEntry> {  // sizeof 0x228
    CheatsEntry();
public:
    CheatsEntry(const jet::String&, bool);
    virtual ~CheatsEntry();
    void SetCallBack(boost::function<void __cdecl(boost::shared_ptr<CheatsEntry> &)>);
    void ClearCheatsEntry();
    void AddCheatEntry(boost::shared_ptr<CheatsEntry>);
    void RemoveCheatEntry(boost::shared_ptr<CheatsEntry>);
    boost::shared_ptr<CheatsEntry> GetCheatEntry(const jet::String&);
    ustl::vector<boost::shared_ptr<CheatsEntry> > &GetCheatsEntryArray();
    void SetName(const jet::String&);
    jet::String &GetName();
    bool IsEnabled();
    void SetEnabled(bool);
    virtual void Update(int);
    virtual void Render(const jet::scene::Camera&, jet::video::Painter&);
    void SetTypeYesNo(bool);
    void SetTypeFlag(int, bool);
    void SetTypeClampedValue(float, float, float, float);
    void SetTypeTrigger();
    safe_enum<CheatsEntry::ETypeDef,enum CheatsEntry::ETypeDef::type> GetType();
    int GetCheatEntryValue();
    int GetFlagValue();
    float GetClampedValue();
private:
    void SetClampedValue(float);
    boost::function<void __cdecl(boost::shared_ptr<CheatsEntry> &)> m_buttonCallback;  // 0x1D0
    ustl::vector<boost::shared_ptr<CheatsEntry> > m_cheatsEntry;  // 0x1F0
    jet::String m_name;  // 0x200
    bool m_enabled;  // 0x204
    static const jet::String s_yes;
    static const jet::String s_no;
    safe_enum<CheatsEntry::ETypeDef,enum CheatsEntry::ETypeDef::type> m_cheatType;  // 0x208
    int m_flag;  // 0x20C
    float m_clampedValMin;  // 0x210
    float m_clampedValCur;  // 0x214
    float m_clampedValMax;  // 0x218
    float m_clampedValIncrement;  // 0x21C
    InterfaceText *m_yesNoTextUI;  // 0x220
    InterfaceButton *m_button;  // 0x224
};

namespace gui {
struct CheatsEntry {  // sizeof 0x1
    jet::String operator class jet::String();
    static jet::String &_EntrySize();
    static jet::String &_EntryButton();
    static jet::String &_YesNoText();
};
}

#endif
