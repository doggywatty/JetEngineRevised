// source/game/cheats/CheatsEntry.cpp
