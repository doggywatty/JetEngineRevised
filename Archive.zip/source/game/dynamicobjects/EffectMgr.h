// source/game/dynamicobjects/EffectMgr.h
#ifndef SOURCE_GAME_DYNAMICOBJECTS_EFFECTMGR_H
#define SOURCE_GAME_DYNAMICOBJECTS_EFFECTMGR_H

class EffectMgr : public Singleton<EffectMgr> {  // sizeof 0x5168
public:
    EffectMgr();
    bool Add(const EffectDef*, const math::vec3<float>&, const math::quat<float>&, bool, const jet::scene::Node*, int);
    EffectControl *Add(const EffectDef*);
    void Release(EffectControl*);
    void Stop(EffectControl*);
    void Update();
    void Render();
    void SetPosition(EffectControl*, const math::vec3<float>&);
    void SetRotation(EffectControl*, const math::quat<float>&);
    void SetTransform(EffectControl*, const math::vec3<float>&, const math::quat<float>&);
    void SetVisible(EffectControl*, bool);
    void SetLinearVelocity(EffectControl*, const math::vec3<float>&);
    void Translate(const math::vec3<float>&);
    void OnModelChanged(jet::scene::Model*, jet::scene::Model*);
    void RenderDebug(jet::video::Painter&);
    EffectControl *GetLastAddedEffect();
    EffectControl *GetEffectByEventId(unsigned);
    void SetListenerPosition(math::vec3<float>);
private:
    void InitBounceScreenAnim(EffectControl*);
    void SetBounceScreenState(EffectControl*, EffectControl::BounceScreenState);
    void UpdateBounceScreenAnim(EffectControl*, int);
    void UpdateBounceScreenPosition(EffectControl*);
public:
    static const float k_bounceMoveToScreenTime;
    static const int k_effectBufferSize;
    static const int k_trail_steps_resolution;
    static const float k_soundRangeSQ;
    static bool s_debug;
private:
    EffectControl m_effects[200];  // 0x4
    EffectControl *m_lastAddedEffect;  // 0x5144
    std::vector<EffectControl *,std::allocator<EffectControl *> > m_bounceScreenControls;  // 0x5148
    math::vec3<float> m_listenerPosition;  // 0x515C
};

#endif
