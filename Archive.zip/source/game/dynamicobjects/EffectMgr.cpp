// source/game/dynamicobjects/EffectMgr.cpp
