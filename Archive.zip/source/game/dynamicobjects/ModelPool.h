// source/game/dynamicobjects/ModelPool.h
#ifndef SOURCE_GAME_DYNAMICOBJECTS_MODELPOOL_H
#define SOURCE_GAME_DYNAMICOBJECTS_MODELPOOL_H

class ModelPool : public Singleton<ModelPool> {  // sizeof 0x18
public:
    ModelPool();
    virtual ~ModelPool();
    void Render();
    void DestroyAll();
    void Release(jet::scene::Model*);
    jet::scene::Model *GetModel(const jet::String&, const jet::String&, jet::scene::Model**);
private:
    void LoadModelIfNeeded(jet::scene::Model**, const jet::String&, const jet::String&);
    void FreeModel(jet::scene::Model**, const jet::String&);
protected:
    std::vector<ModelPoolEntry,std::allocator<ModelPoolEntry> > m_pool;  // 0x4
};

#endif
