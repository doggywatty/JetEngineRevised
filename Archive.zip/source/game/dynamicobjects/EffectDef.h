// source/game/dynamicobjects/EffectDef.h
#ifndef SOURCE_GAME_DYNAMICOBJECTS_EFFECTDEF_H
#define SOURCE_GAME_DYNAMICOBJECTS_EFFECTDEF_H

class EffectDef : public GameEntity {  // sizeof 0x120
public:
    EffectDef(const clara::Template*);
    virtual ~EffectDef();
    virtual void Init();
    virtual void Update();
    bool IsImpostor();
    bool IsLooped();
    bool RotateModel();
    const jet::String &GetModelName();
    const jet::String &GetAnimName();
    const std::vector<std::pair<jet::String,MaterialDef *>,std::allocator<std::pair<jet::String,MaterialDef *> > > &GetMaterialDef();
    LightDef *GetLightDef();
    int GetLightTime();
    const jet::String &GetSoundLabel();
    const jet::String &GetParticleSystem();
    bool GetUseFlashScreen();
    TrailDefEntity *GetTrailDef();
    const jet::String &GetShadowModelName();
    const std::vector<std::pair<jet::String,MaterialDef *>,std::allocator<std::pair<jet::String,MaterialDef *> > > &GetShadowMaterialDef();
    void FlashScreen();
    void ShakeCamera();
    bool GetUseBounceScreenAnim();
    EffectDef::BounceSide GetBounceSide();
    const jet::String &GetFlyingScreenAnim();
    const jet::String &GetBounceScreenAnim();
    static jet::String k_tmplName;
private:
    bool m_isLooped;  // 0x90
    bool m_rotateModel;  // 0x91
    bool m_isImpostor;  // 0x92
    jet::String m_modelName;  // 0x94
    jet::String m_animName;  // 0x98
    std::vector<std::pair<jet::String,MaterialDef *>,std::allocator<std::pair<jet::String,MaterialDef *> > > m_materials;  // 0x9C
    jet::String m_shadowModelName;  // 0xB0
    std::vector<std::pair<jet::String,MaterialDef *>,std::allocator<std::pair<jet::String,MaterialDef *> > > m_shadowMaterialDefs;  // 0xB4
    LightDef *m_lightDef;  // 0xC8
    int m_lightTime;  // 0xCC
    jet::String m_soundLabel;  // 0xD0
    jet::String m_particles;  // 0xD4
    bool m_fadeScreen;  // 0xD8
    jet::String m_fadeTechnique;  // 0xDC
    int m_fadeInTime;  // 0xE0
    int m_fadeOutTime;  // 0xE4
    float m_shakeCameraTime;  // 0xE8
    bool m_useBounceScreenAnim;  // 0xEC
    std::vector<jet::String,std::allocator<jet::String> > m_flyingScreenAnim;  // 0xF0
    std::vector<jet::String,std::allocator<jet::String> > m_bounceScreenAnim;  // 0x104
    EffectDef::BounceSide m_bounceSide;  // 0x118
    TrailDefEntity *m_trailDef;  // 0x11C
    static const float k_bounceMoveToScreenTime;
};

#endif
