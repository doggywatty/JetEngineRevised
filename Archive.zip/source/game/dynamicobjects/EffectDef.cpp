// source/game/dynamicobjects/EffectDef.cpp
