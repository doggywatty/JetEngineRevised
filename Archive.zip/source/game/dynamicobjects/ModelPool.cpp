// source/game/dynamicobjects/ModelPool.cpp
