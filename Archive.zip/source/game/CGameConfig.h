// source/game/CGameConfig.h
#ifndef SOURCE_GAME_CGAMECONFIG_H
#define SOURCE_GAME_CGAMECONFIG_H

#include <string>

namespace jet::video { class Driver; }

// Per-device quality toggles from profiles.json (CGameConfig::ApplyTogglesFromProfile @0x3e96ac)
struct PlatformToggles {
    int textureStartLOD = 0;
    float size = 1.0f;
    float downsamplePercent = 0.0f;
    int msaa = 0;
    bool usePostFX = true;
    int defaultTextureFiltering = 2;
    int useShadows = 0;
    bool useLowMaterials = false;
    bool useLowModels = false;
    bool useLowParticles = false;
    bool hideOptionalDecos = false;
    float decoGenerationGroupAllowedDecosLerp = 1.0f;
    bool useSpecularMask = false;
    bool useRimLight = false;
    bool useCurvature = false;
    bool useLinearSpace = false;
    bool useSpecularLight = false;
    bool useEmissiveness = false;
    bool useBarla = false;
    bool useNdis = false;
    bool useCheapNdis = false;
    bool forceRoadShader = false;
    bool useIngameUITextEffect = true;
    bool useUIDespicableScoreParticles = true;
    int maxOutline = -1;
    float backgroundFarPlane = 1000.0f;
    float decosAnimationRadius = 200.0f;
    float sceneMgrCullingDistance = 90.0f;
    float sceneMgrCullingRadius = 10.0f;
    float sceneMgrCullingScreenPixels = 3.0f;
};

class CGameConfig {
public:
    // the running device's toggles (Game keeps them from PostInit on)
    static PlatformToggles &Current();
    // ComputePlatformToggles @0x3ea260: the device model is mapped through "compats" to its
    // master, "noncompats" gives its {mem, cpu, gpu} levels, then the GPU_<n>, CPU_<n> and
    // MEM_<n> profiles and finally a profile named after the device apply in that order.
    static bool ComputePlatformToggles(const std::string &profilesJson, const std::string &device, PlatformToggles &out);
    // The shader defines Game::PostInit adds for the toggles
    static void AddShaderDefines(const PlatformToggles &t, jet::video::Driver *d);
};

#endif
