// source/game/Game.cpp
#include "Game.h"
#include "scene/modelloader.h"
#include "GameLevel.h"
#include "interfaces/GameSettings.h"
#include "gamemanagers/BappleMgr.h"
#include "Statistics.h"
#include "gamemanagers/TutorialMgr.h"
#include "gamemanagers/MissionMgr.h"
#include "entities/LevelDef.h"
#include "gamemanagers/ClaraFilesMgr.h"
#include "gamemanagers/FontInfoMgr.h"
#include "gamemanagers/PainterMgr.h"
#include "gamestates/GameState.h"
#include "gamestates/GS_Loading.h"
#include "interfaces/interfaceobjects/BasicPage.h"
#include "input/TouchMgr.h"
#include "input/InputMgr.h"
#include "challenges/ChallengeMgr.h"
#include "interfaces/aurora/AuroraLevelMgr.h"
#include "interfaces/interfaceobjects/InterfaceObject.h"
#include "interfaces/menus/Menu_Base.h"
#include "interfaces/menus/MenuMgr.h"
#include "online/tracking/SessionTrackingMgr.h"
#include "project.h"
#include "Player.h"
#include "localization/babel.h"
#include "sprites/spritemgr.h"
#include "sprites/fontmgr.h"
#include "text/fontloader.h"
#include "scene/camera.h"
#include "scene/scenemgr.h"
#include "stream/ifilesystem.h"
#include "stream/streammgr.h"
#include "stream/zipfilesystem.h"
#include "stream/streamutil.h"
#include "system.h"
#include "video/display.h"
#include "video/driver.h"
#include "video/textureloader.h"
#include "scene/modelbase.h"
#include "folder.h"
#include "movie.h"
#include "group.h"
#include "video/shaderuniform.h"
#include <cmath>

// @0x501bcc
Game::Game()
    : m_gfxConfig(0), m_gfx(0), m_designWidthScale(1.0f), m_lastTime(jet::System::GetTime()), m_updateStep(k_updateTime), m_scaledStep(0), m_updateCounter(0), m_renderCounter(0),
      m_paused(false), m_oneUpdateOnly(false), m_keepPending(false), m_timeSpeed(1.0f, 1.0f, 500), m_debugTimeRatio(1.0f), m_timeSpeedHold(0), m_isInActionPhase(false),
      m_isInLoadingPhase(false), m_isCinematic(false), m_gameplayStarted(false), m_loadingScreen(false), m_showingInitialScreens(false), m_waitingForLoad(false), m_startMode(0), m_startDistance(0),
      m_curvature(0, 0), m_curvatureFrom(0, 0), m_curvatureTo(0, 0), m_curvatureTime(0), m_curvatureElapsed(0), m_curvatureAnim(false), m_shadowCamera(0) {}

Game::~Game() {
    delete m_gfxConfig;
    delete m_shadowCamera;
}

void Game::OnDisplayAttached(unsigned) {}
void Game::OnDisplayDetached(unsigned) {}

// @0x50b0c4
void Game::AddZipFileSystem(const jet::String &path) {
    if (!jet::stream::StreamMgr::GetInstance().IsFile(path)) return;
    std::shared_ptr<jet::stream::IFileSystem> z(new jet::stream::ZipFileSystem(path));
    m_zipFileSystems.push_back(z);
}

// @0x50b1ec: the path is added to every archive added, or to the real files when there are none
std::shared_ptr<jet::stream::IStreamFactory> Game::FileSystem_AddPath(const jet::String &path, const jet::String &ext) {
    jet::stream::StreamMgr &sm = jet::stream::StreamMgr::GetInstance();
    if (m_zipFileSystems.empty()) return sm.AddPath(path, ext);
    std::shared_ptr<jet::stream::IStreamFactory> f;
    for (auto &z : m_zipFileSystems)
        if (std::shared_ptr<jet::stream::IStreamFactory> n = sm.AddPath(z, path, ext)) f = n;
    return f;
}

// @0x50b330
std::shared_ptr<jet::stream::IStreamFactory> Game::FileSystem_AddPathInFront(const jet::String &path, const jet::String &ext) {
    jet::stream::StreamMgr &sm = jet::stream::StreamMgr::GetInstance();
    if (m_zipFileSystems.empty()) return sm.AddPathFront(path, ext);
    std::shared_ptr<jet::stream::IStreamFactory> f;
    for (auto &z : m_zipFileSystems)
        if (std::shared_ptr<jet::stream::IStreamFactory> n = sm.AddPathFront(z, path, ext)) f = n;
    return f;
}

// @0x50b4b4: from the last archive that has the path, else from the real files
std::shared_ptr<jet::stream::IStreamFactory> Game::FileSystem_CreateStreamFactoryFromPath(const jet::String &path, const jet::String &ext) {
    for (int i = (int)m_zipFileSystems.size() - 1; i >= 0; i--)
        if (m_zipFileSystems[i]->FindEntryByPath(0, path).id >= 0) return jet::stream::CreateStreamFactoryFromPath(m_zipFileSystems[i], path, ext);
    return jet::stream::CreateStreamFactoryFromPath(path, ext);
}

// @0x50b5d8
bool Game::FileSystem_IsFile(const jet::String &path) { return jet::stream::StreamMgr::GetInstance().IsFile(path); }
bool Game::FileSystem_IsDirectory(const jet::String &path) { return jet::stream::StreamMgr::GetInstance().IsDirectory(path); }
jet::stream::IStream *Game::FileSystem_CreateStreamFromPath(const jet::String &path) { return jet::stream::StreamMgr::GetInstance().CreateStreamByPath(path); }

// @0x505574: the file's content is not read here, the parameter holds the app version
void Game::SetGameParam(const jet::String &name, const jet::String&) { AddParam(name, m_versionName); }

// @0x502b04: the managers that have been ported
void Game::Init() {
    AddParam(jet::String("server"), jet::String("server"));
    FileSystem_AddPath(jet::String("color_profiles"), jet::String("conf"));
    jet::Application::Init();
    jet::video::Driver *drv = jet::System::GetDriver();
    const PlatformToggles &t = CGameConfig::Current();
    jet::video::TextureLoader::GetInstance()->SetDefaultTextureFilter(
        safe_enum<jet::video::Texture::FilterDef, unsigned char>((int)t.defaultTextureFiltering));
    jet::video::TextureLoader::GetInstance()->SetBestLod((unsigned)t.textureStartLOD);
    drv->SetSeparateAlphaTextures(true);
    for (const char *d : { ".", "shaders", "levels", "localizationText" }) FileSystem_AddPath(jet::String(d), jet::String("*"));
    new babel::Babel;
    new Player;
    new MissionMgr;
    new TutorialMgr;
    new Statistics;
    new BappleMgr;
    new GameSettings;
    new PainterMgr;
    new TouchMgr;
    new FontInfoMgr;
    new jet::text::FontLoader;
    new FontMgr;
    new ClaraFilesMgr;
    new clara::Project;
    new SpriteMgr;
    FileSystem_AddPath(jet::String("datalibs"), jet::String("*"));
    FileSystem_AddPath(jet::String("fonts_ttf"), jet::String("ttf"));
    FileSystem_AddPath(jet::String("fonts_cfg"), jet::String("cfg"));
    FontInfoMgr::GetInstance()->Load(jet::String("gui_fonts_info"));
    m_gfxConfig = new GFXConfig;
    m_gfxConfig->Load(jet::String("gfx_config"));
    new AuroraLevelMgr;
    FontMgr::Set2DRenderingWorldCoords(false);
    PostInitRefreshGFX();
    FileSystem_AddPath(jet::String("textures_android"), jet::String("tga"));
}

// @0x5050f8: the display's GUI configuration: the aurora layers, the sprite list and the palettes
void Game::PostInitRefreshGFX() {
    if (!m_gfxConfig || m_gfx) return;
    math::vec2<unsigned int> sz = jet::System::GetDisplay(0)->GetSize();
    m_gfx = m_gfxConfig->GetConfig(sz.x, sz.y);
    float dw = (float)m_gfx->designWidth, dh = (float)m_gfx->designHeight;
    float sw = (float)m_gfx->screenWidth, sh = (float)m_gfx->screenHeight;
    m_designWidthScale = dw / (sw / sh);
    InterfaceObject::Set3DAspectRatioScale(((float)sz.x / (float)sz.y) / (dw / dh));
    float scale = std::min((float)sz.x / dw, (float)sz.y / dh);
    Sprite::SetDefaultPositionScale(scale);
    FileSystem_AddPath(jet::String("datalibs/") + m_gfx->sprites, jet::String("*"));
    FileSystem_AddPath(jet::String("datalibs/") + m_gfx->fonts, jet::String("*"));
    FileSystem_AddPath(jet::String("datalibs/tilemaps"), jet::String("*"));
    std::shared_ptr<jet::stream::IStreamFactory> layers = FileSystem_CreateStreamFactoryFromPath(jet::String("datalibs/") + m_gfx->guiLayers, jet::String("*"));
    AuroraLevelMgr *a = AuroraLevelMgr::GetInstance();
    a->Load(boost::shared_ptr<jet::stream::IStreamFactory>(layers.get(), [layers](void*) {}), m_gfx->guiNames, false, dw, dh, scale, m_gfx->suffixes);
    a->LoadGraphItemSpriteNames(jet::String("gui_graph_item_sprites"));
    InterfaceObject::LoadPalettesValues(jet::String("gui_pal_list"));
    if (!m_gfx->spritePrefix.empty() && !m_gfx->spritePrefix.Equals("_")) SpriteMgr::GetInstance()->SetPrefix(m_gfx->spritePrefix);
}

// @0x503a68: the managers and the shader defines for the device
void Game::PostInit() {
    jet::stream::StreamMgr::GetInstance().AddEncryptionPair(jet::String("ERROR: invalid stream"), jet::String(".xgraphml"));
    GameSettings::GetInstance()->LoadGameSettings();
    FileSystem_AddPath(jet::String("models"), jet::String("pig"));
    FileSystem_AddPath(jet::String("anims"), jet::String("anim"));
    FileSystem_AddPath(jet::String("collisions"), jet::String("*"));
    FileSystem_AddPath(jet::String("collisions"), jet::String("hull"));
    FileSystem_AddPath(jet::String("text"), jet::String("*"));
    FileSystem_AddPath(jet::String("sounds"), jet::String("*"));
    FileSystem_AddPath(jet::String("soundpack"), jet::String("*"));
    const PlatformToggles &t = CGameConfig::Current();
    CGameConfig::AddShaderDefines(t, jet::System::GetDriver());
    if (t.useShadows > 0) InitShadowMapData();
    jet::scene::ModelBase::s_hwSkinningBoneLimit = 30;
    PainterMgr::GetInstance()->Init();
    new MenuMgr;
    MenuMgr::GetInstance()->Init();
    // Not placed here from disassembly (SessionTrackingMgr::SessionTrackingMgr() is trivial enough to
    // be fully inlined at every call site, so armdis.py -s finds no standalone constructor symbol to
    // locate real callers of) -- added because GS_Gameplay::InitSessions() and GS_Loading::Finish()'s
    // GoTo_Gameplay case both now call SessionTrackingMgr::GetInstance() and crash on a null singleton
    // otherwise. Every other Singleton<T> this tree uses is constructed right here the same way.
    new game::common::SessionTrackingMgr;
    // Same reasoning as SessionTrackingMgr above: InputMgr::UpdateSlideActions/Update are now real but
    // nothing constructed an instance anywhere in this tree. See InputMgr.h for why this uses
    // Singleton<T> instead of the real binary's glf::App::GetInputMgr() accessor.
    new InputMgr;
    // Same reasoning again: Menu_Pause::UpdateExit() (now real) calls ChallengeMgr::GetInstance() and
    // needs a non-null singleton.
    new ChallengeMgr;
}

void Game::Shutdown() { jet::Application::Shutdown(); }

bool Game::GetPaintGUI() const { return MenuMgr::s_paintGUI; }
void Game::SetPaintGUI(bool b) { MenuMgr::s_paintGUI = b; }

// @0x508870
void Game::SetTimeSpeed(float target, int transitionMs, int holdMs, std::function<void()> onDone) {
    m_timeSpeed.SetDelay(transitionMs);
    m_timeSpeed.SetTargetValue(target);
    m_timeSpeedHold = holdMs < 1 ? -1 : holdMs + transitionMs;
    m_timeSpeedDone = onDone;
}

// @0x50b964: the device variant of an entity: its name plus a suffix, the first the project has, else itself
clara::DataEntity *Game::GetDeviceSpecificEntity(clara::DataEntity *e) {
    if (!e) return e;
    for (const jet::String &suffix : m_gfx->suffixes) {
        clara::Path p(e->GetName() + suffix);
        if (clara::DataEntity *v = clara::Project::GetInstance()->FindEntityByPath(p)) return v;
    }
    return e;
}

// @0x50b924
clara::DataEntity *Game::GetDeviceSpecificEntity(const jet::String &name) {
    return GetDeviceSpecificEntity(clara::Project::GetInstance()->FindEntityByName(name));
}

// @0x50ba80
clara::Movie *Game::GetDeviceSpecificMovie(clara::Movie *m) {
    if (!m) return m;
    for (const jet::String &suffix : m_gfx->suffixes)
        if (clara::Movie *v = clara::Project::GetInstance()->FindMovieByName(m->GetName() + suffix)) return v;
    return m;
}

// @0x50bb2c
clara::Group *Game::GetDeviceSpecificGroup(clara::Group *g) {
    if (!g) return g;
    for (const jet::String &suffix : m_gfx->suffixes)
        if (clara::Group *v = clara::Project::GetInstance()->FindGroupByName(g->GetName() + suffix)) return v;
    return g;
}

// @0x50bbd8
clara::Folder *Game::GetDeviceSpecificFolder(clara::Folder *f) {
    if (!f) return f;
    for (const jet::String &suffix : m_gfx->suffixes)
        if (clara::Folder *v = clara::Project::GetInstance()->FindFolderByName(f->GetName() + suffix)) return v;
    return f;
}

// @0x505504: the horizontal fov of a vertical one, for the design display or the 3:4 one
float Game::GetHFovFor(float fovY, bool useDesignRatio) const {
    float aspect = 0.75f;
    if (useDesignRatio && m_gfx) aspect = (float)m_gfx->designWidth / (float)m_gfx->designHeight;
    return atanf(tanf(fovY * 0.5f) * aspect) * 2.0f;
}

// @0x50bc84: the curvature jumps (no time) or eases to the new one
void Game::SetCurvatureParams(const math::vec2<float> &c, unsigned ms) {
    m_curvatureTime = (int)ms;
    if (ms == 0) {
        m_curvatureAnim = false;
        m_curvatureElapsed = 0;
        m_curvature = m_curvatureTo = c;
    } else if (!math::equals(m_curvatureTo, c, 1.1920929e-07f)) {
        m_curvatureFrom = m_curvature;
        m_curvatureTo = c;
        m_curvatureElapsed = 0;
        m_curvatureAnim = !math::equals(m_curvature, c, 1.1920929e-07f);
    }
    if (ms == 0)
        jet::System::GetDriver()->SetGlobalUniform(jet::String("CurvatureParams"), jet::video::ShaderUniform(m_curvature));
}

// @0x507810: the touches, the menus and the state, the frame's time to the driver, the curvature easing
void Game::FrameUpdate(unsigned dt) {
    InterfaceObject::UpdateAutoScrollText();
    jet::video::Driver *drv = jet::System::GetDriver();
    MenuMgr *mm = MenuMgr::GetInstance();
    mm->UpdateDisableTouchesTimer();
    if (!m_isInLoadingPhase) {
        if (!m_isCinematic) {
            TouchMgr::GetInstance()->Update();
            // Not verified from disassembly where exactly this real call sits relative to TouchMgr's
            // Update() in the real binary -- added here since this is the one place in this tree a
            // TouchMgr::Update() already runs every frame outside the loading phase, and InputMgr's own
            // Update() needs to run after TouchMgr's so it sees this frame's touch state, not last
            // frame's.
            InputMgr::GetInstance()->Update((int)dt);
            mm->Update();
            Menu_Base *menu = mm->GetCurrentPlayingMenu();
            GameState::UpdateCurrentState(menu ? menu->UpdateGameInBG() : true);
        }
    } else
        GameState::UpdateCurrentState(true);
    drv->AddTime((int)(GetUpdateTimeUs() / 1000));
    if (m_curvatureAnim) {
        m_curvatureElapsed += (int)dt;
        if (m_curvatureElapsed < m_curvatureTime) {
            if (m_curvatureElapsed < 0)
                m_curvature = m_curvatureFrom;
            else {
                float f = jet::core::QuadraticEaseInOut((float)m_curvatureElapsed / (float)m_curvatureTime).v;
                m_curvature = math::vec2<float>(f * m_curvatureTo.x + (1.0f - f) * m_curvatureFrom.x, f * m_curvatureTo.y + (1.0f - f) * m_curvatureFrom.y);
            }
        } else {
            m_curvature = m_curvatureTo;
            m_curvatureAnim = false;
        }
        drv->SetGlobalUniform(jet::String("CurvatureParams"), jet::video::ShaderUniform(m_curvature));
    }
}

// @0x508684: the state, then whatever the game draws over it
void Game::FrameRender() {
    jet::video::Driver *drv = jet::System::GetDriver();
    drv->SetDisplay(jet::System::GetDisplay(0));
    drv->BeginRendering();
    drv->SetCrtRenderTarget(jet::System::GetDisplay(0)->GetRenderTarget());
    GameState::RenderCurrentState();
    PainterMgr::GetInstance()->Flush();  // the painters flush at the end of the frame
    drv->EndRendering();
}

// @0x506210: the game time passes in steps of k_updateTime (at most k_maxUpdates a frame), scaled by the time speed
void Game::OnUpdate() {
    long long now = jet::System::GetTime();
    PreUpdate();
    int pending = (int)(now - m_lastTime);
    if (GameState *s = GameState::GetCrtState()) pending = s->GetUpdateTimeDelta(pending);
    if (pending < 0) pending = 0;
    SetTotalFrameTime((unsigned)pending);
    if (m_timeSpeedHold > 0 && (m_timeSpeedHold -= pending) < 1) {
        m_timeSpeedHold = 0;
        m_timeSpeed.SetTargetValue(1.0f);
    }
    if (m_timeSpeed.IsUpdating()) m_timeSpeed.Update(pending);
    if (m_timeSpeedDone && !m_timeSpeed.IsUpdating()) {
        std::function<void()> f = m_timeSpeedDone;
        m_timeSpeedDone = nullptr;
        f();
    }
    float speed = m_timeSpeed.GetCurrentValue() * m_debugTimeRatio;
    int step = m_updateStep;
    m_scaledStep = speed < 1.0f ? (int)((float)step * speed) : step;
    if (speed > 1.0f) pending = (int)((float)pending * speed);
    int budget = (int)k_maxUpdates + 1;
    while (pending >= step) {
        if (--budget == 0) {
            if (!m_keepPending) pending = 0;
            break;
        }
        SetUpdateTime(m_paused ? 0 : (unsigned)m_scaledStep);
        FrameUpdate((unsigned)m_scaledStep);
        m_updateCounter++;
        pending -= step;
        if (m_oneUpdateOnly) break;
    }
    m_lastTime = now - pending;
    SetRenderTime((unsigned)pending);
    FrameRender();
    if (m_frameDone) m_frameDone();
    jet::System::GetDisplay(0)->Swap();
    m_renderCounter++;
}

void Game::OnPointerPressed(int id, int x, int y) { TouchMgr::GetInstance()->OnTouchPress(id, (float)x, (float)y); }
void Game::OnPointerDragged(int id, int x, int y) { TouchMgr::GetInstance()->OnTouchDrag(id, (float)x, (float)y); }
void Game::OnPointerReleased(int id, int x, int y) { TouchMgr::GetInstance()->OnTouchRelease(id, (float)x, (float)y); }
void Game::OnPointerCancelled(int id, int x, int y) { TouchMgr::GetInstance()->OnTouchCanceled(id, (float)x, (float)y); }
void Game::OnKeyPressed(int) {}
void Game::OnKeyReleased(int) {}

const jet::String &Game::GetShadowTagName() { return GameLevel::GetShadowTagName(); }

// @0x504a70: the shadow map target (a power of two from the shadow quality), its tiny depth viewport and the camera
// that looks at the scene from the light
void Game::InitShadowMapData() {
    m_shadowRT = jet::video::RenderTarget::New();
    unsigned size = 0x80;
    for (int i = 1; i < CGameConfig::Current().useShadows; i++) size <<= 1;
    m_shadowRT->Create(jet::String("shadowMapTarget"), jet::String("T565"), math::vec2<unsigned int>(size, size));
    m_shadowRT->SetClearColorBuffer(true);
    m_shadowRT->SetScissorRect(math::rect<unsigned int>(2, 2, size - 4, size - 4));
    m_shadowRT->SetScissorTest(true);
    m_shadowRT->SetClearDepthBuffer(true);
    jet::System::GetDriver()->AddRenderTarget(m_shadowRT);
    m_shadowCamera = new jet::scene::Camera(math::vec3<float>(0, 0, 0), math::quat<float>(0, 0, 0, 1));
    m_shadowCamera->SetOrthogonal(true);
    m_shadowCamera->SetFov(0.7853982f);
    m_shadowCamera->SetNearDistance(1.5f);
    m_shadowCamera->SetFarDistance(30.0f);
    jet::System::GetDriver()->SetGlobalUniform(jet::String("LightTextureMatrix"), jet::video::ShaderUniform(math::mat4<float>()));
}

// @0x504d08: the scene seen from the shadow camera into the shadow map, and the matrix that takes a world position to it
void Game::RenderShadowMap(jet::scene::SceneMgr *sm) {
    if (CGameConfig::Current().useShadows < 1) {
        sm->SetCamera(GameLevel::GetInstance()->GetCamera());
        return;
    }
    jet::scene::Camera *prev = sm->GetCamera();
    jet::video::Driver *drv = jet::System::GetDriver();
    drv->SetCrtRenderTarget(m_shadowRT);
    sm->SetCamera(m_shadowCamera);
    sm->Render(GetShadowTagName());
    drv->Flush();
    static const float k[16] = { 0.5f, 0, 0, 0, 0, 0.5f, 0, 0, 0, 0, 0.5f, 0, 0.5f, 0.5f, 0.5f, 1.0f };
    static math::mat4<float> bias(k);
    extern bool g_bIsTransitionMacho2Lab;
    if (g_bIsTransitionMacho2Lab) bias.m[12] = 0.492f;
    else if (bias.m[0] == 0.492f) bias.m[0] = 0.5f;
    math::mat4<float> lightMatrix = bias * m_shadowCamera->GetViewProjectionTransform();
    drv->SetGlobalUniform(jet::String("LightTextureMatrix"), jet::video::ShaderUniform(lightMatrix));
    drv->SetCrtRenderTarget(jet::System::GetDisplay(0)->GetRenderTarget());
    sm->SetCamera(prev);
}

bool g_bIsTransitionMacho2Lab = false;

// @0x50cdec
void Game::OnUnloadClaraData() {
    MenuMgr::GetInstance()->OnUnloadClaraData();
    BasicPage::OnUnloadClaraData();
}

// @0x50ce40: the main menu is up, the loading screen is over
void Game::OnMainMenuLoaded() { m_showingInitialScreens = false; }

// @0x50a514: reload the main menu through the loading screen
void Game::GoToMainMenu() {
    ClaraFilesMgr *f = ClaraFilesMgr::GetInstance();
    GameState::PushState(new GS_Loading(GS_Loading::GoTo_MainMenuFromGame, GS_Loading::Steps_Menu, f->GetLibFiles(), f->GetLevelFiles()), true);
}

// @0x50a39c
void Game::LoadFonts(babel::Lang lang) {
    FontMgr *f = FontMgr::GetInstance();
    f->ClearFonts();
    f->SetWrapOnAnyChar(lang.value() == babel::Lang::ZH);
    f->LoadFontDevicePolicy(jet::String("font_android_default"), lang);
    FontInfoMgr::GetInstance()->LoadFontsFor(lang);
}

// @0x50bf0c
void Game::FreeRandomizerModels() {
    m_randomizerModels.clear();
    jet::scene::ModelLoader::GetInstance()->FreeUnusedModelBases();
}

// @0x50d98c: the first and the third location are part of the game
bool Game::HasDLCDataFor(int location, bool) {
    if (location == 0 || location == 2) return true;
    return jet::stream::StreamMgr::GetInstance().CanCreateStream(ClaraFilesMgr::GetInstance()->LocationIdToDynamicLibFile(ELocation((ELocationDef::type)location)));
}
