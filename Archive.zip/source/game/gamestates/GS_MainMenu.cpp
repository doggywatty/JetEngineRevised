// source/game/gamestates/GS_MainMenu.cpp
#include "GS_MainMenu.h"
#include "GS_Loading.h"
#include "game/Game.h"
#include "game/GameLevel.h"
#include "game/entities/LevelDef.h"
#include "game/gamemanagers/ClaraFilesMgr.h"
#include "game/interfaces/menus/Menu_MainMenu.h"
#include "game/interfaces/menus/MenuMgr.h"
#include "scene/camera.h"
#include "scene/scenemgr.h"

const jet::String GS_MainMenu::k_stateName("GS_MainMenu");

// @0x49336c: the menu scene is set up by the level script, the menu pushed and its intro movie started
GS_MainMenu::GS_MainMenu(const jet::String &extraMenu) : m_wasRenderCalled(false), m_music(-1) {
    LevelDef::GetInstance()->OnInitMainMenu();
    MenuMgr *mm = MenuMgr::GetInstance();
    mm->PushMenu(Menu_MainMenu::k_menuName);
    mm->GetMenu(Menu_MainMenu::k_menuName);
    Menu_MainMenu::StartMainMenuIntroMovie();
    jet::scene::Camera *cam = GameLevel::GetInstance()->GetMenuSceneMgr()->GetCamera();
    if (cam) {
        cam->SetHorizontalFov(Game::GetInstance()->GetHFovFor(cam->GetFov(), false));
        m_hfov = cam->GetFov();
    }
    if (!extraMenu.empty()) mm->PushMenu(extraMenu);
}

GS_MainMenu::~GS_MainMenu() {}

// @0x49365c
void GS_MainMenu::ResumeState() {
    if (Menu_Base *m = MenuMgr::GetInstance()->GetMenu(Menu_MainMenu::k_menuName)) m->OnEnter();
}

void GS_MainMenu::SuspendState() {}

// @0x4936e0: the level goes on, the menu has the camera it was given, and a pressed play starts the game
void GS_MainMenu::UpdateState() {
    GameLevel *gl = GameLevel::GetInstance();
    gl->Update(false);
    if (jet::scene::Camera *cam = gl->GetMenuSceneMgr()->GetCamera()) cam->SetHorizontalFov(Game::GetInstance()->GetHFovFor(cam->GetFov(), true));
    if (!MenuMgr::GetInstance()->Movie_IsPlaying()) UpdateNormal();
}

// @0x493918
void GS_MainMenu::UpdateNormal() {
    Menu_MainMenu *m = static_cast<Menu_MainMenu*>(MenuMgr::GetInstance()->GetMenu(Menu_MainMenu::k_menuName));
    if (!m->IsStartPlay()) return;
    StartNormalGamePlay();
    m->Reset();
}

// @0x4838e4
void GS_MainMenu::RenderState() {
    GameLevel::GetInstance()->Render();
    m_wasRenderCalled = true;
}

// @0x483c34: leaves the menu scene and loads the level to play
void GS_MainMenu::StartNormalGamePlay() {
    LevelDef::GetInstance()->OnExitMainMenu();
    ClaraFilesMgr *f = ClaraFilesMgr::GetInstance();
    GameState::PushState(new GS_Loading(GS_Loading::GoTo_Gameplay, GS_Loading::Steps_Gameplay, f->GetLibFiles(), f->GetLevelFiles()), true);
}

void GS_MainMenu::StopMainMenuSfx() {}
