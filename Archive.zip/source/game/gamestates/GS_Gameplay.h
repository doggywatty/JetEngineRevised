// source/game/gamestates/GS_Gameplay.h
#ifndef SOURCE_GAME_GAMESTATES_GS_GAMEPLAY_H
#define SOURCE_GAME_GAMESTATES_GS_GAMEPLAY_H

// GameState.h is already real (ported earlier); jsingleton.h is the convention every other
// Singleton<T> subclass in this tree uses (see MenuMgr.h, GameSettings.h, etc).
#include <map>
#include "GameState.h"
#include "jsingleton.h"
#include "core/pstring.h"
class Menu_Ingame;
class MaterialDef;
namespace game::common { class TrackingSession; }

// sizeof verified @0x500560 (GS_Loading::_UpdateLoadingStep): mallocs 0x78 bytes right before
// constructing this, not the 0x60 this header's fields alone add up to -- see the undocumented map
// member below and re/NOTES.md for how that was found.
class GS_Gameplay : public GameState, public Singleton<GS_Gameplay> {  // sizeof 0x78
public:
    // Verified, not guessed: GS_Gameplay::UpdateGameplayMode() (0x4fcf4c) contains three back-to-back
    // jump tables keyed on (mode - 1), all consistent with each other and with the Begin/End method
    // names already in this header -- case 0 always dispatches to the Fluffy Begin/End pair, case 1 to
    // Rocket, case 2 to LargeMinion, case 3 to Boss, and mode value 0 (the "- 1 wraps to a huge unsigned
    // number, falls out of the 0..3 jump-table range" case) always skips every table, i.e. means "no
    // special mode" / Normal. See re/NOTES.md for the full disassembly.
    enum GameplayMode { Mode_Normal = 0, Mode_Fluffy = 1, Mode_Rocket = 2, Mode_LargeMinion = 3, Mode_Boss = 4 };
    // The PDB header had a stray non-virtual "void GetStateName();" alongside this real override --
    // same kind of extraction artifact as the missing-const GetMenuName() bug fixed on every Menu_*
    // class this session. Removed; this is the only GetStateName() GameState's pure virtual needs.
    virtual const jet::String &GetStateName();
    GS_Gameplay();
    virtual ~GS_Gameplay();
    virtual void ResumeState();
    virtual void SuspendState();
    virtual void UpdateState();
    virtual void RenderState();
    void OnResumeCountdownEnded();
    void UpdateSubStateInit();
    void UpdateSubStatePlaying();
    void UpdateGameplayMode();
    void StartFadeIn(unsigned);
    void StartFadeOut(unsigned);
    Menu_Ingame *GetInterface();
    void ReturnFromDeath();
    void EnableBonusGameplay(bool);
    bool IsInBonusGameplay();
    bool IsInShootingArea();
    void EnableShootingArea(unsigned char);
    unsigned char GetShootingAreaMask();
    void BeginFluffyGameplay();
    void EndFluffyGameplay();
    void BeginRocketGameplay();
    void EndRocketGameplay();
    void MakeFluffyInitialFlash();
    void MakeFluffyFinalFlash();
    bool IsLargeMinionGameplayMode();
    bool IsFluffyGameplayMode();
    bool IsRocketGameplayMode();
    bool IsBossGameplayMode();
    void BeginLargeMinionGameplay();
    void EndLargeMinionGameplay();
    void MakeLargeMinionFinalFlash();
    static void ApplyLargeMinionBeginChanges();
    static void ApplyLargeMinionEndChanges();
    void ApplyFluffyBeginChanges();
    void ApplyFluffyEndChanges();
    void MakeRocketInitialFlash();
    void MakeRocketFinalFlash();
    void MakeRocketCancelFlash();
    static void OnRocketFlashFinished();
    void ApplyRocketBeginChanges();
    void ApplyRocketEndChanges();
    void OnBossStarted();
    void OnBossDefeated();
    void OnBossEnded();
    void OnBossGameplayEnded();
    static void ApplyBossBeginChanges();
    static void ApplyBossEndChanges();
    void MakeBossInitialFlash();
    void MakeBossFinalFlash();
    void ApplyAmbianceSound(jet::String*, bool);
    void ApplyMusic(jet::String*, bool);
    void ApplySoundSettings(jet::String*, jet::String*);
    void ApplyGameplaySfxVolume(int);
    void ResetSfxVolume();
    void SetCurrentAmbienceSoundGain(float);
    void SetCurrentMusicGain(float);
    void SetGameplaySoundGain(float);
    void StartCheckpointLauncher(const unsigned&, const unsigned&);
    static void ReviveMinion();
    void BeginRevivingSequence();
    void SetBossGameplayMode(bool);
    void ForceEndBossGameplayMode();
    void SetProcessingRevive(bool);
    int GetMusicHandle();
    float GetCurrentRunTime();
private:
    void InitSound();
    void StopSound();
    void InitSessions();
    // Not in the PDB header, despite being a real, named symbol in the binary (GS_Gameplay::
    // RestartSessions(), 0x4fc8dc) -- an extraction gap like the ones found in other headers this
    // session, just for a private method instead of a missing include/member this time.
    void RestartSessions();
    void UpdateTimers();
    void RenderFadeEffect();
    void CheckGameplayEnd();
public:
    static const jet::String k_stateName;
private:
    // Not in the PDB header -- the real constructor (0x4fc260) builds a std::map<jet::String,int> (an
    // _Rb_tree ctor/dtor pair) and uses operator[] on it once, right after calling GetInterface()->
    // RestartGame(), before any of the fields below are touched. This is what makes the real sizeof
    // 0x78 instead of 0x60. Purpose not yet determined (possibly a per-checkpoint or per-trigger
    // counter) -- not read or written by any method ported so far, kept only so sizeof stops lying.
    std::map<jet::String, int> m_unverifiedCounterMap;
    int m_subState;  // 0x10
    int m_fadeTimer;  // 0x14
    unsigned m_fadeDuration;  // 0x18
    unsigned m_fadeTargetAlpha;  // 0x1C
    bool m_endGame;  // 0x20
    float m_invincibleTimer;  // 0x24
    jet::String m_ambienceSoundLabel;  // 0x28
    int m_ambienceSoundHandle;  // 0x2C
    jet::String m_musicLabel;  // 0x30
    int m_musicHandle;  // 0x34
    float m_gameplaySoundGain;  // 0x38
    bool m_isInBonusGameplay;  // 0x3C
    unsigned char m_shootingAreaClassMask;  // 0x3D
    GS_Gameplay::GameplayMode m_lastMode;  // 0x40
    GS_Gameplay::GameplayMode m_currentMode;  // 0x44
    GS_Gameplay::GameplayMode m_desiredMode;  // 0x48
    MaterialDef *m_oldPostFx;  // 0x4C
    game::common::TrackingSession *m_runSession;  // 0x50
    game::common::TrackingSession *m_currentRunSession;  // 0x54
    bool m_processingRevive;  // 0x58
    static const float s_recallInvincibleTime;
    static const jet::String k_factoryBossMusicStartLabel;
    static const jet::String k_factoryBossMusicEndLabel;
    unsigned m_previousBestScore;  // 0x5C
};

#endif
