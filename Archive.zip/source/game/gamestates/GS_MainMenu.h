// source/game/gamestates/GS_MainMenu.h
#ifndef SOURCE_GAME_GAMESTATES_GS_MAINMENU_H
#define SOURCE_GAME_GAMESTATES_GS_MAINMENU_H

#include "GameState.h"

// The main menu: the menu page over the lab scene.
// Not ported yet: the menu music and ambience (they need the sound manager), the 3D touches of the minion
// (they need the body part hit detection) and the statistics reset.
class GS_MainMenu : public GameState {  // sizeof 0x24
public:
    explicit GS_MainMenu(const jet::String &extraMenu);
    virtual ~GS_MainMenu();
    virtual const jet::String &GetStateName() { return k_stateName; }
    virtual void ResumeState();
    virtual void SuspendState();
    virtual void UpdateState();
    virtual void RenderState();
    static void StopMainMenuSfx();
    static const jet::String k_stateName;
private:
    void UpdateNormal();
    void StartNormalGamePlay();
    bool m_wasRenderCalled;  // 0xA
    int m_music;  // 0x14
    float m_hfov;  // 0x20
};

#endif
