// source/game/gamestates/GS_Shop.h
#ifndef SOURCE_GAME_GAMESTATES_GS_SHOP_H
#define SOURCE_GAME_GAMESTATES_GS_SHOP_H

class GS_Shop : public GameState {  // sizeof 0x1C
public:
    virtual const jet::String &GetStateName();
    GS_Shop();
    virtual ~GS_Shop();
    virtual void ResumeState();
    virtual void SuspendState();
    virtual void UpdateState();
    virtual void RenderState();
    static void GoToTab(Menu_Shop::EShopTabs);
    static const jet::String k_stateName;
private:
    static const jet::String k_musicLabel;
    int m_music;  // 0xC
    CameraController *m_oldCameraController;  // 0x10
    math::vec2<float> m_oldCurvature;  // 0x14
};

#endif
