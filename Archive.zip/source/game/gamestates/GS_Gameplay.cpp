// source/game/gamestates/GS_Gameplay.cpp
//
// Deliberately partial port. sizeof is now correct (0x78, see GS_Gameplay.h), and this is wired into
// GS_Loading's GoTo_Gameplay path, but ResumeState/SuspendState/UpdateState skip real logic this tree
// has no equivalent for yet: there is no SoundMgr class anywhere in this codebase (the sound work done
// earlier this session was the Musepack *codec*, not an engine-level sound manager singleton), so every
// SoundMgr::Resume/PauseAll call the real binary makes from these methods is left out rather than
// invented. UpdateSubStateInit now runs the level-start sequence (minus meta-progression subsystems --
// see its own comment) and UpdateSubStatePlaying drives the level forward every frame.
#include "GS_Gameplay.h"
#include "game/interfaces/menus/Menu_Ingame.h"
#include "game/interfaces/menus/MenuMgr.h"
#include "game/online/tracking/SessionTrackingMgr.h"
#include "game/GameLevel.h"
#include "game/entities/LevelDef.h"
#include "game/input/InputMgr.h"
#include "GS_Pause.h"
#include "game/Game.h"

const jet::String GS_Gameplay::k_stateName("GS_Gameplay");
const float GS_Gameplay::s_recallInvincibleTime = 1.0f;
const jet::String GS_Gameplay::k_factoryBossMusicStartLabel("");
const jet::String GS_Gameplay::k_factoryBossMusicEndLabel("");

const jet::String &GS_Gameplay::GetStateName() { return k_stateName; }

// Verified structure @0x4fc260: calls GetInterface()->RestartGame() and the still-unexplained map
// operator[] (see the header comment on m_unverifiedCounterMap) before InitSessions(). Member values
// below are this session's best-effort defaults for an untouched gameplay start, not individually
// verified against the constructor's immediate-field-store instructions the way GS_MainMenu's was --
// flagged since the layout gap above means this constructor couldn't be fully trusted line-by-line.
// m_subState(1): forced by UpdateState()'s dispatch (1->UpdateSubStateInit, 2->UpdateSubStatePlaying)
// together with UpdateSubStateInit() being the only place that writes m_subState (to 2, once) -- for the
// init pass to run exactly once right after construction the way the real binary's control flow
// requires, the constructor must set it to 1. Not an instruction-by-instruction verified store (the
// constructor's field-store instructions for this specific field weren't traced), but logically forced
// by the two methods that do have verified bodies.
GS_Gameplay::GS_Gameplay()
    : m_subState(1), m_fadeTimer(0), m_fadeDuration(0), m_fadeTargetAlpha(0), m_endGame(false),
      m_invincibleTimer(0.0f), m_ambienceSoundHandle(-1), m_musicHandle(-1), m_gameplaySoundGain(1.0f),
      m_isInBonusGameplay(false), m_shootingAreaClassMask(0), m_lastMode(Mode_Normal), m_currentMode(Mode_Normal),
      m_desiredMode(static_cast<GameplayMode>(-1)), m_oldPostFx(0), m_runSession(0), m_currentRunSession(0),
      m_processingRevive(false), m_previousBestScore(0) {
    if (Menu_Ingame *ig = GetInterface()) ig->RestartGame();
    InitSessions();
}

GS_Gameplay::~GS_Gameplay() {}

// Verified shape @0x4fc5bc, minus the SoundMgr::Resume() calls and an ambience-label-keyed map lookup
// this tree has no equivalent object for (no SoundMgr class exists here -- see the file header comment).
void GS_Gameplay::ResumeState() {
    if (m_runSession) m_runSession->Resume();
    if (m_currentRunSession) m_currentRunSession->Resume();
}

// Verified shape @0x4fc658, minus the SoundMgr::PauseAll() call for the same reason as ResumeState.
void GS_Gameplay::SuspendState() {
    if (m_runSession) m_runSession->Pause();
    if (m_currentRunSession) m_currentRunSession->Pause();
}

// Verified structure @0x4fc6b4: a mutex-guarded pause-request flag on the Game instance is checked first
// (pushes GS_Pause and returns if set -- now real, ported this update), then substate dispatch
// (1->UpdateSubStateInit, 2->UpdateSubStatePlaying), UpdateGameplayMode(), InitSound(), UpdateTimers(),
// CheckGameplayEnd(), then both sessions get Update(dt).
void GS_Gameplay::UpdateState() {
    if (Game::GetInstance()->ConsumePauseRequest()) {
        GameState::PushState(new GS_Pause(), true);
        Game::GetInstance()->SetGoToIGM(false);
        return;
    }
    if (m_subState == 1) UpdateSubStateInit();
    else if (m_subState == 2) UpdateSubStatePlaying();
    UpdateGameplayMode();
    UpdateTimers();
    CheckGameplayEnd();
}

// Verified @0x4fd0f0: GameLevel::Render() then RenderFadeEffect(). RenderFadeEffect isn't implemented
// yet (no fade-effect rendering path identified in this tree) -- left out rather than guessed.
void GS_Gameplay::RenderState() { GameLevel::GetInstance()->Render(); }

// Verified @0x4fdb0c: a tail call to MenuMgr::GetInstance()->GetMenu(Menu_Ingame::k_menuName).
Menu_Ingame *GS_Gameplay::GetInterface() {
    return static_cast<Menu_Ingame *>(MenuMgr::GetInstance()->GetMenu(Menu_Ingame::k_menuName));
}

// Verified @0x4fcf4c (UpdateGameplayMode): three consecutive jump tables keyed on (mode - 1), all
// agreeing case 0=Fluffy, 1=Rocket, 2=LargeMinion, 3=Boss, with mode 0 (Normal) skipping every table.
// The real tables call GameLevel::Begin/EndXGameplay() directly (not declared in GameLevel.h yet) and
// fetch a per-mode material via a vtable call this session hasn't identified -- left out rather than
// guessed. Only the mode bookkeeping itself (which the three tables all key off of) is reproduced here.
void GS_Gameplay::UpdateGameplayMode() {
    if (m_desiredMode == -1) return;
    m_lastMode = m_currentMode;
    m_currentMode = m_desiredMode;
    m_desiredMode = static_cast<GameplayMode>(-1);
}

bool GS_Gameplay::IsFluffyGameplayMode() { return m_currentMode == Mode_Fluffy; }
bool GS_Gameplay::IsRocketGameplayMode() { return m_currentMode == Mode_Rocket; }
bool GS_Gameplay::IsLargeMinionGameplayMode() { return m_currentMode == Mode_LargeMinion; }
bool GS_Gameplay::IsBossGameplayMode() { return m_currentMode == Mode_Boss; }

bool GS_Gameplay::IsInShootingArea() { return m_shootingAreaClassMask != 0; }
unsigned char GS_Gameplay::GetShootingAreaMask() { return m_shootingAreaClassMask; }
// Real EnableShootingArea @0x4fd304 also flips a flag on an unidentified global when the mask's
// zero/nonzero-ness changes (likely a touch-input lock) -- left out, only the mask store is real/safe.
void GS_Gameplay::EnableShootingArea(unsigned char mask) { m_shootingAreaClassMask = mask; }

bool GS_Gameplay::IsInBonusGameplay() { return m_isInBonusGameplay; }
void GS_Gameplay::EnableBonusGameplay(bool v) { m_isInBonusGameplay = v; }

void GS_Gameplay::SetBossGameplayMode(bool v) { if (v) m_currentMode = Mode_Boss; }

int GS_Gameplay::GetMusicHandle() { return m_musicHandle; }
void GS_Gameplay::SetProcessingRevive(bool v) { m_processingRevive = v; }

// Verified structure @0x4fcc88, conservatively trimmed. The real function also touches
// WeeklyChallengeMgr/MissionMgr/ChallengeMgr/IGNotificationMgr/AchievementsMgr/MessagesMgr/
// LevelSequenceGraph -- all real classes in this tree, but wiring seven meta-progression subsystems
// together in one pass (each with its own unverified internals) is too large a bite to take reliably
// here, and none of them are what actually makes the level run. Kept only the part that does: tell the
// level script gameplay is starting, restart the run-time session, flip to substate 2 (so this doesn't
// run again), advance the level once, and push the real in-game HUD (Menu_Ingame, already ported this
// session) so it's visible during gameplay instead of staying on whatever menu was showing. The skipped
// calls are meta-progression bookkeeping (challenges, missions, achievements, notifications) that would
// need their own disassembly+verification pass -- left for later rather than guessed at.
void GS_Gameplay::UpdateSubStateInit() {
    LevelDef::GetInstance()->OnInitGamePlay();
    RestartSessions();
    m_subState = 2;
    GameLevel::GetInstance()->Update(false);
    MenuMgr::GetInstance()->PushMenu(Menu_Ingame::k_menuName);
    // Not in the real UpdateSubStateInit (SetPlayer is called from elsewhere in the real binary, not
    // traced this session) -- added here as the most logical place in this tree's current call graph,
    // since LaunchEvents() (still unported, see InputMgr.cpp) null-checks m_player and does nothing
    // without it, and this is the first point a level's Minion is guaranteed to exist.
    InputMgr::GetInstance()->SetPlayer(GameLevel::GetInstance()->GetMinion());
}

// Verified structure @0x4fcee4, minus three early-return guards this session can't verify the meaning
// of yet (a field on Menu_Ingame at an unnamed offset, a field on GS_Gameplay itself at an unnamed
// offset, and a byte on an unidentified global -- all presumably some flavor of "is a dialog/movie/pause
// blocking gameplay"). Harmless to omit for now: nothing in this tree currently sets any of them, so
// skipping is behaviorally identical to evaluating them -- but if a future menu/dialog needs to pause
// the level update, these guards are the real mechanism and should be restored, not reinvented.
void GS_Gameplay::UpdateSubStatePlaying() { GameLevel::GetInstance()->Update(true); }

// Verified @0x4fcb40: m_invincibleTimer -= (a per-frame ms value this session hasn't traced back to a
// source in this tree) / 1000.0f. Left as a no-op rather than wiring to a guessed dt source -- nothing
// currently reads m_invincibleTimer, so this has no visible effect either way yet.
void GS_Gameplay::UpdateTimers() {}
void GS_Gameplay::CheckGameplayEnd() {}
void GS_Gameplay::InitSound() {}
void GS_Gameplay::StopSound() {}

// Verified @0x4fc8dc: only restarts m_currentRunSession, not m_runSession -- not a typo, the real binary
// really does only touch the one field.
void GS_Gameplay::RestartSessions() { if (m_currentRunSession) m_currentRunSession->Restart(); }

// Verified @0x4fc7b4: looks up (or creates) a "RUN_SESSION" tracking session and a "CURRENT_RUN_SESSION"
// one right after it, same GetSession-then-AddSession-if-null pattern for both.
void GS_Gameplay::InitSessions() {
    game::common::SessionTrackingMgr *sm = game::common::SessionTrackingMgr::GetInstance();
    m_runSession = sm->GetSession("RUN_SESSION");
    if (!m_runSession) m_runSession = sm->AddSession("RUN_SESSION");
    m_currentRunSession = sm->GetSession("CURRENT_RUN_SESSION");
    if (!m_currentRunSession) m_currentRunSession = sm->AddSession("CURRENT_RUN_SESSION");
}
