// source/game/gamestates/GS_EndGame.h
#ifndef SOURCE_GAME_GAMESTATES_GS_ENDGAME_H
#define SOURCE_GAME_GAMESTATES_GS_ENDGAME_H

class GS_EndGame : public GameState {  // sizeof 0xC
public:
    virtual const jet::String &GetStateName();
    GS_EndGame();
    virtual ~GS_EndGame();
    virtual void ResumeState();
    virtual void SuspendState();
    virtual void UpdateState();
    virtual void RenderState();
    static const jet::String k_stateName;
};

#endif
