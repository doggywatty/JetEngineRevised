// source/game/GameStdAfx.cpp
