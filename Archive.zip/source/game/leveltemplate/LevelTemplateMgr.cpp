// source/game/leveltemplate/LevelTemplateMgr.cpp
#include "game/leveltemplate/LevelTemplateMgr.h"
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include "game/GameLevel.h"
#include "game/Statistics.h"
#include "game/entities/BackgroundData.h"
#include "game/entities/PlatformInstance.h"
#include "game/entities/PlatformTemplate.h"
#include "game/entities/TemplateData.h"
#include "game/gamemanagers/BackgroundMgr.h"
#include "game/leveltemplate/GameplayTemplateInstance.h"
#include "game/leveltemplate/LevelTemplateDef.h"
#include "clarafile.h"
#include "folder.h"
#include "project.h"
#include "camera/cameramgr.h"
#include "scene/camera.h"
#include "system.h"
#include "video/driver.h"
#include "game/entities/Minion.h"

std::map<jet::String, LevelTemplateDef*> LevelTemplateMgr::s_levelTemplates, LevelTemplateMgr::s_backgroundTemplates;
bool LevelTemplateMgr::s_areLibrariesProcessed = false;
const jet::String LevelTemplateMgr::k__leftString("_left"), LevelTemplateMgr::k__rightString("_right"), LevelTemplateMgr::k__teeString("_tee"),
    LevelTemplateMgr::k__secretLeftString("_SecretLeft"), LevelTemplateMgr::k__secretRightString("_SecretRight"), LevelTemplateMgr::k__specialString("_Special"),
    LevelTemplateMgr::k__MacholabSpecialLeft("Macholab_Special_Left"), LevelTemplateMgr::k__MacholabSpecialRight("Macholab_Special_Right");

static jet::String TemplateKey(int id) {
    char b[20];
    snprintf(b, sizeof b, "%03d", id);
    return jet::String(b);
}

// the library name up to its first "_": "001_LAB" is template "001"
static jet::String TemplateNameOf(const jet::String &libName) {
    size_t u = libName.find_first_of('_', 0);
    return libName.substr(0, u);
}

static bool StartsWithDigit(const jet::String &s) { return s.size() && s.c_str()[0] >= '0' && s.c_str()[0] <= '9'; }

// @0x3e986c
void LevelTemplateMgr::LevelTemplateData::SetData(LevelTemplateSequenceProvider *p) {
    templateId = p->GetNextSequenceNumber();
    camera = p->GetNextCamera();
    cameraTransitionTime = p->GetNextCameraTransitionTime();
    speed = p->GetNextSpeed();
    location = p->GetNextLocation();
    bifurcation = LevelTemplateMgr::GetBifurcation(templateId);
    pause = LevelTemplateMgr::GetPause(templateId);
    nodeLabel = p->GetNextNodeLabel();
    nodeId = p->GetNextNodeId();
    nodeGraphId = p->GetNextNodeGraphId();
}

// @0x3e994c
LevelTemplateMgr::LevelTemplateMgr(LevelTemplateSequenceProvider *p)
    : m_provider(p), m_current(0), m_secretExitTaken(false), m_frameIndex(0), m_distance(0), m_cacheStarted(false), m_bifurcationBlocked(false), m_teeInCache(false), m_pausedCreation(false),
      m_pauseInCache(false), m_totalDistance(0), m_fastForward(false) {}

// @0x3e9bd4
LevelTemplateMgr::~LevelTemplateMgr() {
    for (LevelTemplateData *d : m_cache) delete d;
    for (GameplayTemplateInstance *g : m_instances) delete g;
}

// @0x3e9c90
void LevelTemplateMgr::BuildLevelTemplates(bool force) {
    if (s_areLibrariesProcessed && !force) return;
    clara::Project *prj = clara::Project::GetInstance();
    for (unsigned i = 0; i < prj->GetLibraryCount(); i++) {
        clara::ClaraFile *lib = prj->GetLibrary(i);
        const jet::String &name = lib->GetName();
        const clara::Folder &root = lib->GetRoot();
        if (StartsWithDigit(name)) {
            const jet::String key = TemplateNameOf(root.GetName());
            if (s_levelTemplates.find(key) != s_levelTemplates.end()) continue;
            LevelTemplateDef *def = new LevelTemplateDef;
            def->SetTemplateID((unsigned)atoi(key.c_str()));
            ProcessTemplateDefFolder(def, root);
            s_levelTemplates[key] = def;
        } else {
            const jet::String &prefix = BackgroundMgr::k_backgroundPrefix;
            if (prefix.size() && (!name.size() || !jet::detail::stristr(name.c_str(), prefix.c_str()))) continue;
            if (s_backgroundTemplates.find(root.GetName()) != s_backgroundTemplates.end()) continue;
            LevelTemplateDef *def = new LevelTemplateDef;
            ProcessTemplateDefFolder(def, root);
            s_backgroundTemplates[root.GetName()] = def;
        }
    }
    SetLevelTemplatesData();
    s_areLibrariesProcessed = true;
}

// @0x3e9f40
void LevelTemplateMgr::SetLevelTemplatesData() {
    for (auto &kv : s_levelTemplates) kv.second->ProcessTemplateData();
}

// @0x3e9fc8
void LevelTemplateMgr::CleanLevelTemplates(const std::vector<jet::String> &libraries) {
    for (const jet::String &lib : libraries) {
        std::map<jet::String, LevelTemplateDef*> &m = StartsWithDigit(lib) ? s_levelTemplates : s_backgroundTemplates;
        auto it = m.find(StartsWithDigit(lib) ? TemplateNameOf(lib) : lib);
        if (it == m.end()) continue;
        delete it->second;
        m.erase(it);
    }
}

// @0x3ea154
void LevelTemplateMgr::CleanLevelTemplates() {
    for (auto &kv : s_levelTemplates) delete kv.second;
    s_levelTemplates.clear();
    for (auto &kv : s_backgroundTemplates) delete kv.second;
    s_backgroundTemplates.clear();
    s_areLibrariesProcessed = false;
}

// @0x3eabb4
void LevelTemplateMgr::ProcessTemplateDefFolder(LevelTemplateDef *def, const clara::Folder &f) {
    for (unsigned i = 0; i < f.GetEntityCount(); i++) def->AddEntity(f.GetEntity(i));
    for (unsigned i = 0; i < f.GetFolderCount(); i++) ProcessTemplateDefFolder(def, f.GetFolder(i));
}

// @0x3ebb90, @0x3ebcf0, @0x3ebc4c
Bifurcation LevelTemplateMgr::GetBifurcation(int id) {
    auto it = s_levelTemplates.find(TemplateKey(id));
    return it == s_levelTemplates.end() ? Bifurcation_Center : it->second->GetTemplateData()->GetGroundPlatform(false)->GetDefinition()->GetBifurcation();
}
bool LevelTemplateMgr::GetPause(int id) {
    auto it = s_levelTemplates.find(TemplateKey(id));
    return it != s_levelTemplates.end() && it->second->IsPauseTemplate();
}
LevelTemplateDef *LevelTemplateMgr::GetLevelTemplateDef(int id) {
    auto it = s_levelTemplates.find(TemplateKey(id));
    return it == s_levelTemplates.end() ? 0 : it->second;
}

// @0x3ec2a8
int LevelTemplateMgr::GetBGLocation(const jet::String &name) {
    auto it = s_backgroundTemplates.find(BackgroundMgr::k_backgroundPrefix + name);
    return it == s_backgroundTemplates.end() ? -1 : it->second->GetBackgroundData()->GetLocation();
}

// @0x3dbb18
GameplayTemplateInstance *LevelTemplateMgr::BuildLevelPart(const jet::String &name) {
    auto it = s_levelTemplates.find(name);
    return it == s_levelTemplates.end() ? 0 : new GameplayTemplateInstance(it->second);
}

// @0x3da7c0: the next template of the sequence joins the cache of four
void LevelTemplateMgr::CacheLevelSequence() {
    if (!m_cacheStarted) m_cacheStarted = true;
    else m_provider->IncSequenceNumber();
    GameLevel::GetInstance()->UpdateUsedDynamicLibraries();
    LevelTemplateData *d;
    if (m_cache.size() < 4) d = new LevelTemplateData(m_provider);
    else {
        d = m_cache.front();
        d->SetData(m_provider);
        m_cache.pop_front();
    }
    if (d->bifurcation == Bifurcation_Tee) m_teeInCache = true;
    if (d->pause) m_pauseInCache = true;
    m_cache.push_back(d);
}

// @0x3da8b8: a template of the cache was made, the cache is refilled unless a tee or a pause stops it
void LevelTemplateMgr::ConsumeCacheLevelSequence() {
    if (!m_teeInCache && !m_pauseInCache) {
        CacheLevelSequence();
        return;
    }
    if (m_cache.empty()) return;
    delete m_cache.front();
    m_cache.pop_front();
    GameLevel::GetInstance()->UpdateUsedDynamicLibraries();
}

// @0x3da954
void LevelTemplateMgr::CacheInitialLevelSequence() {
    for (int i = 0; i < 4; i++)
        if (!m_teeInCache && !m_pauseInCache) CacheLevelSequence();
}

// @0x3da990
void LevelTemplateMgr::PopulateCacheSequenceBuffer() {
    for (size_t n = m_cache.size(); n < 4; n++)
        if (!m_teeInCache && !m_pauseInCache) CacheLevelSequence();
}

// @0x3da9f4
void LevelTemplateMgr::ResumeCreation() {
    if (!m_pausedCreation || !m_pauseInCache) return;
    m_pausedCreation = false;
    m_pauseInCache = false;
    PopulateCacheSequenceBuffer();
}

// @0x3daa1c
unsigned LevelTemplateMgr::AdvanceLevelSequence(unsigned distance) {
    unsigned covered = 0;
    for (;;) {
        LevelTemplateData *d = m_cache.front();
        LevelTemplateDef *def = s_levelTemplates[TemplateKey(d->templateId)];
        const float size = def->GetSizeY();
        const unsigned next = (size > 0 ? (unsigned)size : 0) + covered;
        if (distance < next) break;
        HistoryData h = { def, d->location };
        switch (def->GetGroundPlatform()->GetDefinition()->GetBifurcation()) {
        case Bifurcation_Left: h.location.append(k__leftString); break;
        case Bifurcation_Right: h.location.append(k__rightString); break;
        case Bifurcation_Tee: h.location.append(k__teeString); break;
        default: break;
        }
        m_history.push_back(h);
        CacheLevelSequence();
        covered = next;
    }
    return covered;
}

// @0x3dac30: the first template of the cache is made, placed at the end of the one before
GameplayTemplateInstance *LevelTemplateMgr::CreateGameplayTemplateInstance() {
    LevelTemplateData *d = m_cache.front();
    GameplayTemplateInstance *g = BuildLevelPart(TemplateKey(d->templateId));
    g->SetCamera(d->camera, d->cameraTransitionTime);
    g->SetSpeed(d->speed);
    g->SetCreationNodeLabel(d->nodeLabel);
    g->SetCreationNodeId(d->nodeId);
    g->SetCreationNodeGraphId(d->nodeGraphId);
    jet::String location = d->location;
    if (!g->HasSecretExit()) {
        switch (g->GetBifurcation()) {
        case Bifurcation_Left:
            if (!location.Equals(k__MacholabSpecialLeft)) location.append(k__leftString);
            break;
        case Bifurcation_Right:
            if (!location.Equals(k__MacholabSpecialRight)) location.append(k__rightString);
            break;
        case Bifurcation_Tee: location.append(k__teeString); break;
        default:
            if (m_secretExitTaken) {
                location.append(k__specialString);
                Statistics::GetInstance()->IncreaseStatistic(StatisticsSaveData::k_statScope_secreatAreaCount, 1);
                m_secretExitTaken = false;
            }
        }
    } else {
        const Bifurcation dir = g->GetSecretExitDirection();
        if (dir == Bifurcation_Left) location.append(k__secretLeftString);
        else if (dir == Bifurcation_Right) location.append(k__secretRightString);
    }
    g->SetLocation(location);
    g->SetTemplateID(d->templateId);
    HistoryData h = { g->GetDefinition(), g->GetLocation() };
    m_history.push_back(h);
    const Bifurcation bif = g->GetBifurcation();
    if (bif < Bifurcation_Tee) g->ResolveBifurcation(bif);
    else m_bifurcationBlocked = true;
    if (g->IsPauseTemplate()) m_pausedCreation = true;
    GameplayTemplateInstance *previous = m_current;
    if (m_instances.empty()) {
        if (m_current && (m_current->GetBifurcation() == Bifurcation_Tee || m_current->IsPauseTemplate())) {
            math::vec3<float> p(0, 0, 0);
            float a = 0;
            m_current->GetEndAnchor(p, a);
            g->SetStartAnchor(p, a);
        }
    } else {
        previous = m_instances.back();
        math::vec3<float> p(0, 0, 0);
        float a = 0;
        previous->GetEndAnchor(p, a);
        g->SetStartAnchor(p, a);
    }
    GameLevel *gl = GameLevel::GetInstance();
    g->SpawnEntities(gl->GetEntityToSpawnCount(), previous);
    gl->RemoveEntities();
    m_instances.push_back(g);
    const float size = g->GetDefinition()->GetSizeY();
    m_totalDistance += size > 0 ? (int)size : 0;
    g->SetDistanceToRemove((unsigned)m_totalDistance);
    ConsumeCacheLevelSequence();
    g->SetStartDistance(m_distance);
    m_distance += g->GetDefinition()->GetSizeY();
    return g;
}

// @0x3ebabc
void LevelTemplateMgr::OnCreateGameplayTemplateInstance() { BackgroundMgr::GetInstance()->OnCreateGameplayTemplateInstance(); }

// @0x3da254: the first templates are made, the first of them is the current one
void LevelTemplateMgr::InitLevelParts() {
    for (int i = 0; i < 4; i++) {
        CreateGameplayTemplateInstance();
        OnCreateGameplayTemplateInstance();
        if (m_bifurcationBlocked || m_pausedCreation) break;
    }
    m_current = m_instances.front();
    if (!m_current->IsEnabled()) m_current->SetEnabled(true);
    m_instances.pop_front();
}

// @0x3da2dc
void LevelTemplateMgr::CleanLevelParts() {
    if (m_current) m_current->DeleteEntities();
    delete m_current;
    m_current = 0;
    for (GameplayTemplateInstance *g : m_instances) {
        g->DeleteEntities();
        delete g;
    }
    m_instances.clear();
    m_history.clear();
    for (LevelTemplateData *d : m_cache) delete d;
    m_cache.clear();
}

// @0x3db08c
const jet::String &LevelTemplateMgr::GetLastBackgroundLocation() const { return m_instances.back()->GetLocation(); }

// @0x3db028: the last template made (the current one while the others are not)
void LevelTemplateMgr::GetNextBackgroundInfo(BackgroundInfo &info) const {
    GameplayTemplateInstance *g = m_instances.empty() ? m_current : m_instances.back();
    g->GetStartAnchor(info.position, info.angle);
    info.bifurcation = g->GetBifurcation();
    info.size = info.size2 = g->GetDefinition()->GetSizeY();
}

// @0x4c0638
bool UpdateTemplateVisibility(LevelTemplateInstance *inst, unsigned distance, float end, float prevEnd) {
    float fogNear = 0, fogFar = 120.0f;
    LevelTemplateDef *def = inst->GetDefinition();
    const math::vec3<float> &front = CameraMgr::GetInstance()->GetSceneCamera()->GetFrontVector();
    const math::vec3<float> &dir = inst->GetDirection();
    const float dot = front.x * dir.x + front.y * dir.y + front.z * dir.z;
    const float margin = dot >= 0.0f ? 5.0f : -5.0f;
    const bool behind = dot < 0.0f;
    const float d = (float)distance;
    jet::video::Color c;
    if (!inst->IsEnabled()) {
        if (def && def->GetBackgroundData()) def->UseFog(&c, &fogNear, &fogFar);
        if (prevEnd <= d + fogFar && (behind || d < margin + end)) {
            inst->SetEnabled(true);
            return true;
        }
        return false;
    }
    if (behind || d < margin + end) {
        if (def && def->GetBackgroundData()) def->UseFog(&c, &fogNear, &fogFar);
        if (prevEnd <= d + fogFar) return false;
    }
    inst->SetEnabled(false);
    return true;
}

// @0x3ea410
bool LevelTemplateMgr::UpdateVisibilities() {
    Minion *minion = GameLevel::GetInstance()->GetMinion();
    if (!minion) return false;
    const unsigned distance = minion->GetTraveledDistance();
    bool changed = false;
    GameplayTemplateInstance *prev = m_current;
    for (GameplayTemplateInstance *g : m_instances) {
        if (!g->SpawningFinished() || g->HasPendingPlatformInstances()) continue;
        changed |= UpdateTemplateVisibility(g, distance, (float)g->GetDistanceToRemove(), prev ? (float)prev->GetDistanceToRemove() : 0.0f);
        prev = g;
    }
    return changed;
}

// @0x3db4b4: the current template is spawned, then the platforms' objects one at a time; with all done the next template is made (up to four
// ahead). What the action phase adds (the cameras and the minion's state at a change, the bifurcation, advancing along the list) joins with it.
bool LevelTemplateMgr::UpdateTemplateInstanceBuilding() {
    const unsigned frame = jet::System::GetDriver()->GetFrameIdx();
    if (frame == m_frameIndex) return false;
    bool created = false;
    if (m_current) {
        GameLevel *gl = GameLevel::GetInstance();
        if (!m_current->SpawningFinished()) {
            m_current->SpawnEntities(gl->GetEntityToSpawnCount(), 0);
            gl->RemoveEntities();
        } else {
            m_current->UpdateDelayedPlatformInstances();
            gl->RemoveEntities();
            bool allFinished = true;
            GameplayTemplateInstance *prev = m_current;
            for (GameplayTemplateInstance *g : m_instances) {
                if (!g->SpawningFinished()) {
                    g->SpawnEntities(gl->GetEntityToSpawnCount(), prev);
                    allFinished = false;
                    gl->RemoveEntities();
                    break;
                }
                if (g->HasPendingPlatformInstances()) allFinished = false;
                g->UpdateDelayedPlatformInstances();
                gl->RemoveEntities();
                prev = g;
            }
            if (!m_bifurcationBlocked && !m_pausedCreation && allFinished && m_instances.size() < 4) {
                CreateGameplayTemplateInstance();
                OnCreateGameplayTemplateInstance();
                created = true;
            }
        }
        m_frameIndex = frame;
    }
    return created;
}

// @0x3ea3c8
void LevelTemplateMgr::UpdateLevelParts() {
    UpdateTemplateInstanceBuilding();
    UpdateVisibilities();
}
