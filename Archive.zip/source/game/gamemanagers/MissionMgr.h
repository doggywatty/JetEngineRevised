// source/game/gamemanagers/MissionMgr.h
#ifndef SOURCE_GAME_GAMEMANAGERS_MISSIONMGR_H
#define SOURCE_GAME_GAMEMANAGERS_MISSIONMGR_H

#include <vector>
#include "jsingleton.h"
#include "core/pstring.h"
#include "game/utils/GameSaveable.h"

// What is saved of the missions: the active ones, the missions sets in progress, the repeated ones and the completed ids
struct MissionMgrSaveData {
    struct ActiveMissionInfo { jet::String id; int a; int state; ActiveMissionInfo() : a(0), state(0) {} };    // 0xC
    struct SaveMissionSetInfo { jet::String id; unsigned index; jet::String next; SaveMissionSetInfo() : index(0) {} };  // 0xC
    struct RepeatedMissionInfo { jet::String id; int count; RepeatedMissionInfo() : count(0) {} };           // 0x8
    unsigned multiplierLevel;                          // 0x0
    unsigned multiplierPoints;                         // 0x4
    int u8;                                            // 0x8
    std::vector<ActiveMissionInfo> activeMissions;     // 0xC
    std::vector<SaveMissionSetInfo> missionSets;       // 0x18
    std::vector<RepeatedMissionInfo> repeatedMissions; // 0x24
    std::vector<jet::String> v30;                      // 0x30
    std::vector<jet::String> v3c;                      // 0x3C
    std::vector<jet::String> completedMissionIds;      // 0x48
    MissionMgrSaveData() : multiplierLevel(0), multiplierPoints(0), u8(-1) {}
};

// The missions of the player and their progress, saved as the record "MissionMgr". Not ported yet: starting, completing
// and repeating missions, the multiplier levels and the in-game notifications.
class MissionMgr : public Singleton<MissionMgr>, public GameSaveable<MissionMgrSaveData> {  // sizeof 0xE8
public:
    static const int k_signatureV1 = 0xaa0006, k_signatureV2 = 0xbb0006, k_saveGameVersion = 2;
    static const jet::String k_saveRecordName;
    MissionMgr() : m_loadedV1(false) {}
    virtual ~MissionMgr() {}
    virtual void ResetData(MissionMgrSaveData &d) const;
    virtual void SaveDataInStream(jet::stream::IStreamW &s, MissionMgrSaveData &d) const;
    virtual bool LoadDataFromStream(jet::stream::IStream &s, MissionMgrSaveData &d) const;
    void Reset() { ResetData(m_data); }
    // the level of the score multiplier
    unsigned GetMultiplierLevel() const { return m_data.multiplierLevel; }
    unsigned GetMultiplierLevelPoints() const { return m_data.multiplierPoints; }
    unsigned GetActiveMissionCount() const { return (unsigned)m_data.activeMissions.size(); }
    const MissionMgrSaveData::ActiveMissionInfo &GetActiveMissionInfo(unsigned i) const { return m_data.activeMissions[i]; }
    bool WasMissionIdCompleted(const jet::String &id) const;
private:
    void SerializeV1(jet::stream::IStreamW &s, MissionMgrSaveData &d) const;
    void SerializeV2(jet::stream::IStreamW &s, MissionMgrSaveData &d) const;
    bool DeserializeV1(jet::stream::IStream &s, MissionMgrSaveData &d) const;
    bool DeserializeV2(jet::stream::IStream &s, MissionMgrSaveData &d) const;
    mutable bool m_loadedV1;  // 0xB0
};

#endif
