// source/game/gamemanagers/CostumeMgr.cpp
