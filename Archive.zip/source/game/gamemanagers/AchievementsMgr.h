// source/game/gamemanagers/AchievementsMgr.h
#ifndef SOURCE_GAME_GAMEMANAGERS_ACHIEVEMENTSMGR_H
#define SOURCE_GAME_GAMEMANAGERS_ACHIEVEMENTSMGR_H

class AchievementsMgr : public Singleton<AchievementsMgr>, public GameSaveable<AchievementsMgrSaveData> {  // sizeof 0x30
public:
    AchievementsMgr();
    virtual ~AchievementsMgr();
    void Reset();
    virtual void ResetData(AchievementsMgrSaveData&);
    virtual void SaveDataInStream(jet::stream::IStreamW&, AchievementsMgrSaveData&);
    virtual bool LoadDataFromStream(jet::stream::IStream&, AchievementsMgrSaveData&);
    void OnAchievementJustCompleted(const jet::String&);
    bool HasAnyPrizeToClaim();
    bool WasPrizeClaimedFor(const jet::String&);
    void SetPrizeClaimedFor(const jet::String&);
    unsigned GetCountCompletedAchievements();
private:
    void SerializeV1(jet::stream::IStreamW&, AchievementsMgrSaveData&);
    bool DeserializeV1(jet::stream::IStream&, AchievementsMgrSaveData&);
public:
    static const jet::String k_saveRecordName;
private:
    static const int k_saveGameVersion;
    static const int k_signatureV1;
};

#endif
