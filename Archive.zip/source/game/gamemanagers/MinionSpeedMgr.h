// source/game/gamemanagers/MinionSpeedMgr.h
#ifndef SOURCE_GAME_GAMEMANAGERS_MINIONSPEEDMGR_H
#define SOURCE_GAME_GAMEMANAGERS_MINIONSPEEDMGR_H

class MinionSpeedMgr : public Singleton<MinionSpeedMgr> {  // sizeof 0x48
public:
    MinionSpeedMgr();
    virtual ~MinionSpeedMgr();
    void PostInit();
    void Update(unsigned);
    void OnAdvanceLevelTemplateList();
    void OnMinionRevive();
    float GetCurrentSpeed();
    void SetSpeedForcedByScript(bool, float);
private:
    void SetSpeedDelayer();
public:
    static const jet::String k_SpeedEvolutionSet_tmplName;
    static const jet::String k_SpeedIntervalDef_tmplName;
private:
    jet::core::Delayer<float,jet::core::LinearStep> m_speedDelayer;  // 0x4
    std::vector<MinionSpeedMgr::SpeedInterval *,std::allocator<MinionSpeedMgr::SpeedInterval *> > m_speedIntervals;  // 0x1C
    unsigned m_distanceRunnedOnCurrentRoom;  // 0x30
    unsigned m_roomsRunned;  // 0x34
    int m_currentInterval;  // 0x38
    int m_speedIntervalOnRevive;  // 0x3C
    bool m_forceSpeedByScript;  // 0x40
    float m_speedByScript;  // 0x44
    static const float k_roomSize;
    static const jet::String k_speedIntervalsParam;
    static const jet::String k_roomAmountParam;
    static const jet::String k_speedParam;
    static const jet::String k_speedIntervalOnReviveParam;
};

#endif
