// source/game/gamemanagers/CostumeMgr.h
#ifndef SOURCE_GAME_GAMEMANAGERS_COSTUMEMGR_H
#define SOURCE_GAME_GAMEMANAGERS_COSTUMEMGR_H

class CostumeMgr : public Singleton<CostumeMgr>, public GameSaveable<CostumeMgrSaveData> {  // sizeof 0x54
public:
    CostumeMgr();
    virtual ~CostumeMgr();
    void Reset();
    void Update();
    unsigned GetCostumeRefCount();
    MinionCostume *GetCostumeRef(unsigned);
    MinionCostume *GetEquippedCostumeRef();
    MinionCostume *GetPlaceHolderCostumeRef();
    void SetEquippedCostume(MinionCostume*, bool);
    void MarkAsBought(MinionCostume*);
    bool WasBought(MinionCostume*);
    const jet::String &GetEquippedCostumeName();
    unsigned GetCountBoughtCostumes();
    void SetEquippedCostumeNameFrom(MinionCostume*);
    bool IsCurrentCostumeADressup();
    virtual void ResetData(CostumeMgrSaveData&);
    virtual void SaveDataInStream(jet::stream::IStreamW&, CostumeMgrSaveData&);
    virtual bool LoadDataFromStream(jet::stream::IStream&, CostumeMgrSaveData&);
private:
    void SetCostumesVisible(bool);
    void ClearAll();
    MinionCostume *FindCostumeRefByName(const jet::String&);
    void SerializeV1(jet::stream::IStreamW&, CostumeMgrSaveData&);
    bool DeserializeV1(jet::stream::IStream&, CostumeMgrSaveData&);
public:
    static const jet::String k_saveRecordName;
    static const jet::String k_folderName;
    static const jet::String k_defaultCostumeName;
private:
    std::vector<MinionCostume *,std::allocator<MinionCostume *> > m_costumesRefs;  // 0x38
    MinionCostume *m_equippedCostumeRef;  // 0x4C
    MinionCostume *m_placeholderCostumeRef;  // 0x50
    static const int k_saveGameVersion;
    static const int k_signatureV1;
};

#endif
