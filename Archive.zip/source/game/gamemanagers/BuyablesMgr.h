// source/game/gamemanagers/BuyablesMgr.h
#ifndef SOURCE_GAME_GAMEMANAGERS_BUYABLESMGR_H
#define SOURCE_GAME_GAMEMANAGERS_BUYABLESMGR_H

class BuyablesMgr : public Singleton<BuyablesMgr> {  // sizeof 0x18
public:
    BuyablesMgr();
    virtual ~BuyablesMgr();
    void Reset();
    void Update();
    void AddBuyable(Buyable*);
    std::vector<Buyable *,std::allocator<Buyable *> > GetBuyablesSortedByPrice(const jet::String&);
private:
    void ClearAll();
    std::vector<Buyable *,std::allocator<Buyable *> > m_buyables;  // 0x4
};

#endif
