// source/game/gamemanagers/PowerUpMgr.h
#ifndef SOURCE_GAME_GAMEMANAGERS_POWERUPMGR_H
#define SOURCE_GAME_GAMEMANAGERS_POWERUPMGR_H

class PowerUpMgr : public Singleton<PowerUpMgr> {  // sizeof 0x18
public:
    PowerUpMgr();
    virtual ~PowerUpMgr();
    void ResetAll();
    void ResetPerks();
    void DisableAll();
    void DisableAllButOne(safe_enum<EPowerUpDef,enum EPowerUpDef::type>);
    void Update();
    void EnablePowerUp(safe_enum<EPowerUpDef,enum EPowerUpDef::type>, int);
    void DisablePowerUp(safe_enum<EPowerUpDef,enum EPowerUpDef::type>);
    void CancelPowerUp(safe_enum<EPowerUpDef,enum EPowerUpDef::type>);
    bool IsPowerUpActive(safe_enum<EPowerUpDef,enum EPowerUpDef::type>);
    void OnPowerUpEnabled(safe_enum<EPowerUpDef,enum EPowerUpDef::type>);
    void OnPowerUpDisabled(safe_enum<EPowerUpDef,enum EPowerUpDef::type>);
    const PowerUpMgr::PowerUpStatus &GetPowerUpStatus(safe_enum<EPowerUpDef,enum EPowerUpDef::type>);
    void SetPerk(safe_enum<PowerUpMgr::EPowerUpPerkDef,enum PowerUpMgr::EPowerUpPerkDef::type>, bool);
    bool HasPerk(safe_enum<PowerUpMgr::EPowerUpPerkDef,enum PowerUpMgr::EPowerUpPerkDef::type>);
    static jet::String GetPowerUpStringId(safe_enum<EPowerUpDef,enum EPowerUpDef::type>);
    static const int k_infiniteTime;
private:
    safe_enum<PowerUpMgr::EPowerUpPerkDef,enum PowerUpMgr::EPowerUpPerkDef::type> m_activePerks;  // 0x4
    ustl::vector<PowerUpMgr::PowerUpStatus> m_powerUpStatus;  // 0x8
};

#endif
