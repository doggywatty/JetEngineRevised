// source/game/gamemanagers/GameSoundMgr.h
#ifndef SOURCE_GAME_GAMEMANAGERS_GAMESOUNDMGR_H
#define SOURCE_GAME_GAMEMANAGERS_GAMESOUNDMGR_H

class GameSoundMgr : public Singleton<GameSoundMgr> {  // sizeof 0x44
public:
    GameSoundMgr();
    virtual ~GameSoundMgr();
    void ClearDelayedSounds();
    void Update();
    void UpdateDelayedSounds();
    void UpdateSoundInfo();
    void PlaySoundDelayed(const jet::String&, float);
    int Play(const jet::String&, float, const math::vec3<float>&, unsigned);
    void ResetCoinCollectedSound();
    void UpdateCollideCoindSound();
    void PlayCollideCoinSound(const jet::String&, const math::vec3<float>&);
private:
    std::list<GameSoundMgr::DelayedSound,std::allocator<GameSoundMgr::DelayedSound> > m_delayedSounds;  // 0x4
    std::map<jet::String,GameSoundMgr::PlayedSoundInfo,std::less<jet::String>,std::allocator<std::pair<jet::String const ,GameSoundMgr::PlayedSoundInfo> > > m_playedSounds;  // 0x1C
    int m_lastCoindCollectedTimer;  // 0x38
    int m_coinCollectedCombo;  // 0x3C
    int m_coinCollectedHappyCombo;  // 0x40
    static const float k_materialBlockCooldownSound;
    static const float k_collideCoinCooldownSound;
    static const int k_bananaInComboTime;
    static const int k_bananaInGroupTime;
    static const int k_bananGroupNumber;
    static const int k_bananaHappyComboCount;
    static const jet::String k_bananaComboLabel;
    static const jet::String k_bananaHappyComboLabel;
};

#endif
