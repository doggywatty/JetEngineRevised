// source/game/gamemanagers/BonusUpgradeMgr.h
#ifndef SOURCE_GAME_GAMEMANAGERS_BONUSUPGRADEMGR_H
#define SOURCE_GAME_GAMEMANAGERS_BONUSUPGRADEMGR_H

class BonusUpgradeMgr : public Singleton<BonusUpgradeMgr>, public GameSaveable<BonusUpgradeMgrSaveData> {  // sizeof 0x34
public:
    BonusUpgradeMgr();
    virtual ~BonusUpgradeMgr();
    void Reset();
    virtual void ResetData(BonusUpgradeMgrSaveData&);
    virtual void SaveDataInStream(jet::stream::IStreamW&, BonusUpgradeMgrSaveData&);
    virtual bool LoadDataFromStream(jet::stream::IStream&, BonusUpgradeMgrSaveData&);
    unsigned GetBonusCount();
    const BonusUpgradeMgrSaveData::BonusInfo &GetBonusInfo(unsigned);
    void OnBonusLevelChanged(Bonus*);
private:
    void SerializeV1(jet::stream::IStreamW&, BonusUpgradeMgrSaveData&);
    bool DeserializeV1(jet::stream::IStream&, BonusUpgradeMgrSaveData&);
public:
    static const jet::String k_saveRecordName;
private:
    static const int k_saveGameVersion;
    static const int k_signatureV1;
    BonusSet *m_bonusSet;  // 0x30
};

#endif
