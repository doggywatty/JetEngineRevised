// source/game/gamemanagers/FlareMgr.cpp
#include "FlareMgr.h"
#include "../entities/LensFlareEntity.h"

// @0x484b64
void FlareMgr::AddFlare(LensFlareEntity *e, const math::vec3<float> &pos, const math::quat<float> &rot) {
    Flare *f = new Flare;
    f->entity = e;
    e->SetRenderable(false);
    f->position = pos;
    f->rotation = rot;
    f->occluded = false;
    m_flares.push_back(f);
}

// @0x484c98
void FlareMgr::CleanFlares() {
    for (Flare *f : m_flares) delete f;
    m_flares.clear();
}
