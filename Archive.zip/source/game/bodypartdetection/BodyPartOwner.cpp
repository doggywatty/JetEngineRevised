// source/game/bodypartdetection/BodyPartOwner.cpp
#include "BodyPartOwner.h"
#include "scene/model.h"
#include "scene/node.h"
#include "entity.h"
#include "param.h"
#include <algorithm>

std::vector<BodyPartOwner*> BodyPartOwner::s_damageables;
jet::String BodyPartOwner::k_SimpleBodyPartDefinition_tmplName("SimpleBodyPartDefinition");
jet::String BodyPartOwner::k_TouchInteractBodyPartDefinition_tmplName("TouchInteractBodyPartDefinition");

BodyPartDefinition::BodyPartDefinition()
    : radius(0), height(0), angle(0), cylinderCover(false), position(0, 0, 0), rotation(0, 0, 0, 1),
      type(0), touchEvent(0), linked3dLayer(0), baseRadius(0), baseHeight(0) {}

// IsReadyToCheck @0x500b58: enabled, and when a touch state is set, only while bit 8 is clear
bool BodyPartSection::IsReadyToCheck() const {
    if (!(flags & Enabled)) return false;
    if (flags & 6) return !(flags & 8);
    return true;
}

BodyPartOwner::BodyPartOwner() : m_classType(ClassType_Default), m_hitSphereRadius(0), m_hitSpherePos(0, 0, 0), m_pModel(0), m_pOwner(0), m_sceneMgrId(0) {}

BodyPartOwner::~BodyPartOwner() {
    BPO_Enable(false);
    BPO_Release();
}

// BPO_Init @0x525010
void BodyPartOwner::BPO_Init(jet::scene::Model *m) {
    m_pOwner = this;
    m_pModel = m;
    m_hitSpherePos = m->GetBoundingSphereCenter();
    m_hitSphereRadius = m->GetBoundingSphereRadius();
}

// BPO_Enable @0x52503c: membership in the global damageable list
void BodyPartOwner::BPO_Enable(bool on) {
    std::vector<BodyPartOwner*>::iterator it = std::find(s_damageables.begin(), s_damageables.end(), this);
    if (on) {
        if (it == s_damageables.end()) s_damageables.push_back(this);
    } else if (it != s_damageables.end()) {
        s_damageables.erase(it);
    }
}

void BodyPartOwner::BPO_Release() {
    while (!m_bodyParts.empty()) BPO_RemoveBodyPart(m_bodyParts[0].def);
    m_pModel = 0;
}

void BodyPartOwner::BPO_SetModel(jet::scene::Model *m) {
    m_pModel = m;
}

// BPO_AddBodyPart @0x5251e0: bound to the model node named by NodeRef, enabled and visible
void BodyPartOwner::BPO_AddBodyPart(BodyPartDefinition *d) {
    const jet::scene::Node *n = m_pModel->FindNodeByName(d->nodeRef);
    if (!n) return;
    BodyPartSection s;
    s.node = const_cast<jet::scene::Node*>(n);
    s.def = d;
    s.flags = BodyPartSection::Enabled | BodyPartSection::Visible;
    m_bodyParts.push_back(s);
}

void BodyPartOwner::BPO_RemoveBodyPart(BodyPartDefinition *d) {
    for (size_t i = 0; i < m_bodyParts.size(); i++)
        if (m_bodyParts[i].def == d) {
            m_bodyParts.erase(m_bodyParts.begin() + i);
            return;
        }
}

void BodyPartOwner::BPO_LoadBodyPartsArray(std::vector<BodyPartDefinition> &defs, clara::Param *p) {
    if (!p) return;
    for (unsigned i = 0; i < p->GetComponentCount(); i++) {
        clara::Entity *e = dynamic_cast<clara::Entity*>(p->GetAsEntity(i));
        defs.push_back(BodyPartDefinition());
        BPO_LoadBodyPart(&defs.back(), e);
    }
}

void BodyPartOwner::BPO_AddBodyPartsArray(std::vector<BodyPartDefinition> &defs) {
    for (size_t i = 0; i < defs.size(); i++) BPO_AddBodyPart(&defs[i]);
}

// BPO_LoadBodyPart @0x5255f4
void BodyPartOwner::BPO_LoadBodyPart(BodyPartDefinition *d, clara::Entity *e) {
    static const math::quat<float> k_rot = math::quat<float>().setFromEulerXYZ(math::vec3<float>(0, -1.5707964f, 0));
    if (!e) return;
    d->name = e->GetName();
    e->GetParam(jet::String("NodeRef"), d->nodeRef);
    e->GetParam(jet::String("Radius"), d->radius);
    e->GetParam(jet::String("Height"), d->height);
    e->GetParam(jet::String("Angle"), d->angle);
    d->angle *= 0.0087266462f;
    e->GetParam(jet::String("cylinderCover"), d->cylinderCover);
    d->position = e->GetPosition();
    d->rotation = k_rot * e->GetRotation();
    int t = 0;
    e->GetParam(jet::String("Type"), t);
    d->type = t;
    e->GetParam(jet::String("touchEvent"), d->touchEvent);
    if (e->FindParamByName(jet::String("TouchedAnimation"))) {
        e->GetParam(jet::String("TouchedAnimation"), d->touchedAnimation);
        e->GetParam(jet::String("PressedAnimation"), d->pressedAnimation);
        e->GetParam(jet::String("TouchedSound"), d->touchedSound);
    }
    d->linked3dLayer = -1;
    if (e->FindParamByName(jet::String("linked3dLayer"))) {
        e->GetParam(jet::String("linked3dLayer"), d->linked3dLayer);
        d->linked3dLayer--;
    }
    d->baseRadius = d->radius;
    d->baseHeight = d->height;
}

void BodyPartOwner::BPO_SetBodyPartEnabled(BodyPartDefinition *d, bool on) {
    bool found = false;
    for (size_t i = 0; i < m_bodyParts.size() && !found; i++)
        if (m_bodyParts[i].def == d) {
            m_bodyParts[i].flags = on ? (m_bodyParts[i].flags | BodyPartSection::Enabled) : (m_bodyParts[i].flags & ~BodyPartSection::Enabled);
            found = true;
        }
    if (on && !found) BPO_AddBodyPart(d);
}

void BodyPartOwner::BPO_SetBodyPartVisible(BodyPartDefinition *d, bool visible, bool setCheck, bool check) {
    for (size_t i = 0; i < m_bodyParts.size(); i++) {
        if (m_bodyParts[i].def != d) continue;
        unsigned char &f = m_bodyParts[i].flags;
        f = visible ? (f | BodyPartSection::Visible) : (f & ~BodyPartSection::Visible);
        if (setCheck) f = check ? (f | BodyPartSection::Check4) : (f & ~BodyPartSection::Check4);
        return;
    }
}

void BodyPartOwner::BPO_AddToLastHit(BodyPartSection *s) {
    if (!BPO_IsLastHit(s)) m_lastHit.push_back(s);
}

bool BodyPartOwner::BPO_IsLastHit(BodyPartSection *s) const {
    return std::find(m_lastHit.begin(), m_lastHit.end(), s) != m_lastHit.end();
}

// BPO_Update @0x525afc: the hit sphere follows the model's bounding sphere
void BodyPartOwner::BPO_Update(int) {
    if (!m_pModel) return;
    m_hitSpherePos = m_pModel->GetBoundingSphereCenter();
    m_hitSphereRadius = m_pModel->GetBoundingSphereRadius();
}

void BodyPartOwner::BPO_Render() {
    for (size_t i = 0; i < m_bodyParts.size(); i++) BPO_RenderBodyPart(&m_bodyParts[i]);
}

// BPO_Scale @0x527208: every part's size scales by f from what it was loaded with
void BodyPartOwner::BPO_Scale(float f) {
    for (size_t i = 0; i < m_bodyParts.size(); i++) {
        m_bodyParts[i].def->radius = f * m_bodyParts[i].def->baseRadius;
        m_bodyParts[i].def->height = f * m_bodyParts[i].def->baseHeight;
    }
}
