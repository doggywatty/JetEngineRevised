// source/game/entities/MinionCostume.h
#ifndef SOURCE_GAME_ENTITIES_MINIONCOSTUME_H
#define SOURCE_GAME_ENTITIES_MINIONCOSTUME_H

class MinionCostume : public Actor, public BodyPartOwner {  // sizeof 0x278
public:
    static void SetCurrentBigCostumePosWorldX(float);
    static void SetIsDragging(bool);
    MinionCostume(MinionCostume*);
    MinionCostume(const clara::Template*);
    virtual ~MinionCostume();
    virtual void Update();
    virtual void Init();
    virtual void PostInit();
    const jet::String &GetGameName();
    const jet::String &GetBonusText();
    Price *GetPrice();
    bool HasPromo();
    Deco3d *GetShadowDeco();
    int GetOrderValue();
    unsigned GetNumBonuses();
    BonusForCostumes *GetBonus(int);
    void SetEnableReachTarget(bool);
    void SetTargetPosition(const math::vec3<float>&);
    math::vec3<float> GetTargetPosition();
    bool ShouldBeShownInShop();
    bool IsPlaceHolderCostume();
    bool IsNearTheCurrentPos();
    bool HasReachedTargetPos();
    void ReleaseEffects();
    bool HasBonus();
    int GetExtraBananasOnFriendsChallenge();
    float GetExtraBananasFactor();
    int GetExtraDespicablePointsFactor();
    int GetExtraTimeForPowerUp(GameItemType);
    int GetExtraWeightFactorForPowerUp(GameItemType);
    int RevivesForFree();
    virtual void BPO_OnBodyPartTouched(BodyPartSection*);
    virtual void BPO_OnBodyPartDragged(BodyPartSection*);
    virtual void BPO_OnBodyPartPressed(BodyPartSection*);
    virtual void BPO_OnBodyPartReleased(BodyPartSection*);
    virtual GameEntity *BPO_GetOwnerGameEntity();
    const jet::String &GetClaraEntityName();
    CostumeId GetCostumeId();
    void SetPlaceHolderDecoIfNeeded();
private:
    void UpdateReachTarget(unsigned);
public:
    static const jet::String k_tmplName;
    static const jet::String k_headNodeName;
    static const float k_axisXToAxisYMulti;
private:
    jet::String m_claraEntityName;  // 0x238
    CostumeId m_id;  // 0x23C
    jet::String m_name;  // 0x240
    jet::String m_bonusText;  // 0x244
    Price *m_price;  // 0x248
    Deco3d *m_shadowDeco;  // 0x24C
    int m_orderValue;  // 0x250
    bool m_isShopElement;  // 0x254
    bool m_enableReachTarget;  // 0x255
    bool m_hasBonus;  // 0x256
    ustl::vector<BonusForCostumes *> m_bonuses;  // 0x258
    math::vec3<float> m_targetPos;  // 0x268
    int m_timeRunning;  // 0x274
    static bool s_isDragging;
    static float s_currentBigCostumePosWorldX;
    static const float k_moveSpeed;
    static const int k_maxTimeRunningInPlace;
    static const jet::String k_costumeId;
    static const jet::String k_name;
    static const jet::String k_bonusText;
    static const jet::String k_price;
    static const jet::String k_orderValue;
    static const jet::String k_hasBonus;
    static const jet::String k_bonuses;
    static const jet::String k_isShopElement;
    static const jet::String k_shadowDeco;
};

#endif
