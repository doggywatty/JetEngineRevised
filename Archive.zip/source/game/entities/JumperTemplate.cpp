// source/game/entities/JumperTemplate.cpp
