// source/game/entities/BananaTemplatePath.cpp
