// source/game/entities/BossObstacleTemplate.cpp
