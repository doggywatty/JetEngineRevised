// source/game/entities/LocationConfig.cpp
#include "LocationConfig.h"
#include "param.h"
#include "project.h"

const jet::String LocationConfig::k_tmplName("LocationConfig"), LocationConfig::k_param_LocationId("LocationId"),
    LocationConfig::k_param_MainMenuMusic("MainMenuMusic"), LocationConfig::k_param_MainMenuAmbient("MainMenuAmbient"),
    LocationConfig::k_param_RenderPlatforms("RenderPlatforms"), LocationConfig::k_param_FluffyBackground("FluffyBackground"),
    LocationConfig::k_param_CannonBackgrounds("CannonBackgrounds"), LocationConfig::k_param_CannonTemplates("CannonTemplates"),
    LocationConfig::k_param_hasBoss("HasBoss"), LocationConfig::k_param_bossReference("BossReference");

// @0x4e5cfc. The large minion configuration (LoadLargeMinionConfig) comes with LargeMinionGameplay.
void LocationConfig::PostInit() {
    clara::Entity::PostInit();
    GetParam(k_param_MainMenuMusic, m_mainMenuMusic);
    GetParam(k_param_MainMenuAmbient, m_mainMenuAmbient);
    m_locationId = FindParamByName(k_param_LocationId)->GetAsIdEnum(0).value;
    GetParam(k_param_RenderPlatforms, m_renderPlatforms);
    m_fluffyBackground = FindParamByName(k_param_FluffyBackground)->GetAsEntity(0);
    m_cannonBackgrounds = FindParamByName(k_param_CannonBackgrounds)->GetAsEntity(0);
    m_cannonTemplates = FindParamByName(k_param_CannonTemplates)->GetAsEntity(0);
    bool hasBoss = false;
    GetParam(k_param_hasBoss, hasBoss);
    if (hasBoss) m_boss = clara::Project::GetInstance()->FindEntityByPath(FindParamByName(k_param_bossReference)->GetAsPath(0));
}
