// source/game/entities/MissionSet.h
#ifndef SOURCE_GAME_ENTITIES_MISSIONSET_H
#define SOURCE_GAME_ENTITIES_MISSIONSET_H

class MissionSet : public GameEntity {  // sizeof 0xA4
public:
    MissionSet(const clara::Template*);
    virtual ~MissionSet();
    virtual void Init();
    virtual void PostInit();
    virtual void Update();
    unsigned GetMissionCount();
    Mission &GetMission(unsigned);
    bool IsInfiniteMissionLooper();
    static jet::String k_tmplName;
private:
    ustl::vector<Mission *> m_missions;  // 0x90
    bool m_isInfiniteMissionLooper;  // 0xA0
};

#endif
