// source/game/entities/Buyable.h
#ifndef SOURCE_GAME_ENTITIES_BUYABLE_H
#define SOURCE_GAME_ENTITIES_BUYABLE_H

class Buyable : public GameEntity {  // sizeof 0x9C
public:
    Buyable(const clara::Template*);
    virtual ~Buyable();
    virtual void Init();
    virtual void PostInit();
    virtual void Update();
    const jet::String &GetBuyableName();
    SpritePlayer *GetSpritePlayer();
    Price *GetPrice();
    static jet::String k_tmplName;
private:
    jet::String m_name;  // 0x90
    SpritePlayer *m_spritePlayer;  // 0x94
    Price *m_price;  // 0x98
    static const jet::String k_name;
    static const jet::String k_price;
    static const jet::String k_icon;
};

#endif
