// source/game/entities/Pacesetter.h
#ifndef SOURCE_GAME_ENTITIES_PACESETTER_H
#define SOURCE_GAME_ENTITIES_PACESETTER_H

#include <vector>
#include "GameEntity.h"
#include "pacesettercontroller.h"
#include "../leveltemplate/gameplaytemplateinstancelistener.h"

class GameplayTemplateInstance;
class PacesetterFollower;

// The point the minion's run follows along the level template lanes: it moves at a speed, changes lane and reports to its followers.
// A controller (the rocket's path) can take it over.
class Pacesetter : public GameEntity, public GameplayTemplateInstanceListener {  // sizeof 0x140
public:
    // what the followers are told: the controller took (0) or gave back (1) the pacesetter
    struct PacesetterEvent { int type; };
    struct PacesetterEventType { enum { ControlStarted = 0, ControlEnded = 1 }; };
    static jet::String k_tmplName;
    explicit Pacesetter(const clara::Template *t) : GameEntity(t), m_currentGti(0), m_currentLane(1), m_controller(0) {}
    virtual ~Pacesetter();
    virtual void Init();
    virtual void PostInit();
    virtual void NotifyTransformChanged(bool);
    void RegisterFollower(PacesetterFollower*);
    void UnregisterFollower(PacesetterFollower*);
    void SetController(PacesetterController*);
    PacesetterController *GetController() const { return m_controller; }
    void SendPacesetterEvent(const PacesetterEvent&);
    // the template instance the pacesetter runs on: it is told when that one goes
    void SetCurrentGameplayTemplateInstance(GameplayTemplateInstance*);
    GameplayTemplateInstance *GetCurrentGameplayTemplateInstance() const { return m_currentGti; }
    virtual void OnGameplayTemplateInstanceEvent(const GameplayTemplateInstanceEvent&);
private:
    GameplayTemplateInstance *m_currentGti;  // 0x90
    int m_currentLane;                       // 0x94
    std::vector<PacesetterFollower*> m_followers;  // 0x130
    PacesetterController *m_controller;      // 0x13C
};

#endif
