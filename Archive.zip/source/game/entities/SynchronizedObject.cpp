// source/game/entities/SynchronizedObject.cpp
