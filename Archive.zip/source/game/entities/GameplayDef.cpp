// source/game/entities/GameplayDef.cpp
