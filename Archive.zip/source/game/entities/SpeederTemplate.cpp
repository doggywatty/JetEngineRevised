// source/game/entities/SpeederTemplate.cpp
