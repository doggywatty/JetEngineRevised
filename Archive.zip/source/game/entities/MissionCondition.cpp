// source/game/entities/MissionCondition.cpp
