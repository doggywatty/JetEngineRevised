// source/game/entities/ObstacleTemplate.h
#ifndef SOURCE_GAME_ENTITIES_OBSTACLETEMPLATE_H
#define SOURCE_GAME_ENTITIES_OBSTACLETEMPLATE_H

class ObstacleTemplate : public Object, public SynchronizedObject, public GameplayTemplateInstanceListener {  // sizeof 0x22C
public:
    ObstacleTemplate(const clara::Template*);
    virtual ~ObstacleTemplate();
    virtual void Init();
    virtual void PostInit();
    virtual void Update();
    virtual void Render();
    virtual void SetSpawnLane(int);
    virtual void OnHit(bool);
    void Destroy(bool, bool);
    unsigned GetCollisionTiles();
    void SetLane(LaneIndex);
    void SetGameplayTemplateInstance(GameplayTemplateInstance*);
    void SetCollisionStart(unsigned);
    void EnableTileCollisions(bool);
    void PlaceTargetOnTriggerPos(GameEntity*);
    bool UseLocalization();
    ObstacleTemplate *GetLocalizedObstacleTemplate(const jet::String&);
    virtual void ConstructFrom(GameEntity*);
    int GetEngineEventOnCrash();
    int GetEngineEventOnNearMiss();
    LaneIndex GetLane();
    bool IsOnLane(LaneIndex);
    static void AddTarget(ObstacleTarget*);
    static void RemoveTarget(ObstacleTarget*);
    GameEntity *GetLinkedInteractiveTemplate();
    void SetLinkedInteractiveInstance(GameEntity*);
    virtual void OnMinionRevive();
    virtual void OnGameplayTemplateInstanceDestroyed();
    virtual void OnGameplayTemplateInstanceEvent(const GameplayTemplateInstance::GameplayTemplateInstanceEvent&);
private:
    void ExplodeLinkedInteractiveObject();
    bool IsTargetOnRail(Pacesetter*);
    ObstacleTemplate::CheckTriggerResult CheckTrigger(Pacesetter*);
    void LoadArray(const jet::String&, std::vector<int,std::allocator<int> >&);
    bool IsFreezingDistanceOk();
    void InitCollisionLanes();
    void UpdateTargetsTrigger();
protected:
    void UpdateWeaponPowerUp();
    bool MustStartWeaponPowerUp();
public:
    static float k_weaponPowerUp_distance;
    static float k_weaponPowerUp_distanceToExplode;
    static jet::String k_tmplName;
private:
    float m_triggerDistance;  // 0x178
    float m_nearMissDistance;  // 0x17C
    std::vector<int,std::allocator<int> > m_successStateTypeOnGround;  // 0x180
    std::vector<int,std::allocator<int> > m_successStateTypeOnPlatform;  // 0x194
    unsigned m_collsisionStart;  // 0x1A8
    unsigned m_collisionTiles;  // 0x1AC
    GameplayTemplateInstance *m_gameplayTemplateInstance;  // 0x1B0
    EffectDef *m_effectOnDestroyed;  // 0x1B4
    jet::String m_nodeRefNameOnDestroyed;  // 0x1B8
    EffectDef *m_effectOnIdle;  // 0x1BC
    jet::String m_nodeRefNameOnIdle;  // 0x1C0
    EffectControl *m_idleEffectControl;  // 0x1C4
    int m_engineEventOnCrash;  // 0x1C8
    int m_engineEventNearMiss;  // 0x1CC
    bool m_useInRight;  // 0x1D0
    bool m_useInLeft;  // 0x1D1
    bool m_nearMiss;  // 0x1D2
    ObstacleTemplate::ObstacleState m_state;  // 0x1D4
    LaneIndex m_lane;  // 0x1D8
    LaneIndex m_collisionLaneStart;  // 0x1DC
    LaneIndex m_collisionLaneEnd;  // 0x1E0
    bool m_freezeDecoChanged;  // 0x1E4
    Deco3d *m_freezeDeco;  // 0x1E8
    EffectDef *m_freezeEffectOnDestroyed;  // 0x1EC
    EffectDef *m_freezeEffect;  // 0x1F0
    EffectDef *m_effectOnCrash;  // 0x1F4
    jet::String m_animOnCrash;  // 0x1F8
    jet::String m_idleAnim;  // 0x1FC
    bool m_hideOnCrash;  // 0x200
    bool m_useLocalization;  // 0x201
    std::map<jet::String,ObstacleTemplate *,std::less<jet::String>,std::allocator<std::pair<jet::String const ,ObstacleTemplate *> > > m_localizationPairs;  // 0x204
    static ustl::vector<ObstacleTarget *> s_obstacleTargets;
    GameEntity *m_linkedInteractiveTemplate;  // 0x220
    GameEntity *m_linkedInteractiveInstance;  // 0x224
    bool m_dbg_checked;  // 0x228
    static const jet::String k_enableStateCheck;
    static const jet::String k_useInRight;
    static const jet::String k_useInLeft;
    static const jet::String k_triggerDistance;
    static const jet::String k_nearMissDistance;
    static const jet::String k_successStateType;
    static const jet::String k_successStateTypeOnPlatform;
    static const jet::String k_collisionTiles;
    static const jet::String k_effectOnDestroyed;
    static const jet::String k_nodeRefOnDestroyed;
    static const jet::String k_effectOnIdle;
    static const jet::String k_nodeRefOnIdle;
    static const jet::String k_engineEventOnCrash;
    static const jet::String k_useLocalization;
    static const jet::String k_localizationArray;
    static const jet::String k_engineEventNearMiss;
    static const jet::String k_effectOnCrash;
    static const jet::String k_animOnCrash;
    static const jet::String k_hideOnCrash;
    static const jet::String k_uselinkedInteractive;
    static const jet::String k_linkedInteractive;
    static const jet::String k_freezeObjectDeco;
    static const jet::String k_freezeEffectOnDestroyed;
    static const jet::String k_freezeEffect;
};

#endif
