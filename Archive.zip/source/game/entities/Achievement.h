// source/game/entities/Achievement.h
#ifndef SOURCE_GAME_ENTITIES_ACHIEVEMENT_H
#define SOURCE_GAME_ENTITIES_ACHIEVEMENT_H

class Achievement : public GameEntity {  // sizeof 0xBC
public:
    Achievement(const clara::Template*);
    virtual ~Achievement();
    virtual void Init();
    virtual void PostInit();
    void OnConditionCompleted();
    void OnStarted();
    bool IsCompleted();
    void MarkAsPreviouslyCompleted();
    const AchievementId &GetAchievemntId();
    const jet::String &GetAchievementName();
    const jet::String &GetAchievementDescription();
    const jet::String &GetGameCenterId();
    Price &GetPrize();
    void ForceConditionUpdate();
    float GetCompletedPercentage();
    const jet::String GetConditionScope();
private:
    void UnregisterObservers();
public:
    static jet::String k_tmplName;
private:
    jet::String m_conditionsScope;  // 0x90
    ustl::vector<MissionCondition *> m_conditions;  // 0x94
    AchievementId m_id;  // 0xA4
    jet::String m_name;  // 0xA8
    jet::String m_description;  // 0xAC
    bool m_completed;  // 0xB0
    jet::String m_gameCenterId;  // 0xB4
    Price *m_prize;  // 0xB8
    static const jet::String k_achievemntIdParam;
};

#endif
