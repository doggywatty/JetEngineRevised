// source/game/entities/Actor.h
#ifndef SOURCE_GAME_ENTITIES_ACTOR_H
#define SOURCE_GAME_ENTITIES_ACTOR_H

class Actor : public Object, public StateMachine {  // sizeof 0x1DC
protected:
    virtual bool RttiIsOfType(int);
    virtual void* RttiCastTo(int);
    static unsigned RttiGetClassId();
    static const char *RttiGetClassIdName();
    virtual const char *RttiGetInstanceClassIdName();
    virtual int RttiGetInstanceClassId();
public:
    Actor(const clara::Template*);
    virtual ~Actor();
    virtual void Init();
    virtual void PostInit();
    virtual void Update();
    virtual void InitStateMachine();
    virtual unsigned SM_GetId();
    Collision3d *GetCurrentGroundCollision();
    virtual void StartJumpDefinition(JumpDefinition*, const math::vec3<float>&, const math::quat<float>&);
    virtual void SetCurrentJumpDefinition(JumpDefinition*);
protected:
    void ResetGravity(float, float, float, bool);
    void ResetGravity(math::vec3<float>&, float);
    void ResetGravity(float);
    bool UpdateGravity(math::vec3<float>&, bool);
    bool ProjectOnGround(const math::vec3<float>&, const math::vec3<float>&, math::vec3<float>&);
    bool ProjectOnGround(math::vec3<float>&, math::quat<float>&, float, float);
    bool ProjectOnGround(math::vec3<float>&, const math::vec3<float>&, float);
    bool ProjectOnGround(math::vec3<float>&);
    bool SetOnGround(math::vec3<float>&, math::quat<float>&, float);
    virtual const jet::String &GetBaseTemplateName();
public:
    static jet::String k_tmplName;
protected:
    JumpDefinitionControl m_jumpCtrl;  // 0x168
    JumpDefinition *m_jump;  // 0x18C
    math::vec3<float> m_fakeJumpMinHeight;  // 0x190
    math::vec3<float> m_fakeJumpMaxHeight;  // 0x19C
    float m_fakeJumpTime;  // 0x1A8
    float m_fakeJumpTimeCount;  // 0x1AC
    math::vec3<float> m_gravitySpeed;  // 0x1B0
    math::vec3<float> m_gravity;  // 0x1BC
    static float k_defaultGravity;
    static float k_maxGravitySpeed;
    Collision3d *m_groundCollisionEntity;  // 0x1C8
private:
    jet::String m_STTFileName;  // 0x1CC
    jet::String m_STTFileInitialState;  // 0x1D0
    clara::Param::StateValue m_statesMachine;  // 0x1D4
    static const jet::String k_stateMachine;
};

#endif
