// source/game/entities/BossGameplay.h
#ifndef SOURCE_GAME_ENTITIES_BOSSGAMEPLAY_H
#define SOURCE_GAME_ENTITIES_BOSSGAMEPLAY_H

class BossGameplay : public GameEntity, public LevelTemplateSequenceProvider {  // sizeof 0x108
public:
    BossGameplay(const clara::Template*);
    virtual ~BossGameplay();
    virtual void Init();
    virtual void PostInit();
    virtual void Update();
    virtual void Render();
    void CreateBoss();
    void CreatePacesetter();
    void Start();
    void End();
    void Reset();
    LevelTemplateMgr *GetLevelTemplateMgr();
    virtual void IncSequenceNumber();
    virtual int GetNextSequenceNumber();
    virtual GameEntity *GetNextCamera();
    virtual int GetNextCameraTransitionTime();
    virtual SpeedDef *GetNextSpeed();
    virtual const jet::String &GetNextLocation();
    virtual const jet::String &GetNextNodeLabel();
    virtual const jet::String &GetNextNodeId();
    virtual void OnNodeCompleted(const jet::String&);
    void AddCreatedEntity(GameEntity*);
    void RemoveCreatedEntity(GameEntity*);
    Boss *GetBoss();
    void KillBoss(const jet::String&, const jet::String&);
    void SetDefeated();
    bool IsTutorialCompleted();
    void CompleteTutorial();
    void BeginTutorial();
    void EndTutorial();
    static const jet::String k_tmplName;
private:
    BossGameplay::BossGameplayState m_state;  // 0x94
    Boss *m_referenceBoss;  // 0x98
    Boss *m_boss;  // 0x9C
    Puppet *m_bossPuppet;  // 0xA0
    unsigned m_sequenceCounter;  // 0xA4
    ustl::vector<unsigned int> m_sequences;  // 0xA8
    CameraEntity *m_cameraEntity;  // 0xB8
    int m_cameraTransitionTime;  // 0xBC
    float m_minionSpeed;  // 0xC0
    ustl::vector<BackgroundData *> m_backgroundArray;  // 0xC4
    float m_invulnerabilityTime;  // 0xD4
    float m_winReturnOffsetInLane;  // 0xD8
    float m_returnOffsetInLane;  // 0xDC
    Pacesetter *m_pacesetter;  // 0xE0
    Pacesetter *m_oldPacesetter;  // 0xE4
    LevelTemplateMgr *m_levelTemplateMgr;  // 0xE8
    unsigned m_startDistanceOnPastTemplates;  // 0xEC
    unsigned m_startDistanceOnCurrentTemplate;  // 0xF0
    SpeedDef m_speedDef;  // 0xF4
    bool m_showTutorial;  // 0xFC
    bool m_hasTutorial;  // 0xFD
    int m_tutorialTemplateId;  // 0x100
    bool m_tutorialStarted;  // 0x104
    static const jet::String k_bossRefParam;
    static const jet::String k_levelTemplateListParam;
    static const jet::String k_bossCameraParam;
    static const jet::String k_cameraTransitionTimeParam;
    static const jet::String k_environmentPoolParam;
    static const jet::String k_postGameplaylnvulnerabilityTimeParam;
    static const jet::String k_minionSpeedParam;
    static const jet::String k_returnLaneOffsetParam;
    static const jet::String k_hasTutorialParam;
    static const jet::String k_tutorialLevelTemplateParam;
    static const jet::String k_emptyStr;
};

#endif
