// source/game/entities/Runner.h
#ifndef SOURCE_GAME_ENTITIES_RUNNER_H
#define SOURCE_GAME_ENTITIES_RUNNER_H

class Runner : public Actor, public PacesetterFollower, public ObstacleTarget {  // sizeof 0x210
public:
    Runner(const clara::Template*);
    virtual ~Runner();
    virtual void Update();
    virtual void PostInit();
    virtual bool IsOutOfScene();
    virtual void GoTo(const math::vec3<float>&, const math::quat<float>&);
    virtual void OnGameplayTemplateInstanceDestroyed();
    virtual void CollidesWith(Collision3d*, const CollisionPair&);
    virtual void OnObstacleHit(ObstacleTemplate*);
    virtual void SetSpawnLane(int);
    void SetSpeedPgt(float, int);
    void EnableLargeMinionGameplay(bool);
    float GetDespicablePoints();
    virtual void OnMinionRevive();
private:
    void SetRunnerState(Runner::RunnerState);
    void InitPacesetter();
    void StartPacesetter();
    void StopPacesetter();
    float GetDistanceSqToPlane(const math::vec3<float>&, const math::quat<float>&);
    void UpdateLargeMinionGameplay(float);
    void FindObstacle();
    void UpdateNPCVoiceTrigger();
public:
    static jet::String k_tmplName;
private:
    Runner::RunnerState m_runnerState;  // 0x1EC
    float m_startTime;  // 0x1F0
    float m_distanceToStopSq;  // 0x1F4
    LaneIndex m_spawnLane;  // 0x1F8
    float m_speedPgt;  // 0x1FC
    int m_speedTime;  // 0x200
    int m_minionEngineEventOnHit;  // 0x204
    bool m_enableLargeMinionGameplay;  // 0x208
    bool m_triggerNPCVoice;  // 0x209
    float m_despicablePoints;  // 0x20C
    static const jet::String k_speedPgtParamName;
    static const jet::String k_speedTimeParamName;
    static const jet::String k_startTimeParamName;
    static const jet::String k_endDistanceParamName;
    static const jet::String k_despicablePointsParamName;
    static const jet::String k_EventOnMinionHitParamName;
    static const float k_distanceToTriggerNPCVoiceSq;
    static const jet::String k_NPCVoiceLabel;
    static const jet::String k_NPCSfxRunningLabel;
    static const float k_NPCVoiceCoolDownTime;
};

#endif
