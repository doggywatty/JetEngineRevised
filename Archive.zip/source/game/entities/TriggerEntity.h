// source/game/entities/TriggerEntity.h
#ifndef SOURCE_GAME_ENTITIES_TRIGGERENTITY_H
#define SOURCE_GAME_ENTITIES_TRIGGERENTITY_H

class TriggerEntity : public Collision3d, public Collision3dListener {  // sizeof 0xD0
public:
    virtual const jet::String &GetBaseTemplateName();
    TriggerEntity(const clara::Template*);
    virtual ~TriggerEntity();
    virtual void Init();
    virtual void PostInit();
    virtual void Update();
    virtual void CollidesWith(Collision3d*, const CollisionPair&);
    virtual GameEntity *GetAsEntity();
    virtual bool IsOutOfScene();
private:
    void OnEnter(GameEntity*);
    void OnExit(GameEntity*);
public:
    static jet::String k_tmplName;
private:
    std::vector<TriggerEntity::Collider,std::allocator<TriggerEntity::Collider> > m_colliders;  // 0xB8
    ScriptData *m_scriptData;  // 0xCC
    static const jet::String k_onEnter;
    static const jet::String k_onExit;
};

#endif
