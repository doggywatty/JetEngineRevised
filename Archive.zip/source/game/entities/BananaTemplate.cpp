// source/game/entities/BananaTemplate.cpp
