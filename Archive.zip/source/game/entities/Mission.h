// source/game/entities/Mission.h
#ifndef SOURCE_GAME_ENTITIES_MISSION_H
#define SOURCE_GAME_ENTITIES_MISSION_H

class Mission : public GameEntity {  // sizeof 0xC0
public:
    Mission(const clara::Template*);
    virtual ~Mission();
    virtual void Init();
    virtual void PostInit();
    safe_enum<EStatisticTypeDef,enum EStatisticTypeDef::type> GetStatType();
    void ForceConditionUpdate();
    void OnAddedToActiveMission(int, int, bool);
    void OnConditionCompleted();
    void OnForceComplition();
    bool IsCompleted();
    const jet::String &GetDescription();
    unsigned GetMissionMultiplierPoints();
    const jet::String &GetMissionGiver();
    const Price &GetSkipPrice();
    float GetCompletedPercentage();
    bool IsScopeCodeImplemented();
    MissionId GetMissionId();
private:
    void Debug_ValidateData();
public:
    static const jet::String k_missionScopeCurrentRun;
    static const jet::String k_missionScopeCareer;
    static const jet::String k_missionScopeAccumulative;
    static const jet::String k_missionGiver_Gru;
    static const jet::String k_missionGiver_Nefario;
    static const jet::String k_missionGiver_Girls;
    static jet::String k_tmplName;
private:
    MissionId m_id;  // 0x90
    jet::String m_description;  // 0x94
    jet::String m_statType;  // 0x98
    int m_activeMissionSlot;  // 0x9C
    ustl::vector<MissionCondition *> m_conditions;  // 0xA0
    jet::String m_missionGiver;  // 0xB0
    bool m_completed;  // 0xB4
    Price *m_skipPrice;  // 0xB8
    unsigned m_missionMultiplierPoints;  // 0xBC
};

#endif
