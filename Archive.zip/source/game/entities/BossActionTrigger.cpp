// source/game/entities/BossActionTrigger.cpp
