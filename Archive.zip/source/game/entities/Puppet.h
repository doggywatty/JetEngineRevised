// source/game/entities/Puppet.h
#ifndef SOURCE_GAME_ENTITIES_PUPPET_H
#define SOURCE_GAME_ENTITIES_PUPPET_H

class Puppet : public Object, public StateMachine {  // sizeof 0x168
public:
    Puppet(const clara::Template*);
    virtual ~Puppet();
    virtual void Update();
    virtual void PostInit();
    virtual void ConstructFrom(GameEntity*);
    void LinkToBoss(Boss*);
    virtual bool IsOutOfScene();
    static jet::String k_tmplName;
private:
    static const jet::String k_stateMachine;
};

#endif
