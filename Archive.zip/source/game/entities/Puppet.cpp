// source/game/entities/Puppet.cpp
