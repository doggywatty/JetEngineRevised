// source/game/entities/JumperTemplate.h
#ifndef SOURCE_GAME_ENTITIES_JUMPERTEMPLATE_H
#define SOURCE_GAME_ENTITIES_JUMPERTEMPLATE_H

class JumperTemplate : public Object, public SynchronizedObject {  // sizeof 0x18C
public:
    JumperTemplate(const clara::Template*);
    virtual ~JumperTemplate();
    virtual void Init();
    virtual void PostInit();
    virtual void Update();
    virtual void CollidesWith(Collision3d*, const CollisionPair&);
    virtual void SetSpawnLane(int);
    virtual void OnMinionRevive();
    static jet::String k_tmplName;
private:
    JumpDefinition *m_jumpDefinition;  // 0x174
    bool m_jumpDone;  // 0x178
    int m_engineEvent;  // 0x17C
    float m_jumpSpeed;  // 0x180
    float m_jumpFrontMinSpeed;  // 0x184
    unsigned m_jumpFrontMinSpeedTime;  // 0x188
    static jet::String k_jumpDefininitionParam;
    static jet::String k_jumpSpeedParam;
    static jet::String k_jumpFrontMinSpeedParam;
    static jet::String k_jumpFrontMinSpeedTimeParam;
    static jet::String k_engineEventParam;
};

#endif
