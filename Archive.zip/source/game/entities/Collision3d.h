// source/game/entities/Collision3d.h
#ifndef SOURCE_GAME_ENTITIES_COLLISION3D_H
#define SOURCE_GAME_ENTITIES_COLLISION3D_H

class Collision3d : public GameEntity {  // sizeof 0xB4
protected:
    virtual bool RttiIsOfType(int);
    virtual void* RttiCastTo(int);
    static unsigned RttiGetClassId();
    static const char *RttiGetClassIdName();
    virtual const char *RttiGetInstanceClassIdName();
    virtual int RttiGetInstanceClassId();
public:
    Collision3d(GameEntity*);
    Collision3d(const clara::Template*);
    virtual ~Collision3d();
    virtual void Init();
    virtual void PostInit();
    virtual void Update();
    virtual void SetEnabled(bool);
    virtual void NotifyTransformChanged(bool);
    RigidBody *GetCollisionBody();
    void CollidesWith(Collision3d*, const CollisionPair&);
    void SetCollisionListener(Collision3dListener*);
    Collision3dListener *GetCollisionListener();
    unsigned short GetCollisionGroup();
    unsigned short GetCollisionMask();
    virtual bool IsOutOfScene();
    bool IsDestructableCollision();
    bool IsGroundCollision();
    void SetIsGroundCollision(bool);
private:
    void RemoveFromWorld(PhysicsWorld*);
public:
    void RemoveFromWorld();
private:
    void AddToWorld(PhysicsWorld*);
public:
    void AddToWorld();
    unsigned GetEffectGroupId();
    static jet::String k_tmplName;
private:
    safe_enum<Collision3d::CollisionShapeTypeDef,enum Collision3d::CollisionShapeTypeDef::type> m_type;  // 0x90
    RigidBody *m_rigidBody;  // 0x94
    CollisionShape *m_collisionShape;  // 0x98
    bool m_isAddedToWorld;  // 0x9C
    unsigned short m_collisionGroup;  // 0x9E
    unsigned short m_collisionMask;  // 0xA0
    float m_sizeExtent;  // 0xA4
    bool m_isGroundCollision;  // 0xA8
    unsigned m_effectGroupId;  // 0xAC
    Collision3dListener *m_collisionListener;  // 0xB0
    static const jet::String k_effectGroupId;
    static const jet::String k_collisionShape;
    static const jet::String k_shapeDef;
    static const jet::String k_meshModel;
    static const jet::String k_overrideMeshMaterials;
    static const jet::String k_collisionGroup;
    static const jet::String k_collisionMask;
};

#endif
