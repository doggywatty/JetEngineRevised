// source/game/entities/Enemy.h
#ifndef SOURCE_GAME_ENTITIES_ENEMY_H
#define SOURCE_GAME_ENTITIES_ENEMY_H

class Enemy : public Actor {  // sizeof 0x1E0
public:
    Enemy(const clara::Template*);
    virtual ~Enemy();
    virtual void Init();
    virtual void PostInit();
    virtual void Update();
    void PushEntity(const math::vec2<float>&);
    const char *GetStringForStateEnum();
    void OnMinionTouch(Minion*);
    void OnMinionHit(Minion*);
    virtual void SM_OnChangeState(ActorState*, ActorState*);
    virtual void ExecuteAttack() = 0;
    static jet::String k_tmplName;
protected:
    Minion *m_minionHitted;  // 0x1DC
};

#endif
