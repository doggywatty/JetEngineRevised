// source/game/entities/BonusForCostumes.h
#ifndef SOURCE_GAME_ENTITIES_BONUSFORCOSTUMES_H
#define SOURCE_GAME_ENTITIES_BONUSFORCOSTUMES_H

class BonusForCostumes : public GameEntity {  // sizeof 0xA0
public:
    BonusForCostumes(const clara::Template*);
    virtual ~BonusForCostumes();
    virtual void Init();
    virtual void PostInit();
    SpritePlayer *GetSpritePlayer();
    CostumeSkillType GetSkillType();
    float GetAmountAsFloat();
    int GetAmountAsInt();
    GameItemType GetGameItemType();
    static jet::String k_tmplName;
private:
    jet::String m_description;  // 0x90
    float m_amount;  // 0x94
    CostumeSkillType m_costumeSkillType;  // 0x98
    GameItemType m_gameItemType;  // 0x9C
};

#endif
