// source/game/entities/BossMeena.h
#ifndef SOURCE_GAME_ENTITIES_BOSSMEENA_H
#define SOURCE_GAME_ENTITIES_BOSSMEENA_H

class BossMeena : public Boss {  // sizeof 0x290
public:
    BossMeena(const clara::Template*);
    virtual ~BossMeena();
    virtual void PostInit();
    bool IsInLane(LaneIndex);
    bool IsBloquingMinion(LaneIndex);
    virtual void StartAttack();
    virtual void OnShoot();
    virtual bool CanShoot();
    virtual const math::vec3<float> &GetShootPosition();
    virtual const jet::String &GetBossSoundLabel();
    virtual int GetStartMinionEvent();
    virtual int GetEndMinionEvent();
protected:
    virtual void UpdatePersecution();
private:
    void UpdateMeleeAttack();
    void UpdatePosition();
    void UpdateCurrentLane();
    virtual void OnAppear();
    virtual void OnDie();
    virtual void SM_OnChangeState(ActorState*, ActorState*);
    bool CanFollowMinion();
public:
    static jet::String k_tmplName;
private:
    LaneIndex m_lastMinionLane;  // 0x228
    LaneIndex m_currentLane;  // 0x22C
    int m_changeLaneTimer;  // 0x230
    jet::core::Delayer<float,jet::core::LinearStep> m_offsetDelayer;  // 0x234
    float m_offsetInPath;  // 0x24C
    jet::core::Delayer<float,jet::core::QuadraticEaseInOut> m_offsetInPathDelayer;  // 0x250
    math::quat<float> m_originalRot;  // 0x268
    int m_changeLaneWaitTime;  // 0x278
    int m_changeLaneTime;  // 0x27C
    int m_engineEventOnCrash;  // 0x280
    int m_ramAttackTime;  // 0x284
    int m_ramBackTime;  // 0x288
    int m_ramWinEngineEvent;  // 0x28C
    static const jet::String k_offsetInPathParam;
    static const jet::String k_changeLaneWaitTimeParam;
    static const jet::String k_changeLaneTimeParam;
    static const jet::String k_engineEventOnCrashParam;
    static const jet::String k_ramAttackTimeParam;
    static const jet::String k_ramBackTimeParam;
    static const float k_meenaLength;
    static const jet::String k_puppetShootDummy;
    static const jet::String k_meenaSoundLabel;
    static const jet::String k_ramWinEngineEventParam;
};

#endif
