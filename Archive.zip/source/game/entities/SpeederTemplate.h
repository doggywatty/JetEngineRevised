// source/game/entities/SpeederTemplate.h
#ifndef SOURCE_GAME_ENTITIES_SPEEDERTEMPLATE_H
#define SOURCE_GAME_ENTITIES_SPEEDERTEMPLATE_H

class SpeederTemplate : public Object, public SynchronizedObject {  // sizeof 0x180
public:
    SpeederTemplate(const clara::Template*);
    virtual ~SpeederTemplate();
    virtual void Init();
    virtual void PostInit();
    virtual void Update();
    virtual void SetSpawnLane(int);
    virtual void CollidesWith(Collision3d*, const CollisionPair&);
    virtual void OnMinionRevive();
    static jet::String k_tmplName;
private:
    float m_distance;  // 0x174
    float m_time;  // 0x178
    bool m_sendEngineEvent;  // 0x17C
    static jet::String k_distanceParam;
    static jet::String k_timeParam;
};

#endif
