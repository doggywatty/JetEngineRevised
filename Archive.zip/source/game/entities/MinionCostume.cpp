// source/game/entities/MinionCostume.cpp
