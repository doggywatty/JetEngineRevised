// source/game/entities/GameEntity.cpp
#include "GameEntity.h"
#include "TemplateData.h"
#include "BackgroundData.h"
#include "MaterialDef.h"
#include "game/leveltemplate/LevelTemplateInstance.h"
#include "game/GameLevel.h"
#include "scene/camera.h"
#include <cctype>
#include <cstdint>
#include <cstdio>
#include "MaterialDef.h"
#include "scene/model.h"
#include "scene/modelbase.h"
#include "video/material.h"
#include "video/textureloader.h"
#include "video/driver.h"

int GameEntity::s_frameDt = 0;

// @0x38ca2c
jet::String GameEntity::GetScriptPrefix() const {
    char buf[512];
    snprintf(buf, sizeof(buf), "X_%s_%d", GetName().empty() ? "" : GetName().c_str(), (int)(intptr_t)this);
    for (char *c = buf; *c; c++)
        if (!isalnum((unsigned char)*c)) *c = '_';
    return jet::String(buf);
}

GameEntity::GameEntity(const clara::Template *t)
    : clara::Entity(t), m_type(EntityTypeDef::Unknown), m_persistenceType(PersistenceTypeDef::Default), m_destroyed(false), m_appearProbability(100),
      m_isRegisteredForUpdate(false), m_isRegisteredForRender(false), m_distanceInRun(0), m_originalEntity(0), m_pendingToDelete(false), m_distanceToDelete(0) {}

GameEntity::~GameEntity() {
    if (m_isRegisteredForUpdate) _RegisterForUpdate(false);
    if (m_isRegisteredForRender) _RegisterForRender(false);
    if (m_persistenceType == PersistenceTypeDef::Volatile && GameLevel::GetInstance()) GameLevel::GetInstance()->RegisterVolatileEntity(this, false);
}

void GameEntity::Init() {
    if (m_flags & F_INIT) return;
    clara::Entity::Init();
}

void GameEntity::PostInit() {
    if (m_flags & F_POSTINIT) return;
    clara::Entity::PostInit();
}

// @0x4db1b4: the attached sounds and particle systems that follow the entity are not ported yet
void GameEntity::Update() { clara::Entity::Update(); }

void GameEntity::_RegisterForUpdate(bool on) {
    if (GameLevel::GetInstance()) GameLevel::GetInstance()->RegisterForUpdate(this, on);
}

void GameEntity::_RegisterForRender(bool on) {
    if (GameLevel::GetInstance()) GameLevel::GetInstance()->RegisterForRender(this, on);
}

// @0x4dabf8: the level lists only hold an entity while it is also enabled (update) or visible (render)
void GameEntity::RegisterForUpdate(bool on) {
    if (m_isRegisteredForUpdate == on) return;
    m_isRegisteredForUpdate = on;
    _RegisterForUpdate(on && IsEnabled());
}

void GameEntity::RegisterForRender(bool on) {
    if (m_isRegisteredForRender == on) return;
    m_isRegisteredForRender = on;
    _RegisterForRender(on && IsVisible());
}

void GameEntity::SetEnabled(bool on) {
    if (on == IsEnabled()) return;
    clara::Entity::SetEnabled(on);
    if (m_isRegisteredForUpdate) _RegisterForUpdate(on);
}

void GameEntity::SetVisible(bool on) {
    if (on == IsVisible()) return;
    clara::Entity::SetVisible(on);
    if (m_isRegisteredForRender) _RegisterForRender(on);
}

void GameEntity::Translate(const math::vec3<float> &d) { SetPosition(GetPosition() + d); }

void GameEntity::SetPersistenceType(int t) {
    if (m_persistenceType == t) return;
    GameLevel *l = GameLevel::GetInstance();
    if (l && m_persistenceType == PersistenceTypeDef::Volatile) l->RegisterVolatileEntity(this, false);
    m_persistenceType = t;
    if (l && t == PersistenceTypeDef::Volatile) l->RegisterVolatileEntity(this, true);
}

void GameEntity::ConstructFrom(const clara::Entity *o) {
    clara::Entity::ConstructFrom(o);
    m_originalEntity = const_cast<clara::Entity*>(o);
}

// @0x4db478: a copy of a copy remembers the first original
void GameEntity::ConstructFrom(const GameEntity *o) {
    clara::Entity::ConstructFrom(static_cast<const clara::Entity*>(o));
    m_originalEntity = o->m_originalEntity ? o->m_originalEntity : const_cast<GameEntity*>(o);
}

void GameEntity::SetPendingToDelete(unsigned distance) {
    m_pendingToDelete = true;
    m_distanceToDelete = distance;
    for (unsigned i = 0; i < GetLinkedEntitiesCount(); i++)
        if (GameEntity *g = dynamic_cast<GameEntity*>(GetLinkedEntity(i))) g->SetPendingToDelete(distance);
}

bool GameEntity::IsOutOfScene() const {
    return m_pendingToDelete && m_distanceToDelete <= GameLevel::GetInstance()->GetPlayerDistance();
}

bool GameEntity::CheckVisibility(float rangeSq, float, const math::vec3<float> &pos, float nearSq) {
    if (rangeSq < nearSq) return true;
    return !(rangeSq <= math::distanceSq(pos, GameLevel::GetInstance()->GetCamera()->GetPosition()));
}

// Texture placeholders of RenderPass "Textures", in the model's map slot order
static int PlaceholderSlot(const jet::String &t) {
    static const char *names[] = { "<Diffuse>", "<Ambient>", "<Bump>", "<SpecularCol>", "<SpecularLvl>", "<Glossiness>",
                                   "<SelfIllum>", "<Opacity>", "<FilterCol>", "<Reflection>", "<Refraction>", "<Displacement>" };
    for (int i = 0; i < 12; i++)
        if (t.Equals(names[i])) return i;
    return -1;
}

// ApplyMaterials @0x5642f4: the definition is built into the model's own material; texture layers
// named by a placeholder take the model's texture from that map slot.
void GameEntity::ApplyMaterials(jet::scene::Model *model, const jet::String &name, MaterialDef *def) const {
    if (!model || !def) return;
    int idx = model->FindMaterialIdxByName(name);
    if (idx < 0) return;
    jet::video::Material &mat = model->GetMutableMaterial((unsigned)idx);
    std::vector<std::vector<jet::String> > names;
    def->LoadMaterial(mat, names);
    const std::vector<jet::String> &slots = model->GetBase()->GetMaterialData((unsigned)idx).textureNames;
    jet::video::TextureLoader *tl = jet::video::TextureLoader::GetInstance();
    const bool separateAlpha = jet::video::Driver::GetCurrent() && jet::video::Driver::GetCurrent()->GetSeparateAlphaTextures();
    for (unsigned p = 0; p < names.size() && p < mat.GetRenderPassCount(); p++)
        for (unsigned l = 0; l < names[p].size() && l < mat.GetTextureLayerCount(p); l++) {
            int slot = PlaceholderSlot(names[p][l]);
            if (slot < 0) continue;
            if ((unsigned)slot >= slots.size() || slots[slot].empty()) continue;
            jet::video::TextureLayer &layer = mat.GetTextureLayer(p, l);
            layer.SetTexture(tl->Load(slots[slot]));
            if (separateAlpha) {
                jet::String alpha = slots[slot];
                alpha.append("__alpha");
                if (tl->CanLoad(alpha)) layer.SetAlphaTexture(tl->Load(alpha));
            }
        }
}

// @0x56470c: every material of the model
void GameEntity::ApplyMaterials(jet::scene::Model *model, MaterialDef *def) const {
    if (!model) return;
    for (unsigned i = 0; i < model->GetMaterialCount(); i++) ApplyMaterials(model, model->GetMaterialName(i), def);
}

// @0x564228: an unnamed entry applies to all materials
void GameEntity::ApplyMaterials(jet::scene::Model *model, const MaterialDefs &defs) const {
    for (unsigned i = 0; i < defs.size(); i++) {
        if (defs[i].first.empty()) ApplyMaterials(model, defs[i].second);
        else ApplyMaterials(model, defs[i].first, defs[i].second);
    }
}

// LoadMaterials @0x56477c: a multi-material parameter gives (component name, material) pairs, a
// single one ("", material)
void GameEntity::LoadMaterials(MaterialDefs &out, const jet::String &param, bool multi) const {
    out.clear();
    clara::Project *project = clara::Project::GetInstance();
    const clara::Param *p = FindParamByName(param);
    if (!p || !project) return;
    if (multi) {
        out.reserve(p->GetComponentCount());
        for (unsigned i = 0; i < p->GetComponentCount(); i++) {
            MaterialDef *def = dynamic_cast<MaterialDef*>(project->FindEntityByPath(p->GetAsPath(i)));
            out.push_back(std::make_pair(p->GetComponentName(i), def));
        }
    } else {
        MaterialDef *def = dynamic_cast<MaterialDef*>(project->FindEntityByPath(p->GetAsPath(0)));
        if (def) out.push_back(std::make_pair(jet::String(), def));
    }
}

// @0x4dbed8
bool GameEntity::CanSpawnNewEntity(LevelTemplateInstance *inst) const {
    if (inst && !inst->IsEntityAllowed(&m_generation)) return false;
    const jet::String &n = GetTemplateName();
    return !(n.Equals(TemplateData::k_tmplName) || n.Equals(BackgroundData::k_tmplName) || n.Equals(MaterialDef::k_tmplName));
}
