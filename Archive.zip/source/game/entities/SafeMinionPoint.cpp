// source/game/entities/SafeMinionPoint.cpp
