// source/game/entities/Bonus.cpp
