// source/game/entities/Launcher.cpp
