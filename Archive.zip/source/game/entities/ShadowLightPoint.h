// source/game/entities/ShadowLightPoint.h
#ifndef SOURCE_GAME_ENTITIES_SHADOWLIGHTPOINT_H
#define SOURCE_GAME_ENTITIES_SHADOWLIGHTPOINT_H

class ShadowLightPoint : public GameEntity, public Singleton<ShadowLightPoint> {  // sizeof 0x94
public:
    ShadowLightPoint(const clara::Template*);
    virtual ~ShadowLightPoint();
    virtual void Init();
    virtual void SetEnabled(bool);
    virtual void SetVisible(bool);
    virtual void Render();
    virtual void NotifyTransformChanged(bool);
    static void ApplyRefPoint(const math::vec3<float>&);
    static void SetModelRefPoint(jet::scene::Model*);
    static jet::String k_tmplName;
private:
    static jet::scene::Model *m_modelRefPoint;
};

#endif
