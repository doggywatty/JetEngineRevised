// source/game/entities/Launcher.h
#ifndef SOURCE_GAME_ENTITIES_LAUNCHER_H
#define SOURCE_GAME_ENTITIES_LAUNCHER_H

class Launcher : public GameEntity {  // sizeof 0xA0
protected:
    virtual bool RttiIsOfType(int);
    virtual void* RttiCastTo(int);
    static unsigned RttiGetClassId();
    static const char *RttiGetClassIdName();
    virtual const char *RttiGetInstanceClassIdName();
    virtual int RttiGetInstanceClassId();
public:
    Launcher(const clara::Template*);
    virtual ~Launcher();
    virtual void Init();
    virtual void PostInit();
    virtual void SetSpawnLane(int);
    InteractiveAnimatedPusher *CreatePusher(const clara::Path&);
    void CreateDefaultPusher();
    void CreateUpgradePusher();
    void InitLauncherData();
    void InitPushers();
    void ActivatePusher(bool);
    static jet::String k_tmplName;
private:
    InteractiveAnimatedPusher *m_defaultPusher;  // 0x90
    InteractiveAnimatedPusher *m_upgradePusher;  // 0x94
    LaneIndex m_spawnLane;  // 0x98
    bool m_usesUpgradedPusher;  // 0x9C
    static const float k_hideLauncherOffsetZ;
    static const jet::String k_interactiveAnimatedPusherParam;
    static const jet::String k_interactiveAnimatedPusherUpgradesParam;
};

#endif
