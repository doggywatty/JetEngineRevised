// source/game/entities/InteractiveObjectTemplate.h
#ifndef SOURCE_GAME_ENTITIES_INTERACTIVEOBJECTTEMPLATE_H
#define SOURCE_GAME_ENTITIES_INTERACTIVEOBJECTTEMPLATE_H

class InteractiveObjectTemplate : public Object, public StateMachine, public SynchronizedObject {  // sizeof 0x2D4
protected:
    virtual bool RttiIsOfType(int);
    virtual void* RttiCastTo(int);
    static unsigned RttiGetClassId();
    static const char *RttiGetClassIdName();
    virtual const char *RttiGetInstanceClassIdName();
    virtual int RttiGetInstanceClassId();
public:
    InteractiveObjectTemplate(const clara::Template*);
    virtual ~InteractiveObjectTemplate();
    virtual void Init();
    virtual void PostInit();
    virtual void Update();
    virtual void CollidesWith(Collision3d*, const CollisionPair&);
    virtual void SetSpawnLane(int);
    virtual void OnSyncFinished();
    virtual unsigned SM_GetId();
    float GetDespicablePoints();
    float GetDespicablePointsOnDistanceTrigger();
    void OnFreeze();
    bool GetForzeSpawnIt();
    virtual void OnMinionRevive();
private:
    void InitStateMachine();
    void InitPreContactAnims();
    void SetPostFxState(InteractiveObjectTemplate::PostFxAnimState);
    void UpdatePostFxState(unsigned);
    void UpateDistanceTriggers();
    void UpdatePreContactAnims(unsigned);
    void StopIdleSound();
public:
    static jet::String k_tmplName;
    static jet::String k_superflousInteractive_tmplName;
private:
    jet::String m_animOnContact;  // 0x200
    bool m_useEngineEvent;  // 0x204
    int m_engineEvent;  // 0x208
    float m_despicablePoints;  // 0x20C
    bool m_hideOnContact;  // 0x210
    bool m_useStateMachine;  // 0x211
    jet::String m_stateOnContact;  // 0x214
    InteractiveObjectTemplate::PreContactAnimState m_preContactState;  // 0x218
    jet::String m_stateOnPreContact;  // 0x21C
    int m_preContactTime;  // 0x220
    EffectDef *m_preContactEffects[3];  // 0x224
    int m_preContactEffectTime;  // 0x230
    int m_preContactProjectileEffectTime;  // 0x234
    int m_preContactProjectileEffectTimeCount;  // 0x238
    EffectControl *m_preContactProjectileEffectCtrl;  // 0x23C
    bool m_useDistanceTrigger;  // 0x240
    float m_distanceTriggerSq;  // 0x244
    std::vector<EffectDef *,std::allocator<EffectDef *> > m_effectOnDistanceTrigger;  // 0x248
    bool m_hideOnDistanceTrigger;  // 0x25C
    float m_despicablePointsOnDistanceTrigger;  // 0x260
    MaterialDef *m_postFxMaterial;  // 0x264
    int m_postFxTimeIntro;  // 0x268
    int m_postFxTime;  // 0x26C
    int m_postFxTimeOutro;  // 0x270
    float m_postFxMaxValue;  // 0x274
    jet::core::Delayer<float,jet::core::QuadraticEaseIn> m_postFxUniformValue;  // 0x278
    InteractiveObjectTemplate::PostFxAnimState m_postFxState;  // 0x290
    jet::video::PostEffect *m_postFx;  // 0x294
    bool m_playIdleSound;  // 0x298
    float m_playIdleSoundDistanceSq;  // 0x29C
    jet::String m_idleSoundLabel;  // 0x2A0
    int m_idleSoundHandle;  // 0x2A4
    std::vector<jet::String,std::allocator<jet::String> > m_animOnFreeze;  // 0x2A8
    std::vector<EffectDef const *,std::allocator<EffectDef const *> > m_effectOnFreeze;  // 0x2BC
    bool m_hideOnFreeze;  // 0x2D0
    bool m_forzeSpawnIt;  // 0x2D1
    static const jet::String k_animOnContact;
    static const jet::String k_useEngineEventOnContact;
    static const jet::String k_engineEventOnContact;
    static const jet::String k_despicablePoints;
    static const jet::String k_stateOnContact;
    static const jet::String k_hideOnContact;
    static const jet::String k_forceSpawnIt;
    static const jet::String k_enablePreContactAnimations;
    static const jet::String k_stateOnPreContact;
    static const jet::String k_preContactTime;
    static const jet::String k_preContactEffectTime;
    static const jet::String k_preContactProjectileTime;
    static const jet::String k_preContactProjectileEffect;
    static const jet::String k_PreContactImpactEffect;
    static const jet::String k_preContactObstacleEffect;
    static const jet::String k_animOnFreeze;
    static const jet::String k_effectOnFreeze;
    static const jet::String k_hideOnFreeze;
    static const jet::String k_useDistanceTrigger;
    static const jet::String k_distanceTrigger;
    static const jet::String k_effectOnDistanceTrigger;
    static const jet::String k_hideOnDistanceTrigger;
    static const jet::String k_despicablePointsOnDistanceTrigger;
    static const jet::String k_usePostFxDistortion;
    static const jet::String k_postFxMaterial;
    static const jet::String k_postFxMaterialLow;
    static const jet::String k_postFxTimeIntro;
    static const jet::String k_postFxTime;
    static const jet::String k_postFxTimeOutro;
    static const jet::String k_postFxUniformMaxValue;
    static const jet::String k_playIdleSoundParam;
    static const jet::String k_playIdleSoundDistanceParam;
    static const jet::String k_idleSoundLabelParam;
};

#endif
