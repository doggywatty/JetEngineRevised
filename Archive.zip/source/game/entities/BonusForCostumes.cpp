// source/game/entities/BonusForCostumes.cpp
