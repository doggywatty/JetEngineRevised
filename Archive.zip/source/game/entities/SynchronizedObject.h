// source/game/entities/SynchronizedObject.h
#ifndef SOURCE_GAME_ENTITIES_SYNCHRONIZEDOBJECT_H
#define SOURCE_GAME_ENTITIES_SYNCHRONIZEDOBJECT_H

class SynchronizedObject : public PacesetterFollower {  // sizeof 0x98
public:
    SynchronizedObject();
    virtual ~SynchronizedObject();
    void Init(Object*);
    void Update();
    virtual void OnSyncFinished();
    void StopPacesetter(bool);
    virtual void GoTo(const math::vec3<float>&, const math::quat<float>&);
    virtual void OnGameplayTemplateInstanceDestroyed();
    void SetSpawnLane(LaneIndex);
    LaneIndex GetSpawnLane();
    bool HasPacesetter();
    bool IsControllingAnim();
private:
    void InitPacesetter();
    bool InitPacesetterCourse();
    bool StartPacestterCourse(float, float);
    void _Update();
    void _UpdatePreContact();
protected:
    void ResetPacestterCourse();
    bool OnMinionRevive();
    void AddSyncMovementDistance(float);
    float ComputeTimeToGetReached();
    float GetTimeToGetReached();
    Pacesetter::PacestterCacheData m_cacheData0;  // 0x8
    Pacesetter::PacestterCacheData m_cacheData1;  // 0x1C
private:
    SynchronizedObject::SynchronizationAnimType m_animType;  // 0x30
    jet::String m_prePositionAnimation;  // 0x34
    jet::String m_postPositionAnimation;  // 0x38
    int m_timeOffset;  // 0x3C
    int m_prePositionAnimationTime;  // 0x40
    int m_lastTime;  // 0x44
    int m_skipCount;  // 0x48
    Pacesetter *m_pacesetterInstance;  // 0x4C
    int m_syncMovement_time;  // 0x50
    float m_syncMovement_distance;  // 0x54
    bool m_pacesetterCourseInit;  // 0x58
    bool m_pacesetterCourseFinished;  // 0x59
    bool m_pacesetterCourseLocked;  // 0x5A
    float m_timeToGetReached;  // 0x5C
    float m_distanceToGetReached;  // 0x60
    int m_lastTimeComputeFrame;  // 0x64
    LaneIndex m_spawnLane;  // 0x68
    Object *m_owner;  // 0x6C
    math::vec3<float> m_localPosition;  // 0x70
    math::quat<float> m_localRotation;  // 0x7C
    int m_preContactTimeMax;  // 0x8C
    int m_preContactTimeMin;  // 0x90
    int m_preContactEngineEvent;  // 0x94
    static const jet::String k_prePositionAnimation;
    static const jet::String k_postPositionAnimation;
    static const jet::String k_timeOffset;
    static const jet::String k_useSyncMovement;
    static const jet::String k_syncDistance;
    static const jet::String k_syncTime;
    static const jet::String k_preContactTimeMaxParam;
    static const jet::String k_preContactTimeMinParam;
    static const jet::String k_preContactEngineEventParam;
};

struct btPointCollector : public btDiscreteCollisionDetectorInterface::Result {  // sizeof 0x40
    btPointCollector();
    virtual void setShapeIdentifiersA(int, int);
    virtual void setShapeIdentifiersB(int, int);
    virtual void addContactPoint(const btVector3&, const btVector3&, float);
    btVector3 m_normalOnBInWorld;  // 0x10
    btVector3 m_pointInWorld;  // 0x20
    float m_distance;  // 0x30
    bool m_hasResult;  // 0x34
};

#endif
