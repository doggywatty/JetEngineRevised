// source/game/entities/TriggerEntity.cpp
