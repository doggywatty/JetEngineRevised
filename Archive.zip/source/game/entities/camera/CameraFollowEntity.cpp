// source/game/entities/camera/CameraFollowEntity.cpp
