// source/game/entities/camera/CameraFollowEntity.h
#ifndef SOURCE_GAME_ENTITIES_CAMERA_CAMERAFOLLOWENTITY_H
#define SOURCE_GAME_ENTITIES_CAMERA_CAMERAFOLLOWENTITY_H

class CameraFollowEntity : public CameraEntity {  // sizeof 0x9C
protected:
    virtual bool RttiIsOfType(int);
    virtual void* RttiCastTo(int);
    static unsigned RttiGetClassId();
    static const char *RttiGetClassIdName();
    virtual const char *RttiGetInstanceClassIdName();
    virtual int RttiGetInstanceClassId();
public:
    virtual const jet::String &GetBaseTemplateName();
    CameraFollowEntity(const clara::Template*);
    virtual ~CameraFollowEntity();
    virtual void Init();
    virtual void PostInit();
    CameraFollowEntity::FollowCameraConfigStruct *GetCameraConfig();
    virtual CameraController *GetCameraController();
    void SetFocusTarget(CameraTarget*);
    static jet::String k_RunningCameraConfig_tmplName;
    static jet::String k_tmplName;
private:
    float m_fov;  // 0x90
    FollowMinionCamera *m_followCamera;  // 0x94
    CameraFollowEntity::FollowCameraConfigStruct *m_camerConfig;  // 0x98
};

#endif
