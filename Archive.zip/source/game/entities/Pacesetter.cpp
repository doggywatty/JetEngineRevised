// source/game/entities/Pacesetter.cpp
#include "Pacesetter.h"
#include "pacesetterfollower.h"
#include "../leveltemplate/GameplayTemplateInstance.h"
#include <algorithm>

jet::String Pacesetter::k_tmplName("Pacesetter");

Pacesetter::~Pacesetter() {
    RegisterForUpdate(false);
    RegisterForRender(false);
}

// @0x4f5a08
void Pacesetter::Init() {
    if (!(m_flags & F_INIT)) clara::Entity::Init();
}

// @0x4f5a0c
void Pacesetter::PostInit() {
    m_currentLane = 1;
    RegisterForUpdate(true);
    RegisterForRender(true);
}

// @0x4f6b44: the followers go where it goes
void Pacesetter::NotifyTransformChanged(bool b) {
    GameEntity::NotifyTransformChanged(b);
    for (PacesetterFollower *f : m_followers) f->GoTo(GetPosition(), GetRotation());
}

// @0x4f6964
void Pacesetter::RegisterFollower(PacesetterFollower *f) {
    m_followers.push_back(f);
    f->SetPacesetter(this);
}

// @0x4f69dc
void Pacesetter::UnregisterFollower(PacesetterFollower *f) {
    m_followers.erase(std::remove(m_followers.begin(), m_followers.end(), f), m_followers.end());
    f->SetPacesetter(0);
}

// @0x4f6abc
void Pacesetter::SetController(PacesetterController *c) {
    if (c == m_controller) return;
    if (m_controller) {
        m_controller->EndControl(this);
        SendPacesetterEvent({ PacesetterEventType::ControlEnded });
    }
    m_controller = c;
    if (c) {
        c->StartControl(this);
        SendPacesetterEvent({ PacesetterEventType::ControlStarted });
    }
}

// @0x4f7580
void Pacesetter::SendPacesetterEvent(const PacesetterEvent &e) {
    for (PacesetterFollower *f : m_followers) f->OnPacesetterEvent(e);
}

// @0x4b0618
void Pacesetter::SetCurrentGameplayTemplateInstance(GameplayTemplateInstance *g) {
    if (m_currentGti) m_currentGti->UnregisterListener(this);
    m_currentGti = g;
    if (g) g->RegisterListener(this);
}

// @0x4f5a34: the instance is gone, the followers know
void Pacesetter::OnGameplayTemplateInstanceEvent(const GameplayTemplateInstanceEvent &e) {
    if (e.type != GameplayTemplateInstanceEvent::Destroyed) return;
    m_currentGti = 0;
    for (PacesetterFollower *f : m_followers) f->OnGameplayTemplateInstanceDestroyed();
}
