// source/game/entities/BonusSet.cpp
