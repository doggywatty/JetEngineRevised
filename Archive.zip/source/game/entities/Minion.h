// source/game/entities/Minion.h
#ifndef SOURCE_GAME_ENTITIES_MINION_H
#define SOURCE_GAME_ENTITIES_MINION_H

#include "GameEntity.h"

class Deco3d;
struct StateSetData;
struct StateData;

// The player minion ("Minion" template). Shown by a copy of its objectDeco (Object::InitDeco3d
// @0x57f3e4) and driven by a state machine from the "states" database: in the main menu
// MainMenuStateMachine (minion_menu | Idle). Entering a state follows its immediate triggers
// (event -1) whose conditions hold, then plays the state's animation (looping when it has a
// Loop track) at AnimSpeed percent.
class Minion : public GameEntity {
public:
    explicit Minion(const clara::Template*);
    virtual ~Minion();
    virtual void Init();
    virtual void PostInit();
    virtual void Update();
    virtual void Render();
    // the costume index the IsMinion conditions test (15: the regular minion)
    void SetCostumeIdx(int c) { m_costumeIdx = c; }
    bool SetStateMachine(const jet::String &set, const jet::String &state);
    bool EnterState(const jet::String &state);
    const StateData *GetState() const { return m_state; }
    Deco3d *GetDeco() const { return m_deco; }
    // how far the minion has run: the part the level sequence advanced and the part it ran itself
    unsigned GetTraveledDistance() const { return m_distanceBase + m_distanceRun; }
    unsigned GetDistanceBase() const { return m_distanceBase; }
    void SetDistanceBase(unsigned d) { m_distanceBase = d; }
    unsigned GetDistanceRun() const { return m_distanceRun; }
    void SetDistanceRun(unsigned d) { m_distanceRun = d; }
    void SetLocationEnterDistance(unsigned d) { m_locationEnterDistance = d; }
    // the modes the background's rocket path takes the pacesetter over in (named from their use)
    bool IsInRocketMode() const { return m_rocketMode; }
    bool IsInFluffyMode() const { return m_fluffyMode; }
    static jet::String k_tmplName;
private:
    bool CheckCondition(const jet::String &name, int value) const;
    Deco3d *m_deco;
    const StateSetData *m_stateSet;
    const StateData *m_state;
    int m_costumeIdx;
    unsigned m_distanceBase = 0, m_distanceRun = 0, m_locationEnterDistance = 0;  // 0x500, 0x504, 0x508
    bool m_rocketMode = false, m_fluffyMode = false;                            // 0x389, 0x38A
};

#endif
