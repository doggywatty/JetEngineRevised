// source/game/entities/BananaTemplatePath.h
#ifndef SOURCE_GAME_ENTITIES_BANANATEMPLATEPATH_H
#define SOURCE_GAME_ENTITIES_BANANATEMPLATEPATH_H

class BananaTemplatePath : public GameEntity {  // sizeof 0xAC
public:
    BananaTemplatePath(const clara::Template*);
    virtual ~BananaTemplatePath();
    virtual void Init();
    virtual void PostInit();
    virtual void Update();
    unsigned GetNumObjectsToCreate();
    virtual void OnLinkedHidden();
protected:
    virtual void NotifyTransformChanged(bool);
private:
    void BuildPath();
    void CreateBananas();
    bool RefreshBananaTransform();
    bool ProjectOnGrund(math::vec3<float>&);
public:
    static jet::String k_tmplName;
private:
    bool m_updateTransform;  // 0x90
    bool m_projectOnGround;  // 0x91
    std::auto_ptr<PathCommon> m_path;  // 0x94
    std::vector<BananaTemplate *,std::allocator<BananaTemplate *> > m_bananas;  // 0x98
    static const jet::String k_points;
    static const jet::String k_pathWidth;
    static const jet::String k_interpType;
    static const jet::String k_numSamples;
    static const jet::String k_tension;
    static const jet::String k_bias;
    static const jet::String k_numObjectsInPath;
    static const jet::String k_projectOnGround;
};

#endif
