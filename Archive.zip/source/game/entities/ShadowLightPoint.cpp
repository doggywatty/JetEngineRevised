// source/game/entities/ShadowLightPoint.cpp
