// source/game/entities/Object.h
#ifndef SOURCE_GAME_ENTITIES_OBJECT_H
#define SOURCE_GAME_ENTITIES_OBJECT_H

#include <list>
#include <vector>
#include "GameEntity.h"

class Deco3d;
class EffectDef;

// A placed thing made of a deco (picked among the "objectDeco" references) the model of the platforms and gameplay
// objects. Not ported yet: the collision (Collision3d), the effects played on contact and the sounds and particles
// attached to the entity.
class Object : public GameEntity {  // sizeof 0xC8
public:
    static const jet::String k_tmplName, k_objectDeco, k_objectCollision3d, k_effectOnContact, k_effectOnContactSpawnAll, k_movieLinkedDeco;
    explicit Object(const clara::Template *t);
    virtual void Init();
    virtual void PostInit();
    virtual void Update();
    virtual void NotifyAnimationChanged();
    virtual bool GetLinkPointTransform(const jet::String &point, math::vec3<float> &pos, math::quat<float> &rot) const;
    virtual bool IsOutOfScene() const;
    virtual void SetPersistenceType(int t);
    virtual void OnPositionedInWorld();
    Deco3d *GetDeco() const { return m_deco; }
    // the deco made for this object takes the place of another one
    void AdoptDeco3d(Deco3d *d);
    void DestroyDeco3d();
    // the entity linked to the deco (as an extra copy of the deco)
    void AddLinkedEntity(Deco3d *d);
    bool CanLoadModel() const;
    bool m_decoTransferred;  // 0x90
private:
    void InitDeco3d(Deco3d *ref);
    void InitMovieDeco();
    void InitEffectOnContact();
    // the deco asked by the data (one of the "objectDeco" references, chosen once), or the default
    Deco3d *GetDecoReference(unsigned *index, bool onlyLoadable) const;
    std::list<Deco3d*> m_linkedDecos;       // 0x94
    unsigned m_ctorFlags;                   // 0x9C
    std::vector<const EffectDef*> m_effectsOnContact;  // 0xA4
    Deco3d *m_deco;                         // 0xB0
    mutable Deco3d *m_decoReference;        // 0xB4
    Deco3d *m_defaultDeco;                  // 0xB8
    mutable unsigned m_decoIndex;           // 0xBC
    bool m_effectOnContactSpawnAll;         // 0xC0
};

#endif
