// source/game/entities/Mission.cpp
