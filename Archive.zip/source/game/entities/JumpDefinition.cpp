// source/game/entities/JumpDefinition.cpp
