// source/game/entities/GameplayDef.h
#ifndef SOURCE_GAME_ENTITIES_GAMEPLAYDEF_H
#define SOURCE_GAME_ENTITIES_GAMEPLAYDEF_H

class GameplayDef : public GameEntity {  // sizeof 0xE8
public:
    GameplayDef(const clara::Template*);
    virtual ~GameplayDef();
    virtual void PostInit();
    virtual void NotifyParamChanged(const jet::String&);
    EffectDef *GetCollisionEffect(unsigned, GameplayDef::CollisionEffects);
    float GetGravity();
    Token *GetDailyToken();
    JumpDefinition *GetJumpDefinition(GameplayDef::JumpDefinitionType, float);
    const ustl::vector<BackgroundPool *> &GetFastForwardBackgrounds();
    const ustl::vector<TemplatePool *> &GetFastForwardTemplates();
private:
    void LoadJumpDefinitions(clara::Param*);
public:
    static jet::String k_tmplName;
    static jet::String k_CollisionEffectPack_tmplName;
    static jet::String k_GameplayDefJumpDefinitionConfig_tmplName;
private:
    std::map<unsigned int,std::vector<EffectDef *,std::allocator<EffectDef *> >,std::less<unsigned int>,std::allocator<std::pair<unsigned int const ,std::vector<EffectDef *,std::allocator<EffectDef *> > > > > m_collisionEffects;  // 0x90
    std::vector<GameplayDef::JumpDefinitionsConfig,std::allocator<GameplayDef::JumpDefinitionsConfig> > m_jumpConfig;  // 0xAC
    float m_gravity;  // 0xC0
    Token *m_dailyToken;  // 0xC4
    ustl::vector<BackgroundPool *> m_fastForwardBackgrounds;  // 0xC8
    ustl::vector<TemplatePool *> m_fastForwardTemplates;  // 0xD8
    static const jet::String k_collisionEffectsIdParam;
    static const jet::String k_collisionEffectsParamNames[3];
    static const jet::String k_cameraOffsetParam;
    static const jet::String k_accelerationParam;
    static const jet::String k_JumpDefinitionsParam;
    static const jet::String k_jumpDefinitionMaxSpeedParam;
    static const jet::String k_jumpDefinitionParamNames[3];
    static const jet::String k_jumpImpulseParam;
    static const jet::String k_jumpFrontDistanceParam;
    static const jet::String k_jumpUpDistanceParam;
    static const jet::String k_dashDownGravityParam;
    static const jet::String k_slideDistanceParam;
    static const jet::String k_changeLaneTimeParam;
    static const jet::String k_changeLaneMaxSpeedParam;
    static const jet::String k_bulletTimeTrackTransTimePgtParam;
    static const jet::String k_postShieldInvulnerabilityTimeParam;
    static const jet::String k_maxDespicablePointsParam;
    static const jet::String k_despicableBarTimeParam;
    static const jet::String k_maxDespicablePointsArray;
    static const jet::String k_despBarDepletion_PerSec;
    static const jet::String k_DespBarDepletion_BananaSafeTime;
    static const jet::String k_DespBarDepletion_DespicableSafeTime;
    static const jet::String k_DespicablePointsOnFreezeObjectsParam;
    static const jet::String k_ScoreMeterMultiplier;
    static const jet::String k_ScoreBananaMultiplier;
    static const jet::String k_ScoreDespicableMultiplier;
    static const jet::String k_ScoreNearmiss;
    static const jet::String k_ScoreLocationChange;
    static const jet::String k_ScoreBossBeaten;
    static const jet::String k_ScorePassAFriend;
    static const jet::String k_ScoreBeatYourBestDistance;
    static const jet::String k_ScoreBeatYourOwnBestScore;
    static const jet::String k_ScoreFreezeGunDestroyObstacle;
    static const jet::String k_postSledgeInvulnerabilityTimeParam;
    static const jet::String k_sledgeGravityMultiplierParam;
    static const jet::String k_collisionEffectsParam;
    static const jet::String k_lastDistanceInteractiveObjectParam;
    static const jet::String k_friendDistanceObjectsRefParam;
    static const jet::String k_item_totalProbabilityParam;
    static const jet::String k_dailyTokenRefParam;
    static const jet::String k_item_minimumItemSpaceParam;
    static const jet::String k_item_maximumItemSpaceParam;
    static const jet::String k_item_initialSpaceParam;
    static const jet::String k_freezingGunBulletEffectParam;
    static const jet::String k_postFxMaterialParam;
    static const jet::String k_ffwCameraParam;
    static const jet::String k_ffwCameraTransitionTimeParam;
    static const jet::String k_ffwFlyingAltitudeParam;
    static const jet::String k_missionMultiplierLvlArray;
    static const jet::String k_missionsInitialOrder;
    static const jet::String k_checkpointPrice;
    static const jet::String k_perkBananaMultiplierPrice;
    static const jet::String k_perkDespicableMultiplierPrice;
    static const jet::String k_perkDespicableMultiplierValue;
    static const jet::String k_deathRevivePrices;
    static const jet::String k_quickTip_BananaMultiplierPrice;
    static const jet::String k_quickTip_DespicableMultiplierPrice;
    static const jet::String k_safeMinionPointdefaultReferenceParam;
    static const jet::String k_resiSkyDomeParam;
    static const jet::String k_cannonBackgroundsParam;
    static const jet::String k_cannonTemplatesParam;
    static const jet::String k_freezeRayTutorialParam;
    static const jet::String k_bananaVacuumTutorialParam;
    static const jet::String k_bananaSplitterTutorialParam;
    static const jet::String k_minionShieldTutorialParam;
    static const jet::String k_sledgeTutorialParam;
};

#endif
