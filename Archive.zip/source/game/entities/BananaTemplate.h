// source/game/entities/BananaTemplate.h
#ifndef SOURCE_GAME_ENTITIES_BANANATEMPLATE_H
#define SOURCE_GAME_ENTITIES_BANANATEMPLATE_H

class BananaTemplate : public Object {  // sizeof 0x138
public:
    BananaTemplate(const clara::Template*);
    virtual ~BananaTemplate();
    virtual void Init();
    virtual void PostInit();
    virtual void Update();
    void Die();
    void SetMagnetized(bool);
    void Push(const math::vec2<float>&);
    virtual void OnLinkedHidden();
private:
    bool IsDead();
    float GetMagnetizedTime();
    void UpdateBananaState();
    void CheckBananaDecoChange();
    bool IsOnCombo();
public:
    static jet::String k_tmplName;
private:
    int m_state;  // 0xDC
    float m_magnetizedTime;  // 0xE0
    bool m_isMagnetized;  // 0xE4
    bool m_comboState;  // 0xE5
    TModelData m_origData;  // 0xE8
    TModelData m_comboData;  // 0x108
    float m_collectionDistanceSq;  // 0x128
    float m_magnetDistanceSq;  // 0x12C
    jet::String m_collectionComboSoundLabel;  // 0x130
    jet::String m_collectionSoundLabel;  // 0x134
    static const jet::String k_comboDeco;
    static const jet::String k_collectionSound;
    static const jet::String k_collectionComboSound;
    static const jet::String k_collectionDistance;
    static const jet::String k_magnetDistance;
};

#endif
