// source/game/entities/AchievementSet.h
#ifndef SOURCE_GAME_ENTITIES_ACHIEVEMENTSET_H
#define SOURCE_GAME_ENTITIES_ACHIEVEMENTSET_H

class AchievementSet : public GameEntity {  // sizeof 0xA0
public:
    static AchievementSet *GetInstance();
    static bool HasInstance();
    AchievementSet(const clara::Template*);
    virtual ~AchievementSet();
    virtual void Init();
    virtual void PostInit();
    void OnAchievementCompleted(Achievement*);
    virtual void Update();
    ustl::vector<Achievement *> &GetAchievements();
    static jet::String k_tmplName;
private:
    ustl::vector<Achievement *> m_achievements;  // 0x90
    static AchievementSet *s_instance;
};

#endif
