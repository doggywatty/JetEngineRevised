// source/game/entities/InteractiveAnimatedPusher.cpp
