// source/game/entities/MissionCondition.h
#ifndef SOURCE_GAME_ENTITIES_MISSIONCONDITION_H
#define SOURCE_GAME_ENTITIES_MISSIONCONDITION_H

class MissionCondition : public GameEntity, public StatisticsObserver {  // sizeof 0xC8
public:
    MissionCondition(MissionCondition*);
    MissionCondition(const clara::Template*);
    virtual ~MissionCondition();
    virtual void Init();
    virtual void PostInit();
    void Reset();
    virtual void ForceUpdate();
    virtual void Update(const jet::String&, const GameplayStatisticsValue&);
    void SetComplete(bool);
    bool IsCompleted();
    float GetCompletedPercentage();
    bool IsFloatValue();
    float GetFloatValue();
    int GetIntValue();
    void RegisterObserver();
    void UnregisterObserver();
    void SetRepeatCountValues(int);
    bool IsScopeCodeImplemented();
    const jet::String &GetConditionStatScope();
    void LinkTo(clara::Entity*, const jet::String&, unsigned);
private:
    void SetConditionValue(int);
public:
    static jet::String k_tmplName;
private:
    jet::String m_conditionStatScope;  // 0x9C
    MissionCondition::ConditionOperand m_operand;  // 0xA0
    bool m_completed;  // 0xA4
    float m_completedPercentage;  // 0xA8
    bool m_observerRegistered;  // 0xAC
    int m_intValue;  // 0xB0
    float m_floatValue;  // 0xB4
    float m_repeatMissionMultiplier;  // 0xB8
    int m_claraIntValue;  // 0xBC
    float m_claraFloatValue;  // 0xC0
    jet::String s_debugLinkedName;  // 0xC4
};

#endif
