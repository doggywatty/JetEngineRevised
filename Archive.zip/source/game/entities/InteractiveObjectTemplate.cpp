// source/game/entities/InteractiveObjectTemplate.cpp
