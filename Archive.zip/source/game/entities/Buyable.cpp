// source/game/entities/Buyable.cpp
