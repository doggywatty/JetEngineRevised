// source/game/entities/SafeMinionPoint.h
#ifndef SOURCE_GAME_ENTITIES_SAFEMINIONPOINT_H
#define SOURCE_GAME_ENTITIES_SAFEMINIONPOINT_H

class SafeMinionPoint : public GameEntity, public GameplayTemplateInstanceListener {  // sizeof 0xB4
public:
    SafeMinionPoint(const clara::Template*);
    virtual ~SafeMinionPoint();
    virtual void Init();
    virtual void PostInit();
    void ComputeCollisionPlane();
    virtual void Update();
    virtual void Render();
    virtual void OnGameplayTemplateInstanceEvent(const GameplayTemplateInstance::GameplayTemplateInstanceEvent&);
    void Register(GameplayTemplateInstance*);
    float GetDistance(math::vec3<float>);
    float GetDistanceToPlane(math::vec3<float>);
    virtual void SetSpawnLane(int);
    int GetSpawnLane();
    void RenderDebug(jet::video::Painter&);
    GameplayTemplateInstance *GetContainerGameplayTemplateInstance();
    bool GetIsLandable();
private:
    void RegisterSafeMinionPoint();
    void RegisterToNotifier(GameplayTemplateInstance*);
    void UnregisterSafeMinionPoint();
    void UnregisterFromNotifier();
public:
    static jet::String k_tmplName;
private:
    bool m_isRegistered;  // 0x94
    GameplayTemplateInstance *m_notifier;  // 0x98
    static const float k_distanceToCheckSq;
    math::plane<float> m_safeMinionPointPlane;  // 0x9C
    int m_lane;  // 0xAC
    bool m_unregisterFromNotifier;  // 0xB0
    bool m_isLandable;  // 0xB1
    static const jet::String k_isLandableParam;
};

#endif
