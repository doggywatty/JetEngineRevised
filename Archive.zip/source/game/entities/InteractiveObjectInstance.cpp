// source/game/entities/InteractiveObjectInstance.cpp
