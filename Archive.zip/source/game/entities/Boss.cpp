// source/game/entities/Boss.cpp
