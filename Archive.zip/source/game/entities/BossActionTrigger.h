// source/game/entities/BossActionTrigger.h
#ifndef SOURCE_GAME_ENTITIES_BOSSACTIONTRIGGER_H
#define SOURCE_GAME_ENTITIES_BOSSACTIONTRIGGER_H

class BossActionTrigger : public GameEntity {  // sizeof 0x98
public:
    BossActionTrigger(const clara::Template*);
    virtual ~BossActionTrigger();
    virtual void Init();
    virtual void PostInit();
    virtual void Update();
    static jet::String k_tmplName;
private:
    int m_engineEvent;  // 0x90
    BossActionTrigger::TriggerState m_state;  // 0x94
    static const jet::String k_engineEventParam;
};

#endif
