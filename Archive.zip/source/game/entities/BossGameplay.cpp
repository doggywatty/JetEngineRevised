// source/game/entities/BossGameplay.cpp
