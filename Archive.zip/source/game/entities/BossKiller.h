// source/game/entities/BossKiller.h
#ifndef SOURCE_GAME_ENTITIES_BOSSKILLER_H
#define SOURCE_GAME_ENTITIES_BOSSKILLER_H

class BossKiller : public Object {  // sizeof 0xE4
public:
    BossKiller(const clara::Template*);
    virtual ~BossKiller();
    virtual void Update();
    virtual void PostInit();
    static jet::String k_tmplName;
private:
    jet::String m_exitStateName;  // 0xDC
    jet::String m_defeatedExitStateName;  // 0xE0
    static jet::String k_exitStateParamName;
    static jet::String k_defeatedExitStateParamName;
};

#endif
