// source/game/entities/JumpDefinition.h
#ifndef SOURCE_GAME_ENTITIES_JUMPDEFINITION_H
#define SOURCE_GAME_ENTITIES_JUMPDEFINITION_H

class JumpDefinition : public GameEntity {  // sizeof 0xD0
public:
    JumpDefinition(const clara::Template*);
    virtual ~JumpDefinition();
    virtual void Init();
    virtual void PostInit();
    virtual void Render();
    bool UpateControl(JumpDefinitionControl&, float);
    math::vec3<float> GetMovementDelta(JumpDefinitionControl&);
    void InitCtrl(JumpDefinitionControl&, float);
    void InitCtrl(JumpDefinitionControl&);
    float GetAverageFrontSpeed(JumpDefinitionControl&);
    bool GetCanFallOut();
private:
    float TimeToPgt(float, float);
    void BuildPath();
public:
    static jet::String k_tmplName;
    static jet::String k_JumpPathPoint_tmplName;
private:
    safe_enum<jet::core::InterpolationDef,enum jet::core::InterpolationDef::type> m_interpolationType;  // 0x90
    float m_totalTime;  // 0x94
    std::auto_ptr<PathCommon> m_path;  // 0x98
    float m_timeMultMin;  // 0x9C
    float m_timeMultMax;  // 0xA0
    bool m_canFallOut;  // 0xA4
    std::vector<JumpDefinition::DistancePoint,std::allocator<JumpDefinition::DistancePoint> > m_distanceDistribution;  // 0xA8
    std::vector<float,std::allocator<float> > m_timesPgt;  // 0xBC
    static const jet::String k_minTimeMult;
    static const jet::String k_maxTimeMult;
    static const jet::String k_canFallOut;
    static const jet::String k_points;
    static const jet::String k_pathWidth;
    static const jet::String k_interpType;
    static const jet::String k_numSamples;
    static const jet::String k_tension;
    static const jet::String k_bias;
    static const jet::String k_interpolationType;
    static const jet::String k_totalTime;
    static const jet::String k_timePgt;
};

#endif
