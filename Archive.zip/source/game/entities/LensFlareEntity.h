// source/game/entities/LensFlareEntity.h
#ifndef SOURCE_GAME_ENTITIES_LENSFLAREENTITY_H
#define SOURCE_GAME_ENTITIES_LENSFLAREENTITY_H

#include "GameEntity.h"

// A lens flare placed in the data: which LensFlareDef it shows and from how far (squared) it can be seen
class LensFlareEntity : public GameEntity {  // sizeof 0xB0
public:
    static jet::String k_tmplName;
    explicit LensFlareEntity(const clara::Template *t) : GameEntity(t), m_def(0), m_enabled(true), m_renderable(false), m_visible(true), m_minDistSq(10000.0f) {}
    virtual void Init();
    virtual void PostInit();
    virtual void NotifyParamChanged(const jet::String&);
    virtual void SetEnabled(bool b) { m_enabled = b; }
    virtual void SetVisible(bool b) { m_visible = b; }
    void SetRenderable(bool b) { m_renderable = b; }
    bool IsVisible() const { return m_visible && m_renderable; }
    bool IsEnabled() const { return m_enabled; }
    clara::DataEntity *GetDef() const { return m_def; }
    float GetMinDistSq() const { return m_minDistSq; }
private:
    clara::DataEntity *m_def;  // 0x8C
    bool m_enabled;            // 0x90
    bool m_renderable;         // 0x91
    bool m_visible;            // 0x92
    float m_minDistSq;         // 0xAC
};

#endif
