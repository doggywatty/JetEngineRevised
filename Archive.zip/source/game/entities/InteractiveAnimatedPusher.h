// source/game/entities/InteractiveAnimatedPusher.h
#ifndef SOURCE_GAME_ENTITIES_INTERACTIVEANIMATEDPUSHER_H
#define SOURCE_GAME_ENTITIES_INTERACTIVEANIMATEDPUSHER_H

class InteractiveAnimatedPusher : public Object, public SynchronizedObject {  // sizeof 0x1AC
public:
    InteractiveAnimatedPusher(const clara::Template*);
    virtual ~InteractiveAnimatedPusher();
    virtual void PostInit();
    virtual void Init();
    virtual void Update();
    virtual void CollidesWith(Collision3d*, const CollisionPair&);
    virtual void SetSpawnLane(int);
    virtual void OnMinionRevive();
    void DisablePusherBehavior();
    void EnablePusherBehavior();
protected:
    void SetPusherState(InteractiveAnimatedPusher::PusherState);
public:
    static jet::String k_tmplName;
private:
    InteractiveAnimatedPusher::PusherState m_pusherState;  // 0x174
    jet::String m_animOnContact;  // 0x178
    jet::String m_minionStateName;  // 0x17C
    JumpDefinition *m_jumpDefinition;  // 0x180
    float m_frontSpeed;  // 0x184
    float m_upSpeed;  // 0x188
    int m_frontSpeedRestoreTime;  // 0x18C
    int m_engineEventOnPushed;  // 0x190
    math::vec2<float> m_minSpeedInfoPair;  // 0x194
    math::vec2<float> m_maxSpeedInfoPair;  // 0x19C
    ActorState *m_minionPlayingState;  // 0x1A4
    GameEntity *m_exitPoint;  // 0x1A8
    static const jet::String k_animOnContact;
    static const jet::String k_stateOnContact;
    static const jet::String k_jumpDefinition;
    static const jet::String k_upSpeed;
    static const jet::String k_frontSpeed;
    static const jet::String k_frontSpeedRestoreTime;
    static const jet::String k_minSpeedInfoPair;
    static const jet::String k_maxSpeedInfoPair;
    static const jet::String k_useEngineEventParam;
    static const jet::String k_engineEventParam;
    static const jet::String k_exitPointParam;
};

#endif
