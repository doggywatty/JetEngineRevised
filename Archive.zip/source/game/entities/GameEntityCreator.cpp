// source/game/entities/GameEntityCreator.cpp
#include "GameEntityCreator.h"
#include "template.h"
#include "../GameLevel.h"
#include "Deco3d.h"
#include "MaterialDef.h"
#include "RenderPassDef.h"
#include "LightDef.h"
#include "TouchInteract3d.h"
#include "Minion.h"
#include "LevelDef.h"
#include "LocationInfoEntity.h"
#include "LocationConfig.h"
#include "Object.h"
#include "ParticleSystemEntity.h"
#include "LensFlareEntity.h"
#include "TemplateData.h"
#include "TemplatePool.h"
#include "BackgroundData.h"
#include "BackgroundPool.h"
#include "PlatformInstance.h"
#include "PlatformTemplate.h"
#include "ChunkTemplate.h"
#include "camera/CameraDirectEntity.h"
#include "camera/CameraCinematicEntity.h"

static clara::DataEntity *Create(const clara::Template *t) {
    const jet::String &n = t->GetName();
    if (n.Equals("Deco3d")) return new Deco3d(t);
    if (n.Equals(MaterialDef::k_tmplName)) return new MaterialDef(t);
    if (n.Equals(RenderPassDef::k_tmplName)) return new RenderPassDef(t);
    if (n.Equals(LightDef::k_tmplName)) return new LightDef(t);
    if (n.Equals(TouchInteract3d::k_tmplName)) return new TouchInteract3d(t);
    if (n.Equals(Minion::k_tmplName)) return new Minion(t);
    if (n.Equals(LevelDef::k_tmplName)) return new LevelDef(t);
    if (n.Equals(CameraDirectEntity::k_tmplName)) return new CameraDirectEntity(t);
    if (n.Equals(CameraCinematicEntity::k_tmplName)) return new CameraCinematicEntity(t);
    if (n.Equals(LocationInfoEntity::k_tmplName)) return new LocationInfoEntity(t);
    if (n.Equals(LocationConfig::k_tmplName)) return new LocationConfig(t);
    if (n.Equals(Object::k_tmplName)) return new Object(t);
    if (n.Equals(ParticleSystemEntity::k_tmplName)) return new ParticleSystemEntity(t);
    if (n.Equals(LensFlareEntity::k_tmplName)) return new LensFlareEntity(t);
    if (n.Equals(TemplateData::k_tmplName)) return new TemplateData(t);
    if (n.Equals(TemplatePool::k_tmplName)) return new TemplatePool(t);
    if (n.Equals(BackgroundData::k_tmplName)) return new BackgroundData(t);
    if (n.Equals(BackgroundPool::k_tmplName)) return new BackgroundPool(t);
    if (n.Equals(PlatformInstance::k_tmplName)) return new PlatformInstance(t);
    if (n.Equals(PlatformTemplate::k_tmplName)) return new PlatformTemplate(t);
    if (n.Equals(ChunkTemplate::k_tmplName)) return new ChunkTemplate(t);
    return new clara::Entity(t);
}

// @0x53954c: the game's class for the template, which the level then notes
clara::DataEntity *GameEntityCreator::CreateEntity(const clara::Template *t) const {
    clara::DataEntity *e = Create(t);
    if (GameLevel *l = GameLevel::GetInstance()) l->EntityCreated(e);
    return e;
}
