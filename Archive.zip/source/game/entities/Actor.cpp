// source/game/entities/Actor.cpp
