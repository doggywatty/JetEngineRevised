// source/game/entities/BossObstacleTemplate.h
#ifndef SOURCE_GAME_ENTITIES_BOSSOBSTACLETEMPLATE_H
#define SOURCE_GAME_ENTITIES_BOSSOBSTACLETEMPLATE_H

class BossObstacleTemplate : public ObstacleTemplate, public BodyPartOwner {  // sizeof 0x310
public:
    BossObstacleTemplate(const clara::Template*);
    virtual ~BossObstacleTemplate();
    virtual void PostInit();
    virtual void Update();
    virtual void OnHit(bool);
    virtual void BPO_OnBodyPartPressed(BodyPartSection*);
    virtual void BPO_OnBodyPartTouched(BodyPartSection*);
    virtual void BPO_OnBodyPartDragged(BodyPartSection*);
    virtual void BPO_OnBodyPartReleased(BodyPartSection*);
private:
    void UpdateEffect(EffectDef*, EffectControl*&);
    void UpdateEffectLaser(EffectDef*, EffectControl*&, const math::vec3<float>&, const math::vec3<float>&);
    void UpdateEffectMissile(EffectDef*, EffectControl*&, const math::vec3<float>&, float, bool);
    void ReleaseEffect(EffectControl*&, bool);
    void UpdateLaser(int);
    void UpdateMissile(int);
    void UpdateMissileToBoss(int);
    void UpdateMissileStop(int);
public:
    static const int k_missileReturnToBossSpeed;
    static jet::String k_tmplName;
private:
    int m_preWarningTime;  // 0x288
    int m_warningTime;  // 0x28C
    int m_startAttackTime;  // 0x290
    float m_missileSpawnPosOffset;  // 0x294
    BossObstacleTemplate::Behavior m_behavior;  // 0x298
    EffectDef *m_preWarningEffect;  // 0x29C
    EffectDef *m_warningEffect;  // 0x2A0
    EffectDef *m_attackEffect;  // 0x2A4
    EffectDef *m_impactEffect;  // 0x2A8
    EffectControl *m_preWarningEffectCtrl;  // 0x2AC
    EffectControl *m_warningEffectCtrl;  // 0x2B0
    EffectControl *m_attackEffectCtrl;  // 0x2B4
    EffectControl *m_impactEffectCtrl;  // 0x2B8
    float m_bossDistance;  // 0x2BC
    float m_bossDamage;  // 0x2C0
    float m_despicablePointsOnHit;  // 0x2C4
    math::vec3<float> m_missileReturnToBossOffset0;  // 0x2C8
    math::vec3<float> m_missileReturnToBossOffset1;  // 0x2D4
    int m_missileReturnToBossTime;  // 0x2E0
    int m_missileReturnToBossTimeCount;  // 0x2E4
    math::vec3<float> m_lastWarningPosition;  // 0x2E8
    math::vec3<float> m_missileStopPos;  // 0x2F4
    int m_missileStopParaboleTimer;  // 0x300
    int m_missileStopParaboleState;  // 0x304
    float m_missileStopLastBossDistance;  // 0x308
    bool m_firstMissileUpdate;  // 0x30C
    static jet::String k_preWarningTime;
    static jet::String k_warningTime;
    static jet::String k_startAttackTime;
    static jet::String k_preWarningEffect;
    static jet::String k_warningEffect;
    static jet::String k_attackEffect;
    static jet::String k_impactEffect;
    static jet::String k_behavior;
    static jet::String k_bodyParts;
    static jet::String k_bossDistance;
    static jet::String k_bossDamage;
    static jet::String k_missileSpawnPosOffset;
    static jet::String k_despicablePointsOnHit;
};

#endif
