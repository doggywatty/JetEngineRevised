// source/game/entities/ObstacleTemplate.cpp
