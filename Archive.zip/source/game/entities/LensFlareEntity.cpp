// source/game/entities/LensFlareEntity.cpp
#include "LensFlareEntity.h"
#include "param.h"

jet::String LensFlareEntity::k_tmplName("LensFlare");

// @0x4e4c10
void LensFlareEntity::Init() {
    GameEntity::Init();
    GetParam(jet::String("Enable"), m_enabled);
    float d;
    if (GetParam(jet::String("MinDist"), d)) m_minDistSq = d * d;
    const clara::Param *p = FindParamByName(jet::String("FlareDef"));
    m_def = clara::Project::GetInstance()->FindEntityByPath(p ? p->GetAsPath(0) : clara::Path());
}

// @0x4e4da0
void LensFlareEntity::PostInit() {
    if (!(m_flags & F_POSTINIT)) clara::Entity::PostInit();
}

// @0x4e4da4
void LensFlareEntity::NotifyParamChanged(const jet::String &n) {
    if (n.Equals("Enable")) GetParam(n, m_enabled);
    if (n.Equals("MinDist")) {
        float d;
        GetParam(n, d);
        m_minDistSq = d * d;
    }
}
