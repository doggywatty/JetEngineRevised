// source/game/entities/LargeMinionGameplay.h
#ifndef SOURCE_GAME_ENTITIES_LARGEMINIONGAMEPLAY_H
#define SOURCE_GAME_ENTITIES_LARGEMINIONGAMEPLAY_H

class LargeMinionGameplay : public GameEntity, public LevelTemplateSequenceProvider {  // sizeof 0x138
public:
    LargeMinionGameplay(const clara::Template*);
    virtual ~LargeMinionGameplay();
    virtual void Init();
    virtual void PostInit();
    virtual void Update();
    virtual void Render();
    virtual void NotifyParamChanged(const jet::String&);
    void UpdateTimeEnd();
    void Start(const Location&);
    void End();
    void HandleAccelerometer(float, float);
    LaneIndex GetLaneAttack();
    float GetRunnerDistanceToHitSq();
    LevelTemplateMgr *GetLevelTemplateMgr();
    virtual void IncSequenceNumber();
    virtual int GetNextSequenceNumber();
    virtual GameEntity *GetNextCamera();
    virtual int GetNextCameraTransitionTime();
    virtual SpeedDef *GetNextSpeed();
    virtual const jet::String &GetNextLocation();
    virtual const jet::String &GetNextNodeLabel();
    virtual const jet::String &GetNextNodeId();
    virtual void OnNodeCompleted(const jet::String&);
    void AddCreatedEntity(GameEntity*);
    void RemoveCreatedEntity(GameEntity*);
    MaterialDef *GetPostFxMaterial();
    bool IsDebugEnabled();
    bool IsSliderEnabled();
    void CleanCreatedEntities();
    void OnRunnerHit(LaneIndex);
    int GetTotalPlayTime();
    int GetRemainingTime();
    float GetSpeed();
private:
    void LoadConfigArray(const jet::String&, std::vector<LargeMinionGameplay::LargeMinionGameplayConfig,std::allocator<LargeMinionGameplay::LargeMinionGameplayConfig> >&);
    void LoadConfig(clara::Entity*, LargeMinionGameplay::LargeMinionGameplayConfig*);
    void LoadSequence(clara::Entity*, LargeMinionGameplay::LargeMinionGameplaySequence*);
    void LoadWave(clara::Entity*, LargeMinionGameplay::LargeMinionGameplayWave*);
    void LoadAnimArray(const jet::String&, std::vector<jet::String,std::allocator<jet::String> >&);
    void UpdateRunnerSpawn(int);
    void UpdateBalanceGamaplay(int);
    void UpdateDebugSliders();
    const LargeMinionGameplay::LargeMinionGameplayConfig &FindConfigToUse(const Location&);
public:
    static const jet::String k_tmplName;
    static const jet::String k_largeMinionGameplayWave_tmplName;
    static const jet::String k_largeMinionGameplaySequence_tmplName;
    static const jet::String k_largeMinionGameplayConfig_tmplName;
    static jet::String k_largeMinionSessionName;
private:
    unsigned m_gameplayTime;  // 0x94
    CameraEntity *m_cameraEntity;  // 0x98
    int m_cameraTransitionTime;  // 0x9C
    int m_postGameplayInvulnerabilityTime;  // 0xA0
    std::vector<Runner *,std::allocator<Runner *> > m_runners;  // 0xA4
    std::vector<LargeMinionGameplay::LargeMinionGameplayConfig,std::allocator<LargeMinionGameplay::LargeMinionGameplayConfig> > m_config;  // 0xB8
    MaterialDef *m_postFx;  // 0xCC
    float m_speed;  // 0xD0
    unsigned m_gameplayTimeCount;  // 0xD4
    float m_currentTiltPgt;  // 0xD8
    float m_dirStrength;  // 0xDC
    int m_unbalanceTimeCount;  // 0xE0
    const LargeMinionGameplay::LargeMinionGameplaySequence *m_currentSequence;  // 0xE4
    int m_runnerSpawnTimer;  // 0xE8
    int m_runnerWaveIdx;  // 0xEC
    LaneIndex m_laneAttack;  // 0xF0
    jet::String m_currentLocation;  // 0xF4
    Pacesetter *m_pacesetter;  // 0xF8
    Pacesetter *m_oldPacesetter;  // 0xFC
    LevelTemplateMgr *m_levelTemplateMgr;  // 0x100
    std::vector<GameEntity *,std::allocator<GameEntity *> > m_createdEntities;  // 0x104
    unsigned m_startDistanceOnPastTemplates;  // 0x118
    unsigned m_startDistanceOnCurrentTemplate;  // 0x11C
    GuiObject *m_tutorialGuiObject;  // 0x120
    int m_unbalanceTime;  // 0x124
    float m_attackLaneRange;  // 0x128
    float m_runnerDistanceToHitSq;  // 0x12C
    float m_runnerAccelerationDistance;  // 0x130
    bool m_enableDebug;  // 0x134
    bool m_enableSliders;  // 0x135
    static const jet::String k_paramGameplayTime;
    static const jet::String k_paramSpecificCamera;
    static const jet::String k_paramCameraTransitionTime;
    static const jet::String k_paramPostGamplaylnerabilityTime;
    static const jet::String k_paramPostFx;
    static const jet::String k_paramRunners;
    static const jet::String k_paramGamplayConfig;
    static const jet::String k_paramUnbalanceTime;
    static const jet::String k_paramPushRange;
    static const jet::String k_paramPushTime;
    static const jet::String k_paramPushForce;
    static const jet::String k_paramAttackLaneRange;
    static const jet::String k_paramRunnerDistanceToHit;
    static const jet::String k_paramRunnerAccelerationDistance;
    static const jet::String k_paramEnableDebug;
    static const jet::String k_paramEnableSliders;
    static const jet::String k_paramAnimOnRunnerHitLeft;
    static const jet::String k_paramAnimOnRunnerHitRight;
    static const jet::String k_paramTutorialGuiObject;
    static const jet::String k_paramMinionSpeed;
    static const jet::String k_paramNumMinions;
    static const jet::String k_paramLane;
    static const jet::String k_paramSpeedPgt;
    static const jet::String k_paramNextWaveTime;
    static const jet::String k_paramFirstRunnerDistance;
    static const jet::String k_paramDistanceBetweenRunner;
    static const jet::String k_paramGameplayTemplateIndex;
    static const jet::String k_paramBackground;
    static const jet::String k_paramWaves;
    static const jet::String k_paramEnviroBase;
    static const jet::String k_paramSequences;
    static const jet::String k_emptyStr;
};

#endif
