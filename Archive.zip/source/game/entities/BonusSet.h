// source/game/entities/BonusSet.h
#ifndef SOURCE_GAME_ENTITIES_BONUSSET_H
#define SOURCE_GAME_ENTITIES_BONUSSET_H

class BonusSet : public GameEntity {  // sizeof 0xAC
public:
    static BonusSet *GetInstance();
    static bool HasInstance();
    BonusSet(const clara::Template*);
    virtual ~BonusSet();
    virtual void Init();
    virtual void PostInit();
    virtual void Update();
    unsigned GetBonusCount();
    Bonus *GetBonus(GameItemType, bool);
    ustl::vector<Bonus *> &GetBonusesArray();
    const jet::String &GetLabelMaxUpgrade();
    const jet::String &GetLabelMaxUpgradeGolden();
    const jet::String &GetDescriptionMaxUpgrade();
    static const jet::String k_tmplName;
private:
    ustl::vector<Bonus *> m_bonuses;  // 0x90
    jet::String m_labelMaxUpgrade;  // 0xA0
    jet::String m_labelMaxUpgradeGolden;  // 0xA4
    jet::String m_descriptionMaxUpgrade;  // 0xA8
    static BonusSet *s_instance;
};

#endif
