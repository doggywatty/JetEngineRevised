// source/game/entities/gameitem/GameItem.cpp
