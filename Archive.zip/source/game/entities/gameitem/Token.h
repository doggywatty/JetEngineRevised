// source/game/entities/gameitem/Token.h
#ifndef SOURCE_GAME_ENTITIES_GAMEITEM_TOKEN_H
#define SOURCE_GAME_ENTITIES_GAMEITEM_TOKEN_H

class Token : public CollectableItem {  // sizeof 0xE8
public:
    Token(const clara::Template*);
    virtual ~Token();
    virtual void Init();
    virtual void PostInit();
    virtual void Update();
    const Deco3d *GetShopDecoRef();
private:
    virtual void Collect(Minion*);
public:
    static jet::String k_tmplName;
private:
    bool m_isDailyTokenGenerated;  // 0xE0
    const Deco3d *m_shopDecoRef;  // 0xE4
    static const jet::String k_shopDeco;
};

#endif
