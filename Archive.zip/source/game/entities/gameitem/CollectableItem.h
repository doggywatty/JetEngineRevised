// source/game/entities/gameitem/CollectableItem.h
#ifndef SOURCE_GAME_ENTITIES_GAMEITEM_COLLECTABLEITEM_H
#define SOURCE_GAME_ENTITIES_GAMEITEM_COLLECTABLEITEM_H

class CollectableItem : public Object {  // sizeof 0xE0
public:
    CollectableItem(const clara::Template*);
    virtual ~CollectableItem();
    virtual void Init();
    virtual void PostInit();
    virtual void Update();
    void OnMinionTouch(Minion*);
    virtual void CollidesWith(Collision3d*, const CollisionPair&);
protected:
    void SetState(safe_enum<CollectableItem::CollectableStateDef,enum CollectableItem::CollectableStateDef::type>);
private:
    virtual void Collect(Minion*) = 0;
    safe_enum<CollectableItem::CollectableStateDef,enum CollectableItem::CollectableStateDef::type> m_state;  // 0xDC
    static const jet::String k_appearProbability;
};

#endif
