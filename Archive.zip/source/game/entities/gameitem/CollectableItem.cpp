// source/game/entities/gameitem/CollectableItem.cpp
