// source/game/entities/gameitem/GameItem.h
#ifndef SOURCE_GAME_ENTITIES_GAMEITEM_GAMEITEM_H
#define SOURCE_GAME_ENTITIES_GAMEITEM_GAMEITEM_H

class GameItem : public CollectableItem {  // sizeof 0xEC
public:
    GameItem(const clara::Template*);
    virtual ~GameItem();
    virtual void Init();
    virtual void PostInit();
    virtual void Update();
    virtual void Render();
    static void ResetLastCreatedDistance();
    static void SetMinimumItemSpace(float);
    static void SetMaximumItemSpace(float);
    static void SetInitialSpace(float);
    static void SetTotalProbabilityValue(float);
    static void OnPowerUpFinished();
    static void OnPowerUpStarted();
    static jet::String GameItemTypeToMaxUpgradeStatisticsScope(GameItemType);
    static jet::String GameItemTypeUnlockedStatisticsScope(GameItemType);
    static bool IsItemTypeEquivalent(GameItemType, GameItemType);
private:
    static float GetNextDistance();
    static float GetInitialDistance();
    bool IsBonusLocked();
    void BuildItem();
    virtual void Collect(Minion*);
    void SetNewData();
    bool ShouldCreateItem();
    const char *GetSkippedReasonAsString();
    void CalculateItemsProbability();
    void CalculateVehiclesProbability();
    void CalculatePowerUpsProbability();
    bool AreAllItemsLocked();
    bool VerifyGeneralProbability();
    GameItemType GetRandomItem();
    GameItemType GetRandomVehicle();
    GameItemType GetRandomPowerUp();
    bool FindGameItemProbability(GameItem::GameItemProbability*, int, GameItemType, int&);
public:
    static jet::String k_tmplName;
private:
    GameItemType m_gameItemType;  // 0xE0
    bool m_created;  // 0xE4
    bool m_creationSkipped;  // 0xE5
    GameItem::SkipReason m_skippedReason;  // 0xE8
    static GameItemType s_lastSelected;
    static bool s_isPowerUpActive;
    static float s_creationSafeDistance;
    static float s_minimumItemSpace;
    static float s_maximumItemSpace;
    static float s_initialSpace;
    static float s_probabilityValue;
    static GameItem::GameItemProbability s_allGameItems[0];
    static GameItem::GameItemProbability s_powerUps[0];
    static GameItem::GameItemProbability s_vehicles[0];
    static const int k_pgtToCreateItem;
    static const jet::String k_GameItemType;
};

#endif
