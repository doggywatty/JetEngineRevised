// source/game/entities/gameitem/Token.cpp
