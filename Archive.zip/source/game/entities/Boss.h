// source/game/entities/Boss.h
#ifndef SOURCE_GAME_ENTITIES_BOSS_H
#define SOURCE_GAME_ENTITIES_BOSS_H

class Boss : public Actor {  // sizeof 0x228
public:
    Boss(const clara::Template*);
    virtual ~Boss();
    virtual void Update();
    virtual void Render();
    virtual void PostInit();
    virtual bool CanSpawnNewEntity(LevelTemplateInstance*);
    bool IsActive();
    bool IsDefeated();
    void EnableBossBehavior(bool);
    void DisableBossBehavior(bool);
    virtual bool IsOutOfScene();
    void IncreaseHealth(float);
    virtual void StartAttack();
    virtual void OnShoot();
    virtual bool CanShoot();
    virtual const math::vec3<float> &GetShootPosition();
    virtual const jet::String &GetBossSoundLabel();
    virtual int GetStartMinionEvent();
    virtual int GetEndMinionEvent();
    void OnMinionHittedByBossObstacle();
    void SetPuppet(Puppet*);
    Puppet *GetPuppet();
    safe_enum<EBossesDef,enum EBossesDef::type> GetId();
protected:
    virtual void UpdatePersecution();
    virtual void SM_OnChangeState(ActorState*, ActorState*);
private:
    virtual void OnAppear();
    virtual void OnDie();
    void SetBehaviorState(Boss::BossState);
public:
    static const jet::String k_vectorSoundStateIntroLoop;
    static const jet::String k_vectorSoundStateOutro;
    static jet::String k_tmplName;
protected:
    safe_enum<EBossesDef,enum EBossesDef::type> m_id;  // 0x1DC
    math::vec3<float> m_positionOffset;  // 0x1E0
private:
    int m_bossSoundHandle;  // 0x1EC
    Boss::BossState m_behaviorState;  // 0x1F0
    Pacesetter::PacestterCacheData m_cacheData;  // 0x1F4
    Puppet *m_puppet;  // 0x208
    int m_dyingTimer;  // 0x20C
    int m_dying_time;  // 0x210
    float m_health;  // 0x214
    float m_maxHealth;  // 0x218
    int m_timeToRestore;  // 0x21C
    int m_timeToRestoreCount;  // 0x220
    int m_winEngineEvent;  // 0x224
    static jet::String ms_bossName;
    static const jet::String k_posOffset;
    static const jet::String k_health;
    static const jet::String k_timeToResTore;
    static const jet::String k_winEngineEvent;
    static const jet::String k_vectorSoundLabel;
};

#endif
