// source/game/entities/Collision3d.cpp
