// source/game/entities/Minion.cpp
#include "Minion.h"
#include "Deco3d.h"
#include "../actors/statemachine/StateDatabase.h"
#include "scene/model.h"
#include <cstdio>

jet::String Minion::k_tmplName("Minion");

Minion::Minion(const clara::Template *t) : GameEntity(t), m_deco(0), m_stateSet(0), m_state(0), m_costumeIdx(15) {}
Minion::~Minion() { delete m_deco; }

void Minion::Init() { GameEntity::Init(); }

// Object::InitDeco3d @0x57f3e4
void Minion::PostInit() {
    GameEntity::PostInit();
    const clara::Param *p = FindParamByName(jet::String("objectDeco"));
    clara::Project *project = clara::Project::GetInstance();
    if (!p || !project) return;
    Deco3d *tmpl = dynamic_cast<Deco3d*>(project->FindEntityByPath(p->GetAsPath(0)));
    if (!tmpl) return;
    m_deco = new Deco3d(tmpl, 0);
    const math::vec3<float> &a = GetScale(), &b = tmpl->GetScale();
    m_deco->SetTransform(GetPosition(), GetRotation(), math::vec3<float>(a.x * b.x, a.y * b.y, a.z * b.z));
}

bool Minion::SetStateMachine(const jet::String &set, const jet::String &state) {
    m_stateSet = StateDatabase::GetInstance()->FindStateSetDataByName(set);
    if (!m_stateSet) {
        fprintf(stderr, "ERROR: no state set %s\n", set.c_str());
        return false;
    }
    return EnterState(state);
}

bool Minion::CheckCondition(const jet::String &name, int value) const {
    if (name.Equals("IsMinion")) return value == m_costumeIdx;
    return false;
}

bool Minion::EnterState(const jet::String &name) {
    if (!m_stateSet) return false;
    for (int hops = 0; hops < 16; hops++) {
        int idx = m_stateSet->FindStateIdxByName(hops ? m_state->name : name);
        if (hops == 0 && idx < 0) return false;
        const StateData &s = m_stateSet->states[(unsigned)(idx < 0 ? 0 : idx)];
        m_state = &s;
        // triggers taken on entry (event -1) when their conditions hold
        const StateData *next = 0;
        for (unsigned t = 0; t < s.triggers.size() && !next; t++) {
            const StateTrigger &tr = s.triggers[t];
            if (tr.values[0] != -1 || tr.target.empty()) continue;
            bool ok = true;
            for (unsigned c = 0; c < tr.conditions.size() && ok; c++) ok = CheckCondition(tr.conditions[c].name, tr.conditions[c].value);
            if (!ok) continue;
            int n = m_stateSet->FindStateIdxByName(tr.target);
            if (n >= 0) next = &m_stateSet->states[(unsigned)n];
        }
        if (!next) break;
        m_state = next;
        if (m_state->anims.empty() && !m_state->isSelector) continue;
        if (!m_state->isSelector) break;
        // selectors pick their first entry's state
        if (m_state->entries.empty()) break;
        int n = m_stateSet->FindStateIdxByName(m_state->entries[0].name);
        if (n < 0) break;
        m_state = &m_stateSet->states[(unsigned)n];
    }
    if (!m_deco || !m_state || m_state->anims.empty()) return true;
    const bool loop = m_state->FindTrack(0, "Loop") != 0;
    m_deco->SetAnimation(m_state->anims[0].name, loop);
    if (m_deco->GetModel()) m_deco->GetModel()->GetAnimController().SetSpeed(m_state->GetParam("AnimSpeed", 100) / 100.0f);
    return true;
}

void Minion::Update() {
    if (m_deco) m_deco->Update();
}
void Minion::Render() {
    if (m_deco) m_deco->Render();
}
