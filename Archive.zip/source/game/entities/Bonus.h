// source/game/entities/Bonus.h
#ifndef SOURCE_GAME_ENTITIES_BONUS_H
#define SOURCE_GAME_ENTITIES_BONUS_H

class Bonus : public GameEntity {  // sizeof 0xD4
public:
    Bonus(const clara::Template*);
    virtual ~Bonus();
    virtual void Init();
    virtual void PostInit();
    virtual void Update();
    void OnStarted();
    const jet::String &GetBonusName();
    const jet::String &GetBonusDescriptionForNextLevel();
    const jet::String &GetBonusLabelMaxUpgrade();
    GameItemType GetGameItemType();
    const Deco3d *GetDecoRef();
    const EffectDef *GetEffectRef();
    const Deco3d *GetShopDecoRef();
    bool IsGolden();
    bool IsLocked();
    int GetCurrentLevel();
    void SetCurrentLevel(int);
    void OnCurrentLevelPurchased();
    int GetLevelsCount();
    bool IsMaxLevel();
    Price *GetPrice(int);
    float GetProbabilityWeight(int);
    int GetAmount(int);
    Price *GetPriceForNextLevel();
private:
    const jet::String &GetBonusDescriptionLevel0();
    const jet::String &GetBonusDescriptionAboveLevel0();
public:
    static jet::String k_tmplName;
private:
    jet::String m_name;  // 0x90
    jet::String m_descriptionLevel0;  // 0x94
    jet::String m_descriptionAboveLevel0;  // 0x98
    GameItemType m_gameItemType;  // 0x9C
    const Deco3d *m_decoRef;  // 0xA0
    const EffectDef *m_effectRef;  // 0xA4
    const Deco3d *m_shopDecoRef;  // 0xA8
    bool m_isGolden;  // 0xAC
    ustl::vector<Price *> m_prices;  // 0xB0
    ustl::vector<float> m_probabilityWeights;  // 0xC0
    int m_currentLevel;  // 0xD0
    static const jet::String k_name;
    static const jet::String k_descriptionLevel0;
    static const jet::String k_descriptionAboveLevel0;
    static const jet::String k_gameItemType;
    static const jet::String k_deco;
    static const jet::String k_effect;
    static const jet::String k_shopDeco;
    static const jet::String k_isGolden;
    static const jet::String k_isLocked;
    static const jet::String k_prices;
    static const jet::String k_probabilities;
};

#endif
