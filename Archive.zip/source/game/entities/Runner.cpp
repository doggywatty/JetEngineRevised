// source/game/entities/Runner.cpp
